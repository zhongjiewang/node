﻿#!/usr/bin/env node
'use strict';

const userAgent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36';
const startPage = 'https://www.tripadvisor.com/Hotels-g294232-Japan-Hotels.html';

// list page related markers
const hotelListBeginsMarker = '<!-- PLACEMENT hotels_list_short_cells2 -->',
	hotelListEndsMarker = '<div id="google_csa_box_BOT"',
	//hotelSponsoredCellBeginsMarker = '<!-- PLACEMENT sponsored_coupon_listing -->',
	//hotelSponsoredCellEndsMarker = '<!--etk-->',
	// city list 
	geoListBeginsMarker1 = '<div id="LEAF_GEO_LIST" class="deckB easyClear">',
	geoListEndsMarker1 = '<div class="deckTools btm leaf_geos_override">',

    geoListBeginsMarker2 = '<div class="geos_grid">',
	geoListEndsMarker2 = '</div> </div> </div> </div> <div class="deckTools btm">',

	pageNumberBeginsMarker = '<div class="pageNumbers">', //be in common use;
	pageNumberEnsMarker = 'class="pageNum last taLnk"';

const requestLanguage = 'en-US;q=0.8,zh-CN;q=0.2';
// const crawlerDatabase = 'mongodb://localhost:27017/crawler',
// 	hotelListCollName = 'tempHotelLinks';

const crawlerDatabase = 'mongodb://localhost:27017/tripadvisor',
	hotelListCollName = 'tempHotelLinks111';

var Crawler = require('js-crawlerMY'),
	_ = require('underscore'),
	url = require('url'),
	log4js = require('log4js'),
	AsyncStreamer = require('async-streamerMY'),
	path = require('path');

var temppath = path.join(__dirname,'/logggg');

log4js.configure({
  appenders: [
    { type: 'console' },
    { type: 'file', filename: `${temppath}/crawler.log`}
  ]
});

log4js.replaceConsole();

var crawler = null;

var asyncStreamer = new AsyncStreamer({
	url: crawlerDatabase,
	collection: hotelListCollName
})
.start();

var hotelIds = [];

function parseAndRequestCitysPageNumberFromTwo (content, link, crawler) {
	let pageNumberSection = content.substring(content.indexOf(pageNumberBeginsMarker), content.indexOf(pageNumberEnsMarker) + pageNumberEnsMarker.length);
	let lastPageDataOffsetString = pageNumberSection.substring(pageNumberSection.indexOf(pageNumberEnsMarker) - 18);
	let lastPageDataOffsetNumber = /\d+/img.exec(lastPageDataOffsetString)[0];
	
	let distance = 20;
	var i = 20;
	while (i <= lastPageDataOffsetNumber){
		crawler.enqueueRequest({
			url: `https://www.tripadvisor.com/Hotels-g294232-oa${i}-Japan-Hotels.html#LOCATION_LIST`,
			'Accept-Language': requestLanguage
		});
		i = i + distance;
	}
}

function parseAndRequestCityLinks(content, link, crawler) {
	let beginMarker = geoListBeginsMarker2;
	let endMarker = geoListEndsMarker2;
	if (!(link.indexOf('#LOCATION_LIST') >= 0)) {
		beginMarker = geoListBeginsMarker1;
		endMarker = geoListEndsMarker1;
	}

	let geoListSection = content.substring(content.indexOf(beginMarker) , content.indexOf(endMarker)); 
	let hrefRegEx = /<div class="geo_name">\n<a[^>]+?href="(.+?)">(.+?)<\/a>([^]{10,15})/img;
	let matches = null;

	while ((matches = hrefRegEx.exec(geoListSection)) != null ) {
		crawler.enqueueRequest({
			url: url.resolve(link, matches[1]),
			'Accept-Language': requestLanguage
		}, 1, true);
	}
}

function parseAndRequestHotelsFromPageTwo (content, link, crawler) {
	if(content.indexOf(pageNumberBeginsMarker) == -1){
		return;
	}
	let pageNumberSection = content.substring(content.indexOf(pageNumberBeginsMarker), content.indexOf(pageNumberEnsMarker) + pageNumberEnsMarker.length);
	
	let lastPageDataOffsetString = pageNumberSection.substring(pageNumberSection.indexOf(pageNumberEnsMarker) - 18);
	let lastPageDataOffsetNumber = /\d+/img.exec(lastPageDataOffsetString)[0];
	let distance = 30;
	var i = 30;
	while (i <= lastPageDataOffsetNumber){
		let t1 = link.match(/-g\d+?-/im);
		crawler.enqueueRequest({
			url: link.replace(/-g\d+?-/im,`${t1[0]}oa${i}-`) + '#ACCOM_OVERVIEW',
			'Accept-Language': requestLanguage
		},1, true);
		i = i + distance;
	};
}
//

function parseAndStreamHotels(content, link) {
	let hotelList = content.substring(content.indexOf(hotelListBeginsMarker),content.indexOf(hotelListEndsMarker));

	//hotelcellBeginsMarker = '<div class="listing easyClear  p13n_imperfect " ',
	//hotelcellEndsMarker = '<!--etk-->',
	let cellRegexp = /<div class="listing easyClear  p13n_imperfect "[^]+?<!--etk-->/img;
	let matches = null;
	while ((matches = cellRegexp.exec(hotelList)) != null ) {
		let hotelItem = matches[0];
		let idMatches = /data\-locationid="(.+?)"/img.exec(hotelItem);
		if(_.contains(hotelIds,idMatches[1])) {
			console.log(`Found ${idMatches[1]} already parse in other page`);
			continue;
		}
		let hotel = {
				crawler: 'tripAdvisorEnHotelLinksCrawler',
				website: 'tripAdvisor.com',
				country: 'jp',
				language: 'en',
				href: link,
				id: idMatches[1]
			};

		hotel.name = /dir=ltr>(.+?)<\/a>/img.exec(hotelItem.substring(idMatches.index))[1];
		hotel.url = url.resolve(link, /<a[^>]+?href="(.+?)"/img.exec(hotelItem)[1]);
		let reviewsMatches = /#REVIEWS">([^]+?)<\/a>/ig.exec(hotelItem);
		if (reviewsMatches) hotel.reviews = reviewsMatches[1].replace(/\n/g, '');
		hotel.tags = [];
		let tagSection = hotelItem.substring(hotelItem.indexOf('<div class="clickable_tags">'));
		let tagRegEx = /<a class="tag".+?>(.+?)<\/a>/ig;
		let m = null;
		while (m = tagRegEx.exec(tagSection)) {
			hotel.tags.push(m[1]);
		}
		hotel.createdAt = new Date();
		asyncStreamer.commit(hotel, result => {});
		hotelIds.push(hotel.id);
		console.log(' hotel cell id test')
		console.log(hotel);
	}
}

var cityResponseCount = 0;

crawler = new Crawler()
.configure({
	ignoreRelative: false, 
	depth: 1,
	userAgent: userAgent,
	maxConcurrentRequests: 6,
	oblivious: true,
	enableTimeOut: true,
	shouldCrawl: function(url) {
		return true;
	},
	onSuccess: function(page) {

		console.log(page.actualUrl);
		// //citys list page 1 response 
		// if (page.url.indexOf('#') < 0 && page.url.indexOf('Japan-Hotels.html') >= 0 ) {
		// 	parseAndRequestCitysPageNumberFromTwo (page.body, page.actualUrl, this);
		// 	parseAndRequestCityLinks(page.body, page.actualUrl, this);
		// }

		// //citys list page 2... response 
		// else if (page.url.indexOf('#LOCATION_LIST') >= 0) { 
		// 	parseAndRequestCityLinks(page.body, page.actualUrl, this);  
		// }
		
		// // page 1  hotels of a city response 
		// else if (page.url.indexOf('#') < 0 && page.url.indexOf('Japan-Hotels.html') <= 0 && page.url.indexOf('#ACCOM_OVERVIEW') < 0) {
		// 	cityResponseCount ++;
		// 	parseAndRequestHotelsFromPageTwo(page.body, page.actualUrl, this);
		// 	//parse citys links and save hotel url infomation
		// 	parseAndStreamHotels(page.body, page.actualUrl);
		// }
		// // page 2..  hotels of a city response 
		// else if (page.url.indexOf('Japan-Hotels.html') <= 0 && page.url.indexOf('#ACCOM_OVERVIEW') >= 0) {
		// 	//parse citys links and save hotel url infomation
		// 	parseAndStreamHotels(page.body, page.actualUrl);
		// 	console.log(' %d hotels have been crawled', hotelIds.length);
		// }
	},
	onFailure: function(postmortem) {
    	console.log('Failed to crawl %s (%s)', postmortem.url, postmortem.status? `HTTP: ${postmortem.status}` : `OTHER: ${postmortem.error}`);
    	if (postmortem.status && [404].indexOf(postmortem.status) < 0) {
    		console.log('...Ask for re-crawling when possibily recoverable failure/error returned from web server');
    		return true;
    	}
    	if (postmortem.error && ['EAI_AGAIN', 'ETIMEDOUT', 'ECONNRESET', 'ENOTFOUND'].indexOf(postmortem.error.code) >= 0) {
    		console.log('...Ask for re-crawling in case of: 1. name resolving error, 2. timeout, 3. connection reset');
    		return true;
    	}
    	return false;
  	},
	onAllFinished: function() {
		console.log('In total %d hotels have been crawled', hotelIds.length);
		asyncStreamer.stop();
  	}
})
.crawl({
	url: startPage,
	'Accept-Language': requestLanguage
});






















































