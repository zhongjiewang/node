#!/usr/bin/env node
'use strict';

const userAgent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36';
var  writeImageSuccessCount = 1;

var crypto = require('crypto'),
    Crawler = require('js-crawler'),
    co = require('co'),
    log4js = require('log4js'),
    fs = require('fs'),
    mongoClient = require('mongodb').MongoClient,
    keypress = require('keypress');

log4js.configure({
  appenders: [
    { type: 'console' },
    { type: 'file', filename: `/tripadvisor/hotel/hotelDetailsCrawler.log` }
  ]
});

log4js.replaceConsole();

var crawler = new Crawler();
 
const crawlerDatabase = 'mongodb://localhost:27017/crawler',
      collectionName = 'bookingHotels';

// When the code is running in the server, please change the root path of the picture, and make sure the root path is exist;
const rootPathOfImages = '/galleries/booking.com/hotel/';

// const rootPathOfImages = '/Users/zhongjie/Desktop/SavePicture/bookinghotel/';

fs.stat(rootPathOfImages,function (err, stats) {  
    if(err)  { console.error(`the rootPath is not exit,please create it: ${rootPathOfImages}`);   process.exit(1);}
});




co(function*() {
    let db = yield mongoClient.connect(crawlerDatabase);
    let linksColl = db.collection(collectionName);
    let records = yield linksColl.find().toArray();
    yield db.close();

    console.log('%d stations to crawl', records.length);

    crawler.crawl();

    for (let record of records) {
           
           crawler.enqueueRequest({
                url: record.photo_url,
            URLType: 'image',
                 id: record.id
            });

    }
})
.catch(err => { console.error(err.stack); });



// var needSaveDetailLink ;
// var needSavePageSecondLink;
// var needSaveImageLink;

crawler.configure({
    ignoreRelative: false, 
    depth: 1,
    userAgent: userAgent,
    maxConcurrentRequests: 10,
    oblivious: true,
    enableTimeOut: true,// this option is very important 'coz sometimes this website will pend responding (forever!) and then the accumulated pending requests will exceed the concurrent threshold thus prevent the web crawler (forever!) from issuing other requests
    shouldCrawl: function(url) {
        return true;
    },
    onSuccess: function(page) {

        if (page.options.URLType === 'image') {
            
            parseImageBufferAndwriteImage(page.actualUrl,page.options.id, page.body,rootPathOfImages);
        };

        console.log(`response --\nWriteImageSuccessCount: ${writeImageSuccessCount}`); 
    },

    onFailure: function(postmortem) {
        console.error('Failed to crawl %s (%s)', postmortem.url, postmortem.status? `HTTP: ${postmortem.status}` : `OTHER: ${postmortem.error}`);
        console.error(`statusSEE :${postmortem.status}`);// get 410 number
        // console.log([410].indexOf(postmortem.status));
         // 410 是资源被删除,已经不存在
        if (postmortem.status && postmortem.status !== 404 && postmortem !== 410 ) {
            console.log('...Ask for re-crawling when possibily recoverable failure/error returned from web server', postmortem.url);
            return true;
        }
        if (postmortem.error && ['EAI_AGAIN', 'ETIMEDOUT', 'ECONNRESET', 'ENOTFOUND'].indexOf(postmortem.error.code) >= 0) {
            console.log('...Ask for re-crawling in case of: 1. name resolving error, 2. timeout, 3. connection reset');
            return true;
        }
        return false;
    },
    onAllFinished: function() {
        
        console.log('All attraction details have been crawled');
        console.log(`\nWriteImageSuccessCount: ${writeImageSuccessCount}`);     
    }
});




function parseImageBufferAndwriteImage (url, hotelID, bufferContent, rootPath) {
 
    let imageid = /\/(\d+?).jpg/im.exec(url);
    getPathAndWrite(rootPath, hotelID, imageid[1], bufferContent);
 }   


function getPathAndWrite (rootPath, hotelID, imageIDName, bufferContent) {


    let theLastThreeNumber = hotelID.slice(-3);

    let sumOftheLastThreeNumber = function (){
                let sum = 0;
                for (let i = 0; i < theLastThreeNumber.length; i++) {
                    let temp = parseInt(theLastThreeNumber[i]);
                    sum += temp;
                };
                return sum;
        }();
    
    let firstDictionary = sumOftheLastThreeNumber.toString();

    let hashPath = rootPath + firstDictionary;


    fsMake(hashPath)
    .then(function(hashPath) {
        let finalPath = hashPath + '/' + hotelID;
        return fsMake(finalPath);
    })
    .then(function(finalPath) {
        // console.log(`finalPath -- ${finalPath}`)
        // console.log(`imageIDName---${imageIDName}`);
        writeFile(finalPath+'/'+imageIDName + '.jpg', bufferContent,{encoding: null});
    });
 
};


function fsMake (path) {
   let  k =   new Promise (function (resolve, reject) {
                fs.stat(path,function (err, stats) {
                    if(!err) {
                        resolve(path) ;
                    }else {
                        fs.mkdir (path, function(err){
                            if(!err) resolve(path);
                        })
                    }
                });
            }); 

   return k;
};



function writeFile(path, data, options) {
    fs.writeFile(path, data, options,function(err){
        // if(!err) console.log('Wrtie to Success :' + path);
        // else console.error('Write Failed :' + path);
        if (!err) writeImageSuccessCount ++ ;
    })
};
 


    //必须是路径已经存在的情况下,才会有回调函数stats,如果该路径下没有文件,则直接报错,并不会有stats的参数
    // fs.stat(hashPath, function (err, stats) {
    //     if (err) {//目录不存在,需要创建目录;
    //         fs.mkdir(finalPath,function(err){
    //             if (err) return console.error(err);
    //             else return finalPath;
    //         });

    //     }else {
    //         return finalPath;
    //     }
    // }); 
 
// fs.exists(path, callback)

// 判断文件是否存在，回调函数参数是 bool 值。例如：
// fs.exists('/etc/passwd', function (exists) {
//   util.debug(exists ? "it's there" : "no passwd!");
// });
// fs.exists() 是老版本的函数，因此在代码里不要用。
// 另外，打开文件前判断是否存在有漏洞，在fs.exists() 和 fs.open() 调用中间，另外一个进程有可能已经移除了文件。最好用 fs.open() 来打开文件，根据回调函数来判断是否有错误。
// fs.exists() 未来会被移除。
// fs.existsSync(path)

// fs.exists() 的同步版本. 如果文件存在返回 true, 否则返回false。
// fs.existsSync() 未来会被移除。
 //http://4travel.jp/domestic/area/okinawa/okinawa/hontohokubu/motobu/zoo/10000190/
 // 0 57个 1 60个; 共计117个
 // var arr = ['http://4travel.jp/domestic/area/kyushu/nagasaki/shimabara/shimabaraHantonanbu/park/10018813-pict/',
 //            'http://spot4travel.jp/landmark/dm/10032391/pict/',
 //            'http://4travel.jp/domestic/area/okinawa/okinawa/hontohokubu/motobu/zoo/10000190-pict/',
 //            'http://spot4travel.jp/landmark/dm/10667842/pict',
 //            'http://4travel.jp/domestic/area/kyushu/kagoshima/izumi/izumi/hotplace/11334051-pict/',
 //            'http://4travel.jp/domestic/area/kanto/chiba/maihamaurayasu/tokyodisneyresort/themepark/11187263/',
 //            'http://spot4travel.jp/landmark/dm/10033189',
 //            'http://4travel.jp/domestic/area/kanto/chiba/maihamaurayasu/tokyodisneyresort/themepark/11187264/',
 //            'http://spot4travel.jp/landmark/dm/10002108',
 //            'http://4travel.jp/domestic/area/chugoku/hiroshima/miyajima/miyajima/temple/10002779/',
 //            'http://4travel.jp/domestic/area/hokkaido/hokkaido/asahikawa/asahikawa/zoo/10000013/',
 //            'http://4travel.jp/domestic/area/kanto/tokyo/ueno/asakusa/temple/10000931/',
 //            'http://spot4travel.jp/landmark/dm/10002696'];











