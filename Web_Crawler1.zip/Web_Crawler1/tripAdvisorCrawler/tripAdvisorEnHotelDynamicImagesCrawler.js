





















/*
- (void)gainLineDetailData
{
    [_mapView removeAnnotations:_mapView.annotations];
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:[[UIApplication sharedApplication].windows lastObject] animated:YES];
    
    [_currentlng_BasicInfoDict removeAllObjects];
    NSMutableDictionary * routeDict = _lineIDsArray[_curLineIndex];
    NSLog(@"_currlineIndex---%ld",(long)_curLineIndex);
    NSLog(@"current--oid--%@",routeDict[@"oid"]);
    RouteInfo * routeInfo = routeDict[@"routeInfo"];
    
    weakifyself;
    [_introView pressToDetail:^{
        strongifyself;
        [OfflineSQLManger sharedGeosInstance].currentRouteInfo = routeInfo;
        [self topPressToDetailWithType:DetailVCType_Line oid:routeDict[@"oid"] attrib:8];
    }];
    
    self.introView.desLabel.text = routeInfo.name;
    ContentSection *sec = routeInfo.contentList[0];
    self.lineView.desLabel.text = sec.body;
    
    [[TAUHomeDataRequest sharedInstance] getThumbnail:routeDict[@"oid"] cache:^(NSData *thumbnailCache) {
    } success:^(NSData *thumbnailSuccess) {
        strongifyself;
        NSLog(@"------line--thumbnil---response");
        self.introView.icon.image = [UIImage imageWithData:thumbnailSuccess];
        if (self.introView.icon.image == nil) {
            self.introView.icon.image = [UIImage imageNamed:@"placeholder3"];
        }
    } failure:^(TAUError *error) {
        
    }];
    
    ItineraryItem *item = routeInfo.itineraryList[0];
    [self.lineView configWithDayArray:routeInfo.itineraryList];
    
    //获取poi详情并显示大头针、连线
    NSArray *itemArray = [NSArray arrayWithArray:item.poisList];
    NSLog(@"-------route--oids--%@",itemArray);
    [self.mapView removeAnnotations:self.mapView.annotations];
    [self.linePoiArray removeAllObjects];
    [self.lineAnnoArray removeAllObjects];
    
    NSMutableArray * searchedThemes = [_geosSQLManger selectPoisWithOids:itemArray];
    NSMutableArray * allThemes = [NSMutableArray array];
    
    for (int i = 0; i < itemArray.count; i ++) {
        for (BasicPoiInfo * info in searchedThemes) {
            if ([info.oid isEqualToString:itemArray[i]]) {
                [allThemes addObject:info];
            }
        }
    }
    
    NSMutableArray *imageArray = [NSMutableArray array];
    NSMutableArray *imageLongArray = [NSMutableArray array];
    for (int i = 0; i < allThemes.count; i ++) {
        TAUCoredataBasicPoiInfo *basic = allThemes[i];
        [imageArray addObject: basic.oid];
    }
    [[TAUHomeDataRequest sharedInstance] getThumbnailLongData:imageArray cache:^(NSData *thumbnailCache) {
    } success:^(NSData *thumbnailSuccess) {
        strongifyself;
        [imageLongArray removeAllObjects];
        long offset = 0;
        while (offset < thumbnailSuccess.length) {
            NSData *mData = [thumbnailSuccess subdataWithRange:NSMakeRange(offset, 4)];
            int size = CFSwapInt32LittleToHost(*(int*)([mData bytes]));
            offset += 4;
            NSData *tData = [thumbnailSuccess subdataWithRange:NSMakeRange(offset, size)];
            NSData *macData = [[NSData alloc] initWithBytes:[tData bytes] length: tData.length];
            [imageLongArray addObject:macData];
            offset += size;
        }
        NSLog(@"imaga--long--array--%lu",(unsigned long)imageArray.count);
        NSMutableArray * points = [NSMutableArray array];
        for (int i = 0; i < imageLongArray.count; i++) {
            BasicPoiInfo *mBasic = allThemes[i];
            [_currentlng_BasicInfoDict setObject:mBasic forKey:[NSString stringWithFormat:@"%f", mBasic.location.lng]];
            //mBasic.imageData = imageLongArray[i];
            //  _viewAnoImgeData = [NSMutableData dataWithData:imageLongArray[i]];
            [self.linePoiArray addObject:mBasic];  //加入当前页面上的poi数组
            //添加大头针
            MGLPointAnnotation *locat = [[MGLPointAnnotation alloc] init];
            locat.coordinate = CLLocationCoordinate2DMake(mBasic.location.lat, mBasic.location.lng);
            locat.title = mBasic.name;
            NSLog(@"---------routeview");
            [points addObject:locat];
        }
        NSLog(@"%@",points);
        [[TRSingleMap sharedInstance].mapView addAnnotations:points];
        dispatch_time_t time = dispatch_time(DISPATCH_TIME_NOW, 0.5 * NSEC_PER_SEC);
        dispatch_after(time, dispatch_get_main_queue(), ^{
            [self addThumnailImageWithPoints:points imagesdata:imageLongArray];
            hud.hidden = YES;
        });
        [self mapViewFitAnnotationsWithPoints:[self.mapView annotations] forVCtype:VCType_Line];
        [self addLineOverlay];
    } failure:^(TAUError *error) {
        if ([error.errorString isEqualToString:@"404"]) {
            [MBProgressHUD showError:@"Request error"];
        }
    }];
}
*/












































































