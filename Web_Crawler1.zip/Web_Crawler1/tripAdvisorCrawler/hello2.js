const userAgent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36';
const crawlerDatabase = 'mongodb://localhost:27017/tripadvisor',
    // hotelImageWebPageLinks = 'hotelImageWebPageLinks',
    hotelLinksCollName = 'hotelLinks',
    rootPathOfImages = '/Users/zhongjie/Desktop/SavePicture/1ap/';


// const crawlerDatabase = 'mongodb://localhost:27017/crawler',
//     hotelLinksCollName = 'tempHotelLinks',
//     // hotelImageWebPageLinks = 'tempHotelImageWebPageLinks',
//     rootPathOfImages = '/galleries/tripadvisor.com/hotels/professional/';


console.log('----------------');

// const tripadvisorUrl = 'https://www.tripadvisor.com',
//       requestLanguage = 'en-US;q=0.8,zh-CN;q=0.2';
// var Crawler = require('js-crawler'),
//     mongoClient = require('mongodb').MongoClient,
  var  co = require('co');
//     _ = require('underscore'),
//     log4js = require('log4js'),
//     fs = require('fs'),
//     keypress = require('keypress'),
//     AsyncStreamer = require('async-streamer');

// const crawlerDatabase = 'mongodb://localhost:27017/tripadvisor',
  const  hotelListCollName = 'tempHotelLinks2222';
  const  hotelListImageColl = 'tempHotelLinksImage';

// var asyncStreamer = new AsyncStreamer({
//     url: crawlerDatabase,
//     collection: hotelListImageColl
// }).start();

var webpage = require('webpage'); 

page = webpage.create();

var fs = require('fs');

page.viewportSize = { width: 1024, height: 800 };
page.clipRect = { top: 0, left: 0, width: 1024, height: 800 };
page.settings = {
    javascriptEnabled: true,
    loadImages: false,
    webSecurityEnabled: false,
    userAgent: 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.137 Safari/537.36 LBBROWSER'
    //要指定谷歌ua,我用火狐无法浏览
};

console.log('----------------');

co(function*() {
//     let db = yield mongoClient.connect(crawlerDatabase);
//     let linksColl = db.collection(hotelLinksCollName);
//     let records = yield linksColl.find().toArray();
    
//     yield db.close();
    
//     let spliceArr = records.splice(0);
//     console.log('%d professional hotels to crawl', spliceArr.length);

// // let rurl = 'https://www.tripadvisor.com/Hotel_Review-g1120615-d670212-Reviews-Hotel_Sierra_resort_Hakuba-Hakuba_mura_Kitaazumi_gun_Nagano_Prefecture_Chubu.html';
//     for (let record of spliceArr) {
//         // let opathName = `${rootPathOfImages}${record.id}.jpg`;
//         // if (!fs.existsSync(opathName)){
//             page.open(url2, function () {
//             console.log('start');
//             if (status === 'success') {
//                     page.close();
//                 }
//             })
//         // }else{
//         //     console.log("webResquestalready exit",record.id);
//         // }

//     }

//     // logSave();
})
// .catch(err => { console.error(err.stack); });






















