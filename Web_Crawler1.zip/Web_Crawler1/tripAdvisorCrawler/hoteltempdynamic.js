#!/usr/bin/env node
'use strict';

const userAgent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36';
// const crawlerDatabase = 'mongodb://localhost:27017/tripadvisor',
//     // hotelImageWebPageLinks = 'hotelImageWebPageLinks',
//     hotelLinksCollName = 'hotelLinks',
//     rootPathOfImages = '/Users/zhongjie/Desktop/SavePicture/1ap/';


const crawlerDatabase = 'mongodb://localhost:27017/crawler',
    hotelLinksCollName = 'tempHotelLinks',
    // hotelImageWebPageLinks = 'tempHotelImageWebPageLinks',
    rootPathOfImages = '/galleries/tripadvisor.com/hotels/professional/';

const tripadvisorUrl = 'https://www.tripadvisor.com',
      requestLanguage = 'en-US;q=0.8,zh-CN;q=0.2';
var Crawler = require('js-crawler'),
    mongoClient = require('mongodb').MongoClient,
    co = require('co'),
    _ = require('underscore'),
    log4js = require('log4js'),
    AsyncStreamer = require('async-streamer'),

    fs = require('fs'),
    keypress = require('keypress');

log4js.configure({
  appenders: [
    { type: 'console' },
    { type: 'file', filename: '/repos.git/webCrawler/zhongjie/log/tripadvisorHotelImagesCrawler5.log' }
  ]
});


log4js.replaceConsole();


function saveImage(url, hotelId, bufferContent, rootPath){

    let path = `${rootPathOfImages}/${hotelId}.jpg`;
    writeFile(path, bufferContent, {encoding : null}, hotelId);
}

function fsMake (path) {
   let  k =   new Promise (function (resolve, reject) {
                fs.stat(path,function (err, stats) {
                    if(!err) {
                        resolve(path) ;
                    }else {
                        fs.mkdir (path, function(err){
                            if(!err) resolve(path);
                        })
                    }
                });
            }); 

   return k;
};
var writeImageSuccessCount = 0;
function writeFile(path, data, options, hotelId) {
    if (!fs.existsSync(path)) {
        fs.writeFile(path, data, options,function(err){
            if (!err) { writeImageSuccessCount ++ };
        });
    };
};





var crawler = null;

crawler = new Crawler()
.configure({
    ignoreRelative: false, 
    depth: 1,
    userAgent: userAgent,
    maxConcurrentRequests: 30,
    oblivious: true,
    enableTimeOut: true,
    shouldCrawl: function(url) {
        return true;
    },
    onSuccess: function(page) {


        saveImage(page.actualUrl, page.options.id, page.body, rootPathOfImages);
        

    },
    onFailure: function(postmortem) {
        console.log('Failed to crawl %s (%s)', postmortem.url, postmortem.status? `HTTP: ${postmortem.status}` : `OTHER: ${postmortem.error}`);
        if (postmortem.status && [404, 403].indexOf(postmortem.status) < 0) {
            console.log('...Ask for re-crawling when possibily recoverable failure/error returned from web server', url);
            return true;
        }
        if (postmortem.error && ['EAI_AGAIN', 'ETIMEDOUT', 'ECONNRESET', 'ENOTFOUND'].indexOf(postmortem.error.code) >= 0) {
            console.log('...Ask for re-crawling in case of: 1. name resolving error, 2. timeout, 3. connection reset');
            return true;
        }
        return false;
    },

    onAllFinished: function() {
        console.log('Pictures of all hotels have been crawled & saved');


    }
});

var text = fs.readFileSync('/Users/zhongjie/Desktop/node/db/exportToSql/zoomlevel12.txt');

        var result  = null;
        let itemRegexp  = /qw\-(.+?)-kl/img;
        while ((result = itemRegexp.exec(text)) != null ) {
            console.log(result[1]);
            let str  = `insert into att_rtree_0 select id, loc_lng, loc_lng, loc_lat, loc_lat from sim_pois where oid = '${result[1]}'`;
            noDB.run(str);
        }


    crawler.enqueueRequest({
                url: url,
                'Accept-Language': requestLanguage,
                id: hotelId,
                URLType: 'image',
                size: 'o'
            },1,true);
















