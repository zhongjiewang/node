#!/usr/bin/env node
'use strict';

const userAgent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36';

const crawlerDatabase = 'mongodb://localhost:27017/tripadvisor',
    hotelLinksCollName = 'hotelLinks',
    hotelsCollName = 'hotelDetails';

const requestLanguage = 'en-US;q=0.8,zh-CN;q=0.2';

var Crawler = require('js-crawler'),
    mongoClient = require('mongodb').MongoClient,
    co = require('co'),
    _ = require('underscore'),
    url = require('url'),
    log4js = require('log4js'),
    AsyncStreamer = require('async-streamer'),
    path = require('path');

var temppath = path.join(__dirname,'/log');

log4js.configure({
  appenders: [
    { type: 'console' },
    { type: 'file', filename: `${temppath}/tripadvisor/hotel/hotelDetailsCrawler.log` }
  ]
});

log4js.replaceConsole();

// to prevent from aborting streamers before completion
var hotelsToComplete = [];
var crawlingDone = false;

var crawler = null;
var asyncStreamer = new AsyncStreamer({
    url: crawlerDatabase,
    collection: hotelsCollName
})
.start();

/* -------------------- url decryption function excerpted from tripAdivisor -------------------- */
function getOffset(a){if(a>=97&&a<=122){return a-61}if(a>=65&&a<=90){return a-55}if(a>=48&&a<=71){return a-48}return -1}function asdf(d){var g={"":["&","=","p","6","?","H","%","B",".com","k","9",".html","n","M","r","www.","h","b","t","a","0","/","d","O","j","http://","_","L","i","f","1","e","-","2",".","N","m","A","l","4","R","C","y","S","o","+","7","I","3","c","5","u",0,"T","v","s","w","8","P",0,"g",0],q:[0,"__3F__",0,"Photos",0,"https://",".edu","*","Y",">",0,0,0,0,0,0,"`","__2D__","X","<","slot",0,"ShowUrl","Owners",0,"[","q",0,"MemberProfile",0,"ShowUserReviews",'"',"Hotel",0,0,"Expedia","Vacation","Discount",0,"UserReview","Thumbnail",0,"__2F__","Inspiration","V","Map",":","@",0,"F","help",0,0,"Rental",0,"Picture",0,0,0,"hotels",0,"ftp://"],x:[0,0,"J",0,0,"Z",0,0,0,";",0,"Text",0,"(","x","GenericAds","U",0,"careers",0,0,0,"D",0,"members","Search",0,0,0,"Post",0,0,0,"Q",0,"$",0,"K",0,"W",0,"Reviews",0,",","__2E__",0,0,0,0,0,0,0,"{","}",0,"Cheap",")",0,0,0,"#",".org"],z:[0,"Hotels",0,0,"Icon",0,0,0,0,".net",0,0,"z",0,0,"pages",0,"geo",0,0,0,"cnt","~",0,0,"]","|",0,"tripadvisor","Images","BookingBuddy",0,"Commerce",0,0,"partnerKey",0,"area",0,"Deals","from","\\",0,"urlKey",0,"'",0,"WeatherUnderground",0,"MemberSign","Maps",0,"matchID","Packages","E","Amenities","Travel",".htm",0,"!","^","G"]};var b="";for(var a=0;a<d.length;a++){var h=d.charAt(a);var e=h;if(g[h]&&a+1<d.length){a++;e+=d.charAt(a)}else{h=""}var f=getOffset(d.charCodeAt(a));if(f<0||typeof g[h][f]=="String"){b+=e}else{b+=g[h][f]}}return b}
/* -------------------- url decryption function excerpted from tripAdivisor -------------------- */

function htmlUnescape(s) {
    return s.replace(/&quot;/g, '"').replace(/&rArr;/g, '⇒').replace(/&hellip;/g, '…')
        .replace(/&amp;/ig, '&').replace(/&mdash;/ig, '—').replace(/&#[0-9]+?;/g, function(m){
            return String.fromCharCode(/^&#([0-9]+?);$/.exec(m)[1]);
        });
}

function parseEmailPage(content) {
    let id = /name="detail" value="(.+?)"/g.exec(content)[1];
    let email = /name="receiver" value="(.+?)"/g.exec(content)[1];
}

function parseAndStreamHotel(content, link) {
    let index = content.indexOf('<h1 id="HEADING" property="name" class="heading_name    limit_width_800">');
    
    if (index == -1) {

        console.log('index is -1')
        console.log(link);
        console.log(content);
    }


    let narrowed = content.substring(index);

    let hotel = {
        crawler: 'tripAdvisorEnHotelDetailsCrawler',
        source: 'tripAdvisor.com',
        country: 'jp',
        language: 'en',
        href: link,
        crawledAt: new Date()
    };
    console.log(`--link1 ---${link}`);

    hotel.id = /^.+?\-d(.+?)\-.+?$/g.exec(link)[1];
    console.log(`---id ${hotel.id}`);
    var t = /<div class="heading_height"><\/div>([^]+?)<\/h1>/img.exec(narrowed);
    console.log('test t');
    if(t === null) {
        console.log('t is null');
        console.log(narrowed.substring(0,200));
        // return;
    }
    
    var s = t[1].replace(/\n/g, '');

    hotel.name = htmlUnescape(s);
    let matches = /<span class="localNameValue">(.+?)<\/span>/mg.exec(narrowed);
    if (matches) hotel.localName = htmlUnescape(matches[1].trim());
    matches = /<img class="sprite\-rating_cl_gry_fill rating_cl_gry_fill.+?alt="(.+?) of 5"/mg.exec(narrowed);
    if (matches) hotel.class = parseFloat(matches[1]);
    matches = /<span class="tabs_descriptive_text">([^]+?)<\/span>/img.exec(narrowed);
    if (matches) hotel.description = htmlUnescape(matches[1].replace(/\n/g, '').replace(/<[^>]+?>/g, ' ')).replace(/ +/g, ' '); 
    let addressSection = narrowed.substring(narrowed.indexOf('<address class="additional_info adr"'));
    addressSection = addressSection.substring(0, addressSection.indexOf('</address>')).replace(/\n/g, '').replace(/<[^>]+?>/g, '').trim();
    let addrArray = addressSection.split(': ');
    if (addrArray.length >= 2) hotel.address = htmlUnescape(addrArray[1]).split(', ');
    matches = /<span class="localAddressValue">(.+?)<\/span><\/span>/mg.exec(narrowed);
    if (matches) hotel.localAddress = htmlUnescape(matches[1].replace(/<[^>]+?>/g, ' ').trim());
    matches = /&center=(.+?)&maptype=roadmap/ig.exec(content);
  
    console.log(`--link2 ---${link}`);
    if (matches) hotel.geoPosition = matches[1].split(',');
    let idx = narrowed.indexOf('<div class="ui_icon phone fl icnLink"></div>');
    if (idx >= 0) {
        let phoneSection = narrowed.substring(idx);
        phoneSection = phoneSection.substring(0, phoneSection.indexOf('</script>'));
        let document = {
            'phone#': null,
            write: function(s) {
                this['phone#'] = s;
            }
        };
        eval(/function escramble[^]+?escramble.+?\(\)/mg.exec(phoneSection)[0]);
        if (document['phone#']) hotel.telephone = document['phone#'];
    }
    
    let itemsToRetrieve = [];
    idx = narrowed.indexOf('<div class="ui_icon email fl icnLink"></div>');
    if (idx >= 0) {
        itemsToRetrieve.push('email');
        hotelsToComplete.push(hotel.id);
        let emailSection = narrowed.substring(idx);
        emailSection = emailSection.substring(0, emailSection.indexOf('<script>'));
        let showEmailHotelOverlay = function (a, b, c, d) {
            let request = require('request');
            let options = {
                url: 'https://www.tripadvisor.com/EmailHotel',
                'Accept-Language': requestLanguage,
                headers: {
                    'User-Agent': userAgent
                },
                qs: {
                    detail: a,
                    isOfferEmail: b,
                    overrideOfferEmail: c,
                    contactColumn: d
                }
            };
            let retrieveEmail = function(error, response, body) {
                if (response && _.contains([200, 400, 404], response.statusCode)) {
                    if (response.statusCode === 200) {
                        hotel.email = /name="receiver" value="(.+?)"/g.exec(body)[1];
                        console.log('The email of %s was set', hotel.name);
                    }
                    itemsToRetrieve.splice(itemsToRetrieve.indexOf('email'), 1);
                    if (itemsToRetrieve.length === 0) {
                        // console.log(hotel);
                        asyncStreamer.commit(hotel);
                        console.log('Items retrieving of %s were completed and committed to stream', hotel.name);
                        hotelsToComplete.splice(hotelsToComplete.indexOf(hotel.id), 1);
                        if (crawlingDone && hotelsToComplete.length === 0) {
                            asyncStreamer.stop();
                            console.log('All hotels were completed and streamed');
                        }
                    }
                }
                else {
                    request(options, retrieveEmail);
                    console.log('Unexpected error happened when retrieve the email of %s and retried', hotel.name);
                }
            };
            request(options, retrieveEmail);
        }
        eval(/showEmailHotelOverlay\(.+?\);/mg.exec(emailSection)[0]);
        console.log('%s has email and requested for retrieving', hotel.name);
    }
    let ratingAndReviewsSection = narrowed.substring(narrowed.indexOf('<div class="heading_ratings">'));
    ratingAndReviewsSection = ratingAndReviewsSection.substring(0, ratingAndReviewsSection.indexOf('<div class="popRanking popIndexValidation'));
    matches = /<img class="sprite\-rating_rr_fill rating_rr_fill.+?content="(.+?)">/mg.exec(ratingAndReviewsSection);
    if (matches) hotel.rating = parseFloat(matches[1]);
    matches = /<a class="more taLnk".+?content='(.+)'>/.exec(ratingAndReviewsSection);
    if (matches) hotel.reviews = parseInt(matches[1].replace(/,/g, ''));
    matches = /<span class="test taLnk hvrIE6"[^]+?'aHref':'(.+?)'.+?>/img.exec(narrowed);
    if (matches) {
        itemsToRetrieve.push('website');
        if (!_.contains(hotelsToComplete, hotel.id)) hotelsToComplete.push(hotel.id);
        let websiteUrl = url.resolve(link, asdf(matches[1]));
        let request = require('request');
        let options = {
            url: websiteUrl,
            'Accept-Language': requestLanguage,
            encoding: 'utf-8',
            followRedirect: false,
            headers: {
                'User-Agent': userAgent
            },
        };
        let retrieveWebsite = function(error, response, body) {
            if (response && _.contains([302, 404], response.statusCode)) {
                if (response.statusCode === 302) {
                    hotel.website = response.headers.location.replace(/#_=_/g, '');
                    console.log('The website of %s was set', hotel.name);
                }
                itemsToRetrieve.splice(itemsToRetrieve.indexOf('website'), 1);
                if (itemsToRetrieve.length === 0) {
                    // console.log(hotel);
                    asyncStreamer.commit(hotel);
                    console.log('Items retrieving of %s were completed and committed to stream', hotel.name);
                    hotelsToComplete.splice(hotelsToComplete.indexOf(hotel.id), 1);
                    if (crawlingDone && hotelsToComplete.length === 0) {
                        asyncStreamer.stop();
                        console.log('All hotels were completed and streamed');
                    }
                }
            }
            else {
                request(options, retrieveWebsite);
                console.log('Unexpected error happened when retrieve the website of %s and retried', hotel.name);
            }
        };
        request(options, retrieveWebsite);
        console.log('%s has website and requested for retrieving', hotel.name);
    } else {
        // console.log(hotel);
        asyncStreamer.commit(hotel);
        console.log('%s has neither website nor email, directly committed to stream', hotel.name);
    }
}

crawler = new Crawler()
.configure({
    ignoreRelative: false, 
    depth: 1,
    userAgent: userAgent,
    maxConcurrentRequests: 10,
    oblivious: true,
    enableTimeOut: true,
    shouldCrawl: function(url) {
        return true;
    },
    onSuccess: function(page) {
        if (page.url === page.actualUrl) {
            console.log(`crawlering response url ${page.url} `);
            parseAndStreamHotel(page.body, page.url);
        }  else {
            console.log('%s was redirected, the related hotel might have been removed');
        }
    },
    onFailure: function(postmortem) {
        console.log('Failed to crawl %s (%s)', postmortem.url, postmortem.status? `HTTP: ${postmortem.status}` : `OTHER: ${postmortem.error}`);
        // if (postmortem.status && [404].indexOf(postmortem.status) < 0) {
        //  console.log('...Ask for re-crawling when possibily recoverable failure/error returned from web server', url);
        //  return true;
        // }
        // if (postmortem.error && ['EAI_AGAIN', 'ETIMEDOUT', 'ECONNRESET', 'ENOTFOUND'].indexOf(postmortem.error.code) >= 0) {
        //  console.log('...Ask for re-crawling in case of: 1. name resolving error, 2. timeout, 3. connection reset');
        //  return true;
        // }
        // return false;
    },
    onAllFinished: function() {
        console.log('All hotel details have been crawled');
        crawlingDone = true;
        if (crawlingDone && hotelsToComplete.length === 0) {
            asyncStreamer.stop();
            console.log('All hotels were completed and streamed');
        }
    }
});

co(function*() {
    let db = yield mongoClient.connect(crawlerDatabase);
    // let linksColl = db.collection('taleHots'hotelLinksCollName);
    let linksColl = db.collection(hotelLinksCollName);
    let records = yield linksColl.find(/*{language: 'en'}*/{}, {url: true}).toArray();
    console.log('%d hotels to crawl', records.length);
    yield db.close();
    crawler.crawl();
    
    // let tempUrl = 'https://www.tripadvisor.com/Hotel_Review-g298224-d8004649-Reviews-Hyatt_Regency_Naha_Okinawa-Naha_Okinawa_Prefecture_Kyushu_Okinawa.html';
    // // 'https://www.tripadvisor.com/Hotel_Review-g298224-d1509802-Reviews-Naha_Tokyu_REI_Hotel-Naha_Okinawa_Prefecture_Kyushu_Okinawa.html';
 //                      // https://www.tripadvisor.com/Hotel_Review-g298224-d1094112-Reviews-BEST_WESTERN_Naha_Inn-Naha_Okinawa_Prefecture_Kyushu_Okinawa.html
    // crawler.enqueueRequest({
    //      url: tempUrl,
    //      'Accept-Language': requestLanguage
    //  });

    for (let record of records) {
        crawler.enqueueRequest({
            url: record.url,
            'Accept-Language': requestLanguage
        });
    }
})
.catch(err => { console.error(err.stack); });




























