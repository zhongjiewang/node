
// var page = require('webpage').create();
// var url2 = 'http://www.baidu.com/';
// const url1 = 'http://example.com';
// const url2 = 'http://www.runoob.com';

// var url2 = 'https://www.tripadvisor.com/Hotel_Review-g298566-d1830576-Reviews-The_St_Regis_Osaka-Osaka_Osaka_Prefecture_Kinki.html';
// var page = require('webpage').create();
// page.open(url2, function(status) {
//   console.log("Status: " + status);
//   if(status === "success") {

//     if(status === "success") {
//         page.render('example.png');
//     }
//         // console.log(page);
//         var title = page.evaluate(function() {
//             console.log('-------------');
//             console.log(document.toString());

//             return document.body;
//         });

//         // console.log(document.toString());

//         console.log(title.toString());
//   }

//   // phantom.exit();
// });

// page.onConsoleMessage = function(msg) {
//   console.log('Page title is ' + msg.toString());
// };


"use strict";
var url2 = 'http://localhost:3333/geos/views/view-geo.client.view.html';
// var url2 = 'https://www.tripadvisor.com/Hotel_Review-g298566-d1094561-Reviews-Hotel_Brighton_City_Osaka_Kitahama-Osaka_Osaka_Prefecture_Kinki.html';

var webpage = require('webpage'), page = webpage.create();
var fs = require('fs');
page.viewportSize = { width: 1024, height: 800 };
page.clipRect = { top: 0, left: 0, width: 1024, height: 800 };
page.settings = {
    javascriptEnabled: true,
    loadImages: true,
    webSecurityEnabled: false,
    userAgent: 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.137 Safari/537.36 LBBROWSER'
    //要指定谷歌ua,我用火狐无法浏览
};

// 对于当前页面的一些配置项。此API必须在 page.open()调用之前设置，否则不会起作用。以下是配置项：
// * javascriptEnabled 

page.open(url2, function(status) {

    console.log(status);

    if (status === "success") {
       

            page.evaluateAsync(function () {
                
                // window.onload = function (){
                //     console.log('+++++++++++++');
                //     return document.body.innerHTML;  
                // } 

                function waite (){
                    console.log($('#main').html());
                    // console.log(document.body.innerHTML);
                }

                setTimeout(function (){
                    waite();

                },10*1000);

            });

            // page.evaluateAsync()。
            // page.includeJs('https://apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js', function() {
            // page.evaluate(function() {
            // // console.log(page.content);

            //     // lastest version on the web
            //     // console.log($('#d011002'));
            //     // console.log($('#main').html());
            //     // console.log("$(\"span.version\").text() -> " + $("span.version").text());
                
            // });
            //     phantom.exit(0);
            // });

        // console.log(page.content);

        } else {

      // phantom.exit(1);
    }
});

page.onLoadFinished = function () {
    console.log('finished-------------');
    // console.log(page.content);
}

page.onResourceRequested = function (req) {
                // console.log('requested: ' + JSON.stringify(req, undefined, 4));
    }; 
 
    page.onResourceReceived = function (res) {
                    // console.log('received: ' + JSON.stringify(res, undefined, 4));
                    // console.log(page.content);
                    // console.log(page.document);
            }; 


// function waitFor(testFx, onReady, timeOutMillis) {
//     var maxtimeOutMillis = timeOutMillis ? timeOutMillis : 3000, //< Default Max Timout is 3s
//         start = new Date().getTime(),
//         condition = false,
//         interval = setInterval(function() {
//             if ( (new Date().getTime() - start < maxtimeOutMillis) && !condition ) {
//                 // If not time-out yet and condition not yet fulfilled
//                 condition = (typeof(testFx) === "string" ? eval(testFx) : testFx()); //< defensive code
//             } else {
//                 if(!condition) {
//                     // If condition still not fulfilled (timeout but condition is 'false')
//                     console.log("'waitFor()' timeout");
//                     phantom.exit(1);
//                 } else {
//                     // Condition fulfilled (timeout and/or condition is 'true')
//                     console.log("'waitFor()' finished in " + (new Date().getTime() - start) + "ms.");
//                     typeof(onReady) === "string" ? eval(onReady) : onReady(); //< Do what it's supposed to do once the condition is fulfilled
//                     clearInterval(interval); //< Stop this interval
//                 }
//             }
//         }, 250); //< repeat check every 250ms
// };


// var system = require('system');
// if (system.args.length === 1) {
//     console.log('Try to pass some args when invoking this script!');
// } else {
//     system.args.forEach(function (arg, i) {
//             console.log(i + ': ' + arg);
//     });
// }


// var page = require('webpage').create();
// page.open(url2, function(status) {
//   var title = page.evaluate(function() {
//     console.log(document);
//     console.log('-------------');
//     return document.title;
//   });
//   console.log('Page title is ' + title);
//   phantom.exit();
// });


// var page = require('webpage').create();
// page.onConsoleMessage = function(msg) {
//   console.log('Page title is ' + msg);
// };
// page.open(url2, function(status) {
//   page.evaluate(function() {
//     console.log(document.title);
//   });
//   phantom.exit();
// });



// "use strict";
// var system = require('system');
// if (system.args.length === 1) {
//     console.log('Try to pass some args when invoking this script!');
// } else {
//     system.args.forEach(function (arg, i) {
//             console.log(i + ': ' + arg);
//     });
// }
// phantom.exit();





















































