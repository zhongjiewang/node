#!/usr/bin/env node
'use strict';

const userAgent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36';
// const crawlerDatabase = 'mongodb://localhost:27017/tripadvisor',
//     restaurantsCollName = 'restaurantDetailsDuan';
//     rootPathOfImages = '/Users/zhongjie/Desktop/SavePicture/1ap/';


const crawlerDatabase = 'mongodb://localhost:27017/crawler',
    restaurantsCollName = 'restaurants';
const  writePath = '/galleries/tripadvisor.com/restaurantConvert/';

var  mongoClient = require('mongodb').MongoClient,
    co = require('co'),
    AsyncStreamer = require('async-streamer'),
    fs = require('fs');

const onlineCollName = 'restaurantsOnline12';

var asyncStreamer = new AsyncStreamer({
    url: crawlerDatabase,
    collection: onlineCollName
}).start();

var hasNO = 0;
var hasYES = 0;
co(function*() {
    let db = yield mongoClient.connect(crawlerDatabase);
    let linksColl = db.collection(restaurantsCollName);
    let r = yield linksColl.find({reviews:{$ne:null}}).toArray();
    
    console.log('r----',r.length);
    r.sort((a,b) => {
        return b.reviews - a.reviews;
    })



    var spliceArr = r.splice(0,120000);

    console.log(spliceArr.length);

    for (let i = 0; i < spliceArr.length; i++) {
        let res = spliceArr[i];
        console.log(res.id);
        asyncStreamer.commit(spliceArr[i]);
    }



    // for (let record of records) {
    //     let id = `${record.id}`;
    //     let path = `${writePath}${id[0]}/${id}.jpg`;

    //     console.log(path);
    //     if (!fs.existsSync(path)) {
    //         hasNO ++;
    //         console.log('hasNO-----',hasNO);
    //     }else {
    //         hasYES ++;
    //         console.log('hasYES----',hasYES);
    //     };
    // }

})
.catch(err => { console.error(err.stack); });



























































