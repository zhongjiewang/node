#!/usr/bin/env node
'use strict';


var fs = require('fs');
var path = require('path');
var sharp = require('sharp');


// const rootPath = '/Users/zhongjie/Desktop/SavePicture/1ap/';
//       writePath = '/Users/zhongjie/Desktop/SavePicture/1attimage/';

// const rootPath = '/galleries/tripadvisor.com/restaurants/',
//       writePath = '/galleries/tripadvisor.com/restaurantConvert/';
const rootPath = '/galleries/tripadvisor.com/attractions/',
      writePath = '/galleries/tripadvisor.com/tempAttractions/';
const thumb = 'thumb';
const full = 'full';

console.log("查看 /tmp 目录");
var firstNum = '1';
var temp = 0;

//tripid--10000694--oid-at989936-eu
let str1 = fs.readFileSync('endFileIdAndOid.txt').toString();
let Regexp1 = /tripid--(.+?)--oid-(.+?)-eu/img;
let matches1 = null;
let set1 = new Set();
let arr1 = [];
while ((matches1 = Regexp1.exec(str1)) != null ) {
    // console.log(matches1[1]);
    // set1.add(matches1[1]);
    arr1.push({tripId: matches1[1], oid: matches1[2]});
}

console.log(arr1.length);
console.log(arr1[0]);

for (let item of arr1) {
  let path = `${rootPath}${item.tripId}`;
  let end = (item.tripId[0] === firstNum);
  
  if(end) {
      fs.readdir(path, function(err, files){
          if(files.length != 0) { 
                files.forEach(function (file){
                console.log(`--${item.tripId}----${file}`);
                let imagePath = `${path}/${file}`;
                // console.log(imagePath);
              
                sharp(imagePath)
                .toBuffer({}, function (err,data, info){
                    console.log(err);
                    console.log(`imagePath-${imagePath}-with-${info.width}--height-${info.height}-size-${info.size}`);
                });
            });
          };
      });
  }

}

// var sharpQRCodeImage = async function () {
//     await sharp('alipay2.png')
//          .extract({ left: 775, top: 200, width: 180, height: 180 })
//          .toFile('output.png', function(err) {
//               // Extract
//                 console.log('====',err);

//           });
// }





// fs.readdir(rootPath, function(err, files){
//    if (err) {
//        return console.error(err);
//    };

//    files.forEach(function (file){
//       let f = `${file}`;
//       // let end =  f[0] != 1 && f[0] != 8  && f.length < 20;
//       // let end = (f[0] === firstNum);
//       let end = true;
//       if(end) {      
//        let idpath = `${rootPath}${file}`;
//        console.log(idpath);
//        temp ++;
//        if(file != '.DS_Store'){ 
//             fs.readdir(idpath, function(err, idfiles){
//                 let oid = changeidToOid(file);
//                 console.log(`${file}-oid-${oid}----${idfiles.length}---count`);
//                 if(idfiles[0]){
//                   for (let  i = 0; i < idfiles.length; i++) {
//                       if(i <= 9) {
//                           let imgPath = `${idpath}/${idfiles[i]}`;
//                           //console.log('imgpath',imgPath);
//                           fs.readFile(imgPath, function (err, data) {
//                               console.log('read error',err);
//                               let writepath = `${writePath}${full}/${oid}-${i+1}.jpg`;
//                               //console.log('writePath',writepath);
//                               writeFile(writepath, data, {encoding : null});
//                           });
//                       };
//                   };
//                 }else{
//                   // console.log('this id not has image',file);
//                 }
//             });

//        };
  
//       }
//    });

//     console.log(`count ---${files.length}`);
//     console.log(`${firstNum}-----count ${temp}`);
// })

var writeImageSuccessCount = 0;
function writeFile(path, data, options, hotelId) {
    if (!fs.existsSync(path)) {
        fs.writeFile(path, data, options,function(err){
            if (!err) { writeImageSuccessCount ++ 
                console.log(`writecount --${writeImageSuccessCount}`);
            };
        });
    }else {
        console.log(`fs existes already -${path}`);
    }
};

// 非 1 非 8的 15840
// 1-----count 11931


function changeidToOid (tempid) {
  let id = Number(tempid).toString(16);
  let oid =  `at${(Array(6).join(0) + id).slice(-6)}`;
  return oid
}


































































































