#!/usr/bin/env node
'use strict';

const userAgent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36';
// const crawlerDatabase = 'mongodb://localhost:27017/tripadvisor',
//     restaurantsCollName = 'restaurantDetailsDuan';
//     rootPathOfImages = '/Users/zhongjie/Desktop/SavePicture/1ap/';


const crawlerDatabase = 'mongodb://localhost:27017/crawler',
    restaurantsCollName = 'restaurants';
const  readPath = '/galleries/tripadvisor.com/restaurantConvert/total/';
// const  writePath = '/galleries/tripadvisor.com/restaurantConvert/selectOnline/';


var  mongoClient = require('mongodb').MongoClient,
    co = require('co'),
    AsyncStreamer = require('async-streamer'),
    fs = require('fs');

const onlineCollName = 'restaurantsOnline';

var asyncStreamer = new AsyncStreamer({
    url: crawlerDatabase,
    collection: onlineCollName
}).start();

var hasNO = 0;
var hasYES = 0;
co(function*() {
    let db = yield mongoClient.connect(crawlerDatabase);
    let linksColl = db.collection(onlineCollName);
    let r = yield linksColl.find({},{id:1}).toArray();
    
    console.log('r----',r.length);

    let temp = r.splice(30000,30000);
    for (let record of temp) {
        let id = `${record.id}`;
        let path = `${readPath}${id[0]}/${id}.jpg`;

        console.log(path);
        if (!fs.existsSync(path)) {
            hasNO ++;
            console.log('hasNO-----',hasNO);
        }else {
            hasYES ++;
            console.log('hasYES----',hasYES);
            fs.readFile(path, function (err, data) {
                if (err) {
                    console.log('read error');
                    return console.error(err);
                };
                let writePath = path.replace('total','selectOnline');
                console.log(writePath);
                writeFile(writePath, data, {encoding : null});
            });

        };
    }

})
.catch(err => { console.error(err.stack); });


var writeImageSuccessCount = 0;
function writeFile(path, data, options, id) {
    if (!fs.existsSync(path)) {
        fs.writeFile(path, data, options,function(err){
            if (!err) { 
                writeImageSuccessCount ++ 
                console.log('writeImageSuccessCount', writeImageSuccessCount);
            };
        });
    }else{
        console.log('already  exists');
    }
};


//hasYES---- 77734

























































