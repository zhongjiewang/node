#!/usr/bin/env node
'use strict';


const s = `
<div class="grayPhone sprite-grayPhone fl icnLink"></div>
<div class="fl">
<script>
<script>
<!--
function escramble_249(){
var a,b,c
a='011 '
b='540-'
a+='81 3-'
b+='3740'
c='4'
document.write(a+c+b)
}
escramble_249()
//-->
</script>;
`;

let document = {
    'phone#': null,
    write: function(s) {
        this['phone#'] = s;
    }
}

var phoneScript = /function escramble[^]+?escramble.+?\(\)/mg.exec(s)[0];
eval(phoneScript);
console.log(document['phone#']);

const s2 = `
<div class="grayEmail sprite-grayEmail fl icnLink"></div>
<div class="fl">
<span class="taLnk hvrIE6" onclick="                                  ta.trackEventOnPage('hr_back_to_h_bar', 'BL_EMAIL' );
                 ta.trackEventOnPage(           'Hotel_Review'
   ,'EMAIL|text|3||', '320581', 0, false);
              ; ta.trackEventOnPage('BusinessListings', 'BL_CLICK', 'BL_LINKS');; ta.util.cookie.setPIDCookie(14514); ta.common.flyout.showEmailHotelOverlay(320581, 'false', '', '3');">
`;

var showEmailHotelOverlay = function (a, b, c, d) {
    console.log(a, b, c, d);
    let request = require('request');
    let options = {
        url: 'https://www.tripadvisor.com/EmailHotel',
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36'
        },
        qs: {
            detail: a,
            isOfferEmail: b,
            overrideOfferEmail: c,
            contactColumn: d
        }
    }
    request(options, function(error, response, body) {
        let email = /name="receiver" value="(.+?)"/g.exec(body)[1];
        console.log(email);
    });
}

eval(/showEmailHotelOverlay\(.+?\);/.exec(s2)[0]);





/*
let code = `
    macroPhone.speak('Hello, ' + name + '!', jobname);
`;
let name = 'Zhongjie';
let jobname = 'node.js';
let macroPhone = {
    speak: (msg, job) => {
        console.log(msg,job);
        console.log(job);
    }
};
eval(code);
*/




















