#!/usr/bin/env node
'use strict';

var fs = require('fs');
var path = require('path');
var Crawler = require('js-crawler');
const userAgent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36',
      requestLanguage = 'en-US;q=0.8,zh-CN;q=0.2';
var co = require('co');


// const crawlerDatabase = 'mongodb://localhost:27017/tripadvisor',
//     hotelImageWebPageLinks = 'hotelImageWebPageLinks',
//     rootPathOfImages = '/Users/zhongjie/Desktop/SavePicture/1ap/';


const crawlerDatabase = 'mongodb://localhost:27017/crawler',
    hotelLinksCollName = 'tempHotelLinks',
    hotelImageWebPageLinks = 'tempHotelImageWebPageLinks',
    rootPathOfImages = '/galleries/tripadvisor.com/hotels/';


var crawler = new Crawler()
.configure({
    ignoreRelative: false, 
    depth: 1,
    userAgent: userAgent,
    maxConcurrentRequests: 30,
    oblivious: true,
    enableTimeOut: true,
    shouldCrawl: function(url) {
        return true;
    },
    onSuccess: function(page) {
        console.log(`response -${page.actualUrl}`)
        if (page.options.URLType === 'web'){
            parsePhotosWebPageAndRequest(page.actualUrl, page.options.id, page.body, page.options.URLType);
        
        }else if (page.options.URLType === 'image'){
            saveImage(page.actualUrl, page.options.id, page.body, rootPathOfImages);
        }
    },
    onFailure: function(postmortem) {
        console.log('Failed to crawl %s (%s)', postmortem.url, postmortem.status? `HTTP: ${postmortem.status}` : `OTHER: ${postmortem.error}`);
        if (postmortem.status && [404, 403].indexOf(postmortem.status) < 0) {
            console.log('...Ask for re-crawling when possibily recoverable failure/error returned from web server', url);
            return true;
        }
        if (postmortem.error && ['EAI_AGAIN', 'ETIMEDOUT', 'ECONNRESET', 'ENOTFOUND'].indexOf(postmortem.error.code) >= 0) {
            console.log('...Ask for re-crawling in case of: 1. name resolving error, 2. timeout, 3. connection reset');
            return true;
        }
        if (postmortem.status && postmortem.status === 403) {
            if (postmortem.options.URLType === 'image') {
                if (postmortem.options.size === 'o') {
                    crawler.enqueueRequest({
                        url: postmortem.url.replace(/photo-.{1}/im,'photo-s'),
                        'Accept-Language': requestLanguage,
                        id: postmortem.options.id,
                        URLType: 'image',
                        size: 's'
                    },1,true);
                    console.log(`hotelid-${postmortem.options.id}request again with photo-s-${postmortem.url}`);
                } else {
                    // crawler.enqueueRequest(options);
                    console.log('...Already request the small image, stop the crawling efforts');
                }
            }
        }
        return false;
    },

    onAllFinished: function() {
        console.log('Pictures of all hotels have been crawled & saved');

    }
});

crawler.crawl();

// console.log(crawler);


// var temppath = path.join(__dirname,'/templog/tripadvisorHotelImagesCrawler2.log');

var temppath = '/repos.git/webCrawler/zhongjie/log/tripadvisorHotelImagesCrawler2.log';

var content =  fs.readFileSync(temppath);

// console.log(content.toString());
let str = content.toString();
var result = null;
var reg = /parse web page photeos section url--(.+?)--type/img;
var hotels = [];



// co(function*() {

function test () {


   while ((result = reg.exec(str)) != null) {

    let id = result[1].match(/-d(.+?)-/);
    // console.log(
    crawler.enqueueRequest({
        url: result[1],
        'Accept-Language': requestLanguage,
        URLType: 'web',
        id: id[1]
    });
}
}

setTimeout(test, 0);
// })
// .catch(err => { console.error(err.stack); });







// console.log(hotels.length);

function parseWebWhenOneBigImageAndRequest (link, hotelId, content) {

    let reg = /"big_photo" style=".+?src="(.+?)" alt/img;
    let imageurl = reg.exec(content);
    console.log(imageurl[1]);
    crawler.enqueueRequest({
        url: imageurl[1].replace(/photo-.{1}/im,'photo-o'),
        'Accept-Language': requestLanguage,
        id: hotelId,
        URLType: 'image',
        size: 'o'
    },1,true);
}



function saveImage(url, hotelId, bufferContent, rootPath){

    let hotelpath = `${rootPathOfImages}${hotelId}/`;
    console.log(hotelpath);
    let t  = /photo-(.+)/mg.exec(url);
    let imageName = null;
    if (t != null) {
        imageName = t[1].replace(/\//g,'-');
    }else {
        console.log(`save video-t -id-${hotelId} image url ${url}`);
        let video  = /video-(.+)/mg.exec(url);
        if (video) {
            imageName = video[1].replace(/\//g,'-');
        };
    };
    
    fsMake(hotelpath)
    .then( (path) => {
        writeFile(`${path}${imageName}`, bufferContent, {encoding : null}, hotelId);
    });
}


function fsMake (path) {
   let  k =   new Promise (function (resolve, reject) {
                fs.stat(path,function (err, stats) {
                    if(!err) {
                        resolve(path) ;
                    }else {
                        fs.mkdir (path, function(err){
                            if(!err) resolve(path);
                        })
                    }
                });
            }); 

   return k;
};
var writeImageSuccessCount = 0;
function writeFile(path, data, options, hotelId) {
    if (!fs.existsSync(path)) {
        fs.writeFile(path, data, options,function(err){
            if (!err) { writeImageSuccessCount ++ 
                console.log(`count --${writeImageSuccessCount}`);
            };
        });
    };
};



















