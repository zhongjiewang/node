#!/usr/bin/env node
'use strict';

const userAgent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36';

const crawlerDatabase = 'mongodb://localhost:27017/crawler',
    attractionLinksCollName = 'attractionLinks',
    attractionsCollName = 'attractions';

const requestLanguage = 'en-US;q=0.8,zh-CN;q=0.2';

// const folderToStore = '/galleries/tripadvisor.com/attractions/';
const folderToStore = '/Users/zhongjie/Desktop/SavePicture/1attimage/';


var Crawler = require('js-crawler'),
    mongoClient = require('mongodb').MongoClient,
    co = require('co'),
    _ = require('underscore'),
    url = require('url'),
    log4js = require('log4js'),
    fs = require('fs');

log4js.configure({
  appenders: [
    { type: 'console' },
    { type: 'file', filename: '/var/log/tourank/crawler.log' }
  ]
});

log4js.replaceConsole();

// to prevent from aborting streamers before completion
var crawlingDone = false;

var crawler = null;

function saveRequestedImage(content, id, name, size) {
    // if (name.indexOf('.') < 0) name += '.jpg';

    console.log(' begin save request  images ');

    let pathName = `${folderToStore}${id}/${size}-${name}`;
    if (!fs.existsSync(pathName)) {
        fs.writeFileSync(pathName, content, {encoding: null});
        console.log('Image %s @ %s was saved as %s', name, id, pathName);
    }
}

function parseAndRequestImgsAndNextPage(content, link, id, crawler) {

    console.log('request images and next page --------');

    let index = content.indexOf('<div class="photos" itemprop="video" itemscope itemtype="http://schema.org/VideoObject">');

    console.log(index);

    // parsing the new version of photo gallery design
    let narrowed = content.substring(content.indexOf('<div class="photos" itemprop="video" itemscope itemtype="http://schema.org/VideoObject">'));
    
    // console.log(narrowed.substring(0,10));
    let index1 = narrowed.indexOf('<ul>');
    console.log(index1);

    // narrowed = narrowed.substring(0, index1);
    

    // console.log(narrowed);

    // added for backward compatibility, like https://www.tripadvisor.com/LocationPhotoDirectLink-g303156-d1311146-i186714796-Tsurugaoka_Hachimangu_Shrine-Kamakura_Kanagawa_Prefecture_Kanto.html
    let matches = /<div class="pageRight pageArrow"><a onclick=".+?return ta\.servlet\.Photos\.handlePagedFilterOption\('(.+?)'\);"/mg.exec(narrowed);
    
    // console.log(matches);

    // process for common cases
    if (!matches) matches = /<img class="taLnk big_photo" [^>]+?onclick="return ta\.servlet\.Photos\.handlePagedFilterOption\('(.+?)'\);"/mg.exec(narrowed);
    // console.log(matches);
    console.log(url.resolve(link, matches[1]));

    if (matches) {
        crawler.enqueueRequest({
            url: url.resolve(link, matches[1]),
            'Accept-Language': requestLanguage,
            type: 'gallery',
            id: id
        }, 1, true);
        console.log('Next page link %s @ %s was parsed and issued', url.resolve(link, matches[1]), id);
    }
    
    matches = null;
    let imgRegEx = /<img class="taLnk big_photo"[^>]+?src="(.+?)"/mg;
    while (matches = imgRegEx.exec(narrowed)) {
        let orgImgLink = matches[1].replace(/photo\-s/g, 'photo-o');
        let imgName = /photo\-s\/(.+?)$/.exec(matches[1])[1].replace(/\//g, '_');
        if (imgName.indexOf('.') < 0) imgName += '.jpg';
        let opathName = `${folderToStore}${id}/o-${imgName}`;
        let spathName = `${folderToStore}${id}/s-${imgName}`;
        if (!fs.existsSync(opathName) && !fs.existsSync(spathName)) {
            crawler.enqueueRequest({
                url: orgImgLink,
                'Accept-Language': requestLanguage,
                type: 'image',
                size: 'o',
                id: id,
                name: imgName
            }, 1, true);
            console.log('Image link %s @ %s was parsed and issued', orgImgLink, id);
        }
    }
}

function parseAndRequestGalleryPage(content, link, id, crawler) {
    let narrowed = content.substring(content.indexOf('<div class="main_section photobar">'));
    narrowed = narrowed.substring(narrowed.indexOf('<div class="flexible_photo_frame">'));
    let matches = /<a [^>]+?href="(.+?)"/mg.exec(narrowed);
        

    let secondUrl =  url.resolve(link, matches[1]);
    console.log('secondUrl------------');
    console.log(secondUrl);


    if (matches) {
        crawler.enqueueRequest({
            url: url.resolve(link, matches[1]),
            'Accept-Language': requestLanguage,
            type: 'gallery',
            id: id
        }, 1, true);
        console.log('Gallery link %s @ %s was parsed and issued', url.resolve(link, matches[1]), id);
    }
}

crawler = new Crawler()
.configure({
    ignoreRelative: false, 
    depth: 1,
    userAgent: userAgent,
    maxConcurrentRequests: 6,
    oblivious: true,
    enableTimeOut: true,
    shouldCrawl: function(url) {
        return true;
    },
    onSuccess: function(page) {
        if (!page.options.type) {
            console.log('Processing attraction#%d: %s...', page.options.seq, page.options.id);
            console.log(page.actualUrl);
            parseAndRequestGalleryPage(page.body, page.actualUrl, page.options.id, this);
        } else if (page.options.type === 'gallery') {
            parseAndRequestImgsAndNextPage(page.body, page.actualUrl, page.options.id, this);
        } else {
            saveRequestedImage(page.body, page.options.id, page.options.name, page.options.size);
        }
    },
    onFailure: function(postmortem) {
        console.log('Failed to crawl %s (%s)', postmortem.url, postmortem.status? `HTTP: ${postmortem.status}` : `OTHER: ${postmortem.error}`);
        if (postmortem.status && [404, 403].indexOf(postmortem.status) < 0) {
            console.log('...Ask for re-crawling when possibily recoverable failure/error returned from web server', url);
            return true;
        }
        if (postmortem.error && ['EAI_AGAIN', 'ETIMEDOUT', 'ECONNRESET', 'ENOTFOUND'].indexOf(postmortem.error.code) >= 0) {
            console.log('...Ask for re-crawling in case of: 1. name resolving error, 2. timeout, 3. connection reset');
            return true;
        }
        // when unauthorized to access the original image, fail-over to the small one.
        if (postmortem.status && postmortem.status === 403) {
            if (postmortem.options.type === 'image') {
                let options = postmortem.options;
                if (options.size === 'o') {
                    let pathName = `${folderToStore}${options.id}/s-${options.name}`;
                    if (!fs.existsSync(pathName)) {
                        options.url = options.url.replace(/photo\-o/g, 'photo-s');
                        options.size = 's';
                        crawler.enqueueRequest(options, 1, true);
                        console.log('...Fail over to small image when unauthorized to access the original one');
                    }
                } else {
                    // crawler.enqueueRequest(options);
                    console.log('...Already request the small image, stop the crawling efforts');
                }
            }
        }
        return false;
    },
    onAllFinished: function() {
        console.log('Pictures of all attractions have been crawled & saved');
        setTimeout(function () {
            console.log('not exit');
        },30000);
    }
});

co(function*() {
    let db = yield mongoClient.connect(crawlerDatabase);
    let linksColl = db.collection(attractionLinksCollName);
    let records = yield linksColl.find({language: 'en'}, {url: true, id: true, d_reviews: true}).toArray();
    records.sort(function(a, b) {
        return b.d_reviews - a.d_reviews;
    });
    /*
    let taleAttColl = db.collection('taleAtts');
    let records = yield taleAttColl.find().toArray();
    */
    yield db.close();
    console.log('%d attractions to crawl', records.length);
    let count = 1;
    crawler.crawl();

    let attractionUrl = 'http://www.tripadvisor.cn/Attraction_Review-g1066443-d320625-Reviews-The_East_Gardens_of_the_Imperial_Palace_Edo_Castle_Ruin-Chiyoda_Tokyo_Tokyo_Prefe.html';

    crawler.enqueueRequest({
        url: attractionUrl,
        'Accept-Language': requestLanguage,
        id: 320625 
    });

//http://www.tripadvisor.cn/Attraction_Review-g1066443-d320625-Reviews-The_East_Gardens_of_the_Imperial_Palace_Edo_Castle_Ruin-Chiyoda_Tokyo_Tokyo_Prefe.html#photos;geo=1066443&detail=320625
    // for (let record of records) {
    //     if (!fs.existsSync(`${folderToStore}${record.id}`)) {
    //         fs.mkdirSync(`${folderToStore}${record.id}`);
    //     }
    //     crawler.enqueueRequest({
    //         url: record.url,
    //         'Accept-Language': requestLanguage,
    //         id: record.id,
    //         seq: count
    //     });
    //     count++;
    // }
})
.catch(err => { console.error(err.stack); });


//http://www.tripadvisor.cn/LocationPhotoDirectLink-g298484-d300366-i246557667-Red_Square_Krasnaya_ploshchad-Moscow_Central_Russia.html#246557667











