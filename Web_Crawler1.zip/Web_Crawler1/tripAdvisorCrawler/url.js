#!/usr/bin/env node
'use strict';


const phantom = require('phantom');
var url2 = 'https://www.tripadvisor.com/Hotel_Review-g298566-d598268-Reviews-Hotel_Monterey_Lasoeur_Osaka-Osaka_Osaka_Prefecture_Kinki.html';

const crawlerDatabase = 'mongodb://localhost:27017/tripadvisor';
const  hotelListCollName = 'dynamicHotelCollName';
const  hotelListImageColl = 'tempHotelLinksImage';
var   mongoClient = require('mongodb').MongoClient;
var count = 0;

var   AsyncStreamer = require('async-streamer');

var asyncStreamer = new AsyncStreamer({
    url: crawlerDatabase,
    collection: hotelListImageColl
}).start();

(async function() {
    const instance = await phantom.create();
    console.log('-----------');
    let db = await mongoClient.connect(crawlerDatabase);
    let linksColl = db.collection(hotelListCollName);
    let records = await linksColl.find().toArray();
    
    await db.close();
    
    let spliceArr = records.splice(0);
    console.log('%d professional hotels to crawl', spliceArr.length);
  
    for (let record of spliceArr) {
        console.log('start hotel id',record.id);
        let page = await instance.createPage();
        let  status = await page.open(record.url);
        console.log(record.id,status);
        if(status === 'success'){
            let  content = await page.property('content');
        //     console.log('get content success----------');
           await waiteForpage(record.id, page);
            count ++;
            console.log(count,'-------------');
        }
        page.close();
        console.log('close------');
    }
}());

// var count = 0;
function waiteForpage (id, pagelet) {
  return  pagelet.evaluate(function() {
            var a = document.getElementsByClassName('inView');
            return a[0].innerHTML;
    }).then(function(html){
        console.log(id,html);
        let match = /<img alt.+?src="(.+?)">/img.exec(html);
        console.log(match)
    });

}


// let str = 'http://aff.bstatic.com/images/hotel/max500/112/11250175.jpg';

// let imageid = /\/(\d+?).jpg/im.exec(str);

// console.log(imageid);
// var t = ['ew','tt'];

// console.log(t.indexOf('tt'));

// var r = 'dfe';

// if (r === ('ee' || 're' || 'dfe')) {

//     console.log('==========');
// }

//  var str = 'https://media-cdn.tripadvisor.com/media/photo-o/0e/69/ef/ae/photo6jpg.jpg';

//  var str1 = /photo-(.+)/mg.exec(str);

// console.log(str1);
//  let ar  = str1[1].replace(/\//g,'-');
// console.log(ar);

// let a  = parseInt("data-offset= 1380", 10); 


// console.log(a);

// // var str = "Visit W3School"; 
// // var patt = new RegExp("W3School","g");
// // var result;

// // result = /\d*$/img.exec("data-offset=1380");
// // console.log(result);

// // var str = 'https://www.tripadvisor.com/Hotels-g1023691-Nagato_Yamaguchi_Prefecture_Chugoku-Hotels.html';
// // var t1 = str.match(/-g\d+?-/im);
// // console.log(t1[0]);
// // var temp = str.replace(/-g\d+?-/im,`${t1[0]}oa30-`);
// // console.log(temp);
// // // while ((result = /=/img.exec("data-offset= 1380")) != null)  {
// // //   console.log(result);
// // //   console.log("<br />");
// // //   console.log(patt.lastIndex);
// // // }

// let i = 0

// while (i++ <= 5) {
//     if(i == 2) {
        
//         continue;
//     }
//     console.log(i);
// }
// var  AsyncStreamer = require('async-streamer');

// const crawlerDatabase = 'mongodb://localhost:27017/asyncStreamerTest',
//     hotelListCollName = 'hotelTest';


// var asyncStreamer = new AsyncStreamer({
//     url: crawlerDatabase,
//     collection: hotelListCollName
// }).start();
// console.log('url.js -----------');
// console.log(asyncStreamer);

//  for (let i = 0; i < 10; i++) {

//     let hotel = {
//         id: 1,
//         name: 'test'
//     }
//     // asyncStreamer.timeStamped = new Date();
//     asyncStreamer.commit(hotel);
//  }

// setTimeout(()=>{
//     asyncStreamer.stop();
// }, 5000)































