#!/usr/bin/env node
'use strict';

const userAgent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36';

// const phantom = require('phantom');
var url2 = 'https://www.tripadvisor.com/Hotel_Review-g298566-d598268-Reviews-Hotel_Monterey_Lasoeur_Osaka-Osaka_Osaka_Prefecture_Kinki.html';
const requestLanguage = 'en-US;q=0.8,zh-CN;q=0.2';


const crawlerDatabase = 'mongodb://localhost:27017/tripadvisor';
const  hotelListCollName = 'dynamicHotelCollName';
const  hotelListImageColl = 'tempHotelLinksImage222222';
var   mongoClient = require('mongodb').MongoClient;
var count = 0;
var distakeCount = 0;

var   AsyncStreamer = require('async-streamer');
var  Crawler = require('js-crawler');
var co = require('co');
var asyncStreamer = new AsyncStreamer({
    url: crawlerDatabase,
    collection: hotelListImageColl
}).start();

var count = 0;

function parseImageurl(link, id, content, urlType) {

//<meta property="og:image" content="http://ccm.ddcdn.com/ext/photo-s/02/98/3a/3d/filename-05-201-1-jpg.jpg"/>
    let match = /<meta property="og:image" content="(.+?)"\/>/img.exec(content);

    if (match) {
        let url  = match[1];
        let h = {
            id: id,
            href: link,
            url: url
        }
        asyncStreamer.commit(h);
        count ++;
        console.log(count,'---------------------');
    }else {
        console.log('not match ----',id, link);
    }

    // console.log(match[1]);

}

var crawler = new Crawler()
.configure({
    ignoreRelative: false, 
    depth: 1,
    userAgent: userAgent,
    maxConcurrentRequests: 30,
    oblivious: true,
    enableTimeOut: true,
    shouldCrawl: function(url) {
        return true;
    },
    onSuccess: function(page) {
        console.log(page.actualUrl);
        parseImageurl(page.actualUrl, page.options.id, page.body, this) 

    },
    onFailure: function(postmortem) {
        console.log('Failed to crawl %s (%s)', postmortem.url, postmortem.status? `HTTP: ${postmortem.status}` : `OTHER: ${postmortem.error}`);
        if (postmortem.status && [404].indexOf(postmortem.status) < 0) {
            console.log('...Ask for re-crawling when possibily recoverable failure/error returned from web server');
            return true;
        }
        if (postmortem.error && ['EAI_AGAIN', 'ETIMEDOUT', 'ECONNRESET', 'ENOTFOUND'].indexOf(postmortem.error.code) >= 0) {
            console.log('...Ask for re-crawling in case of: 1. name resolving error, 2. timeout, 3. connection reset');
            return true;
        }
        return false;
    },
    onAllFinished: function() {
        console.log('In total %d hotels have been crawled', hotelIds.length);
        asyncStreamer.stop();
    }
});

co(function*() {
    let db = yield mongoClient.connect(crawlerDatabase);
    let linksColl = db.collection(hotelListCollName);
    let records = yield linksColl.find().toArray();
    
    yield db.close();
    
    let spliceArr = records.splice(0);
    console.log('%d hotels to crawl', spliceArr.length);
    crawler.crawl();
    for (let record of spliceArr) {
        crawler.enqueueRequest({
            url: record.url,
            'Accept-Language': requestLanguage,
            URLType: 'photo-direct-link',
            id: record.id
        });
    }

    // logSave();
})
.catch(err => { console.error(err.stack); });
























