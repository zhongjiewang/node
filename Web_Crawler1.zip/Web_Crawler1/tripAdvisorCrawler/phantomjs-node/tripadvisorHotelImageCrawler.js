#!/usr/bin/env node
'use strict';

const phantom = require('phantom');
var url2 = 'https://www.tripadvisor.com/Hotel_Review-g298566-d598268-Reviews-Hotel_Monterey_Lasoeur_Osaka-Osaka_Osaka_Prefecture_Kinki.html';

const crawlerDatabase = 'mongodb://localhost:27017/tripadvisor';
const  hotelListCollName = 'dynamicHotelCollName';
const  hotelListImageColl = 'tempHotelLinksImage';
var   mongoClient = require('mongodb').MongoClient;
var count = 0;
var distakeCount = 0;

var   AsyncStreamer = require('async-streamer');

var asyncStreamer = new AsyncStreamer({
    url: crawlerDatabase,
    collection: hotelListImageColl
}).start();

(async function() {
    const instance = await phantom.create();
    console.log('-----------');
    let db = await mongoClient.connect(crawlerDatabase);
    let linksColl = db.collection(hotelListCollName);
    let records = await linksColl.find().toArray();

    let imageColl = db.collection(hotelListImageColl);
    let spliceArr = records.splice(400,600);
    console.log('%d professional hotels to crawl', spliceArr.length);
  
    for (let record of spliceArr) {
        console.log('start hotel id------',record.id);
        distakeCount ++;
        console.log('distakeCount',distakeCount);
        let result  = await imageColl.find({id:record.id},{'id':1}).toArray();
        if(result.length === 1){
            console.log('already crawler---------');
            continue;
        };
        console.log(record.url);
        let page = await instance.createPage();
        let  status = await page.open(record.url);
        console.log(record.id,status);
        if(status === 'success'){
            let  content = await page.property('content');
           await waiteForpage(record.id, record.url, page);
            count ++;
            console.log(count,'-------------');
        };
        page.close();
    }
}());

function waiteForpage (id, url, pagelet) {
  return  pagelet.evaluate(function() {
            var a = document.getElementsByClassName('inView');
            return a[0].innerHTML;
    }).then(function(html){
        let match = /<img alt.+?src="(.+?)">/img.exec(html);
        if(match){
            let hotelthum = {
                id:id,
                href: url,
                imageLink: match[1]
            }
            console.log('commit',id);
            asyncStreamer.commit(hotelthum);
        }else{
            console.log('not match', url);
        }
    });
}












