#!/usr/bin/env node
'use strict';

const userAgent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36';

const crawlerDatabase = 'mongodb://localhost:27017/tripadvisor',
     hotelListImageColl = 'tempRestaurantImageLinks',
     rootPathOfImages = '/Users/zhongjie/Desktop/SavePicture/1ap/';

//tempHotelimagelinks

// const crawlerDatabase = 'mongodb://localhost:27017/crawler',
//     hotelListImageColl = 'tempRestaurantImageLinks',
//     rootPathOfImages = '/galleries/tripadvisor.com/restaurantConvert/professional/';

const tripadvisorUrl = 'https://www.tripadvisor.com',
      requestLanguage = 'en-US;q=0.8,zh-CN;q=0.2';
var Crawler = require('js-crawler'),
    mongoClient = require('mongodb').MongoClient,
    co = require('co'),
    _ = require('underscore'),
    log4js = require('log4js'),
    fs = require('fs'),
    keypress = require('keypress');

// log4js.configure({
//   appenders: [
//     { type: 'console' },
//     { type: 'file', filename: '/repos.git/webCrawler/zhongjie/log1/tripadvisorResImagesCrawler9.log' }
//   ]
// });

// log4js.configure({
//   appenders: [
//     { type: 'console' },
//     { type: 'file', filename: 'logs/cheese.log', category: 'cheese' }
//   ]
// });


log4js.replaceConsole();


function saveImage(url, hotelId, bufferContent, rootPath){
    let hotelpath = `${rootPathOfImages}${hotelId}.jpg`;
    writeFile(hotelpath, bufferContent, {encoding : null}, hotelId);
}


var writeImageSuccessCount = 0;
function writeFile(path, data, options, hotelId) {
    if (!fs.existsSync(path)) {
        fs.writeFile(path, data, options,function(err){
            if (!err) { writeImageSuccessCount ++ };
        });
    };
};

keypress(process.stdin); 
process.stdin.on('keypress', function (ch, key) {
    if (key && key.name === 'space') {
        if (crawler) {
            console.log('------ log save ------------');
            let obj = crawler.dump();
            console.log(`WriteImageSuccessCount: ${writeImageSuccessCount}`);
        };
    };
    if (key && key.ctrl && key.name == 'c') {
        process.exit(1);
    }
});


function logSave() {
    if(crawler){
        console.log('------ log save ------------');
        let obj =  crawler.dump();
        console.log(`WriteImageSuccessCount: ${writeImageSuccessCount}`);
    }
    setTimeout(function(){
        logSave();
    }, 120*1000);
}

process.stdin.setRawMode(true);
process.stdin.resume();

process.on('uncaughtException', function (err) {
    console.error(`error----${err.stack}`);
});

var crawler = null;

crawler = new Crawler()
.configure({
    ignoreRelative: false, 
    depth: 1,
    userAgent: userAgent,
    maxConcurrentRequests: 30,
    oblivious: true,
    enableTimeOut: true,
    shouldCrawl: function(url) {
        return true;
    },
    onSuccess: function(page) {
        console.log(page.actualUrl);

        saveImage(page.actualUrl, page.options.id, page.body, rootPathOfImages);
        
    },
    onFailure: function(postmortem) {
        console.log('Failed to crawl %s (%s)', postmortem.url, postmortem.status? `HTTP: ${postmortem.status}` : `OTHER: ${postmortem.error}`);
        if (postmortem.status && [404, 403].indexOf(postmortem.status) < 0) {
            console.log('...Ask for re-crawling when possibily recoverable failure/error returned from web server', url);
            return true;
        }
        if (postmortem.error && ['EAI_AGAIN', 'ETIMEDOUT', 'ECONNRESET', 'ENOTFOUND'].indexOf(postmortem.error.code) >= 0) {
            console.log('...Ask for re-crawling in case of: 1. name resolving error, 2. timeout, 3. connection reset');
            return true;
        }
        // when unauthorized to access the original image, fail-over to the small one.
        if (postmortem.status && postmortem.status === 403) {
            if (postmortem.options.URLType === 'image') {
                if (postmortem.options.size === 'o') {
                    crawler.enqueueRequest({
                        url: postmortem.url.replace(/photo-.{1}/im,'photo-s'),
                        'Accept-Language': requestLanguage,
                        id: postmortem.options.id,
                        URLType: 'image',
                        size: 's'
                    },1,true);
                    console.log(`hotelid-${postmortem.options.id}request again with photo-s-${postmortem.url}`);
                } else {
                    // crawler.enqueueRequest(options);
                    console.log('...Already request the small image, stop the crawling efforts');
                }
            }
        }
        return false;
    },

    onAllFinished: function() {
        console.log('Pictures of all hotels have been crawled & saved');

        setTimeout(function(){
            process.exit(1);
        }, 60*1000);

    }
});

// const  hotelListImageColl = 'tempHotelLinksImage222222';

co(function*() {
    let db = yield mongoClient.connect(crawlerDatabase);
    let linksColl = db.collection(hotelListImageColl);
    let records = yield linksColl.find().toArray();
    
    yield db.close();
    
    let spliceArr = records.splice(0,100);
    console.log('%d hotels to crawl', spliceArr.length);
    crawler.crawl();

    for (let record of spliceArr) {
        let path = `${rootPathOfImages}${record.id}.jpg`;
        let match = record.imageUrl.indexOf('photo-');
        if ((!fs.existsSync(path)) && (match > 0)) {
            crawler.enqueueRequest({
                url: record.imageUrl.replace(/photo-.{1}/im,'photo-o'),
                'Accept-Language': requestLanguage,
                URLType: 'image',
                id: record.id,
                size: 'o'
            });
        }else {
            console.log('already exit not request',match,record.id,record.href);
        }
    }

    logSave();
})
.catch(err => { console.error(err.stack); });


> db.tempRestaurantImageLinks.find({id:'1010352'})
{ "_id" : ObjectId("58cf6ae2b138580c5db49bdc"), "id" : "1010352", "href" : "https://www.tripadvisor.com/Restaurant_Review-g1066443-d1010352-Reviews-NINJA_AKASAKA-Chiyoda_Tokyo_Tokyo_Prefecture_Kanto.html", "imageUrl" : "https://media-cdn.tripadvisor.com/media/photo-s/05/5c/57/79/sushi-plate.jpg" }





