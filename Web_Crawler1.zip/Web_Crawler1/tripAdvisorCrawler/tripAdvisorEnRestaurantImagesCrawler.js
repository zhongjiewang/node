#!/usr/bin/env node
'use strict';

const userAgent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36';

const crawlerDatabase = 'mongodb://localhost:27017/tripadvisor',
    restaurantImageWebPageLinks = 'restaurantImageWebPageLinks',
    rootPathOfImages = '/Users/zhongjie/Desktop/SavePicture/1ap/';


// const crawlerDatabase = 'mongodb://localhost:27017/crawler',
//     restaurantImageWebPageLinks = 'temprestaurantImageWebPageLinks',
//     rootPathOfImages = '/galleries/tripadvisor.com/restaurants/';


const tripadvisorUrl = 'https://www.tripadvisor.com',
      requestLanguage = 'en-US;q=0.8,zh-CN;q=0.2';
var Crawler = require('js-crawler'),
    mongoClient = require('mongodb').MongoClient,
    co = require('co'),
    _ = require('underscore'),
    log4js = require('log4js'),
    fs = require('fs'),
    keypress = require('keypress');

log4js.configure({
  appenders: [
    { type: 'console' },
    { type: 'file', filename: '/repos.git/webCrawler/zhongjie/log/tripadvisorRestaurantImagesCrawler3.log' }
  ]
});


log4js.replaceConsole();


// function parseHotelDetailsAndRequestTravellerLocationPhotoDirectLink (link, hotelId, content,  crawler) {
//     let locationPhotoDirectLinkMatch = /href=\"(\/LocationPhotoDirectLink.+?)" onclick="/img.exec(content);
//     if (locationPhotoDirectLinkMatch == null) {
//         console.log(`null -- locationPhotoDirectLinkMatch in ${link}`);
//         return;
//     }
//     let url = `${tripadvisorUrl}${locationPhotoDirectLinkMatch[1]}`;

//     crawler.enqueueRequest({
//         url:url,
//         'Accept-Language': requestLanguage,
//         URLType: 'photo-direct-link',
//         id: hotelId
//     },1,true);
// }
function parseWebWhenOneBigImageAndRequest (link, id, content) {
    let reg = /"big_photo" style=".+?src="(.+?)" alt/img;
    let imageurl = reg.exec(content);
    console.log(id,'one big image --',imageurl[1]);
    let t  = /photo-.{1}\/(.+)/mg.exec(imageurl[1]);
    let imgName = null;
    if (t != null) {
        imgName = t[1].replace(/\//g,'-');
        let opathName = `${rootPathOfImages}${id}/o-${imgName}`;
        let spathName = `${rootPathOfImages}${id}/s-${imgName}`;
        if (!fs.existsSync(opathName) && !fs.existsSync(spathName)){
            crawler.enqueueRequest({
                url: imageurl[1].replace(/photo-.{1}/im,'photo-o'),
                'Accept-Language': requestLanguage,
                id: id,
                URLType: 'image',
                size: 'o'
            },1,true);
        };
    }else{
        console.log(id, 'big iamge imageName match is null');
    }
}


function parsePhotosWebPageAndRequest(link, id, content, urlType) {

    if ( /<div class="thumbImg wrap">[^]+?<!--etk-->/img.exec(content) == null) {
        // console.log(`${id}-Failed parse web page photeos section in ${link}`);
        parseWebWhenOneBigImageAndRequest(link,id,content);
        return;
    }
    let section = /<div class="thumbImg wrap">[^]+?<!--etk-->/img.exec(content)[0];

    // let leftPartition = '<div class="hoverHighlight left"><div class="arrow"></div></div>';
    let rightPartition = '<div class="hoverHighlight right"><div class="arrow"></div></div>';
    
    // if (urlType === 'left-arrow' || urlType === 'photo-direct-link') {
    //     let leftItem = section.substring(0,section.indexOf(leftPartition));
    //     let leftPageUrl = /<a onclick=".+?" href="(.+?)">/img.exec(leftItem);
    //     if (leftPageUrl) {
    //         crawler.enqueueRequest({
    //             url: tripadvisorUrl + leftPageUrl[1],
    //             'Accept-Language': requestLanguage,
    //             id: hotelId,
    //             URLType: 'left-arrow'
    //         },1,true);
    //     };
    // }

    // if (urlType === 'right-arrow') {
        let tempindex = section.indexOf('<div class="thumblpdl last"');
        if (tempindex == -1) {
            tempindex = section.indexOf('<div class="thumblpdl">');
        }
        let rightItem = section.substring(tempindex, section.indexOf(rightPartition));
        let rightPageUrl = /<a onclick=".+?" href="(.+?)">/img.exec(rightItem);
        if (rightPageUrl) {
            crawler.enqueueRequest({
                url: tripadvisorUrl + rightPageUrl[1],
                'Accept-Language': requestLanguage,
                id: id,
                URLType: 'right-arrow'
            },1,true);
        };
    // };
 
    let itemRegexp = /src="(.+?)" alt="/img;
    let thumblpdlmatches = null;
    while ((thumblpdlmatches = itemRegexp.exec(section)) != null ) {
         let imageUrl = thumblpdlmatches[1];
         let t  = /photo-.{1}\/(.+)/mg.exec(imageUrl);
         let imgName = null;
         if (t != null) {
            imgName = t[1].replace(/\//g,'-');
            let opathName = `${rootPathOfImages}${id}/o-${imgName}`;
            let spathName = `${rootPathOfImages}${id}/s-${imgName}`;
            if (!fs.existsSync(opathName) && !fs.existsSync(spathName)){
                crawler.enqueueRequest({
                    url: imageUrl.replace(/photo-.{1}/im,'photo-o'),
                    'Accept-Language': requestLanguage,
                    id: id,
                    URLType: 'image',
                    size: 'o'
                },1,true);
            };
         }else {
            console.log(`video-t image url id ${id}- ${imageUrl}`);
            crawler.enqueueRequest({
                url: imageUrl,
                'Accept-Language': requestLanguage,
                id: id,
                URLType: 'image',
                size: 'video'
            },1,true);  
         };
    };
}

function saveImage(url, id, bufferContent, rootPath){

    let hotelpath = `${rootPathOfImages}${id}/`;
    let t  = /photo-(.+)/mg.exec(url);
    let imageName = null;
    if (t != null) {
        imageName = t[1].replace(/\//g,'-');
    }else {
        console.log(`save video-t -id-${id} image url ${url}`);
        let video  = /video-(.+)/mg.exec(url);
        if (video) {
            imageName = video[1].replace(/\//g,'-');
        };
    };
    
    fsMake(hotelpath)
    .then( (path) => {
        // writeFile(`${path}${imageName}`, bufferContent, {encoding : null}, id);
    });
}

function fsMake (path) {
   let  k =   new Promise (function (resolve, reject) {
                fs.stat(path,function (err, stats) {
                    if(!err) {
                        resolve(path) ;
                    }else {
                        fs.mkdir (path, function(err){
                            if(!err) resolve(path);
                        })
                    }
                });
            }); 

   return k;
};
var writeImageSuccessCount = 0;
function writeFile(path, data, options, id) {
    if (!fs.existsSync(path)) {
        fs.writeFile(path, data, options,function(err){
            if (!err) { writeImageSuccessCount ++ };
        });
    };
};

keypress(process.stdin); 
process.stdin.on('keypress', function (ch, key) {
    if (key && key.name === 'space') {
        if (crawler) {
            console.log('------ log save ------------');
            let obj = crawler.dump();
            console.log(`WriteImageSuccessCount: ${writeImageSuccessCount}`);
        };
    };
    if (key && key.ctrl && key.name == 'c') {
        process.exit(1);
    }
});


function logSave() {
    if(crawler){
        console.log('------ log save ------------');
        let obj =  crawler.dump();
        console.log(`WriteImageSuccessCount: ${writeImageSuccessCount}`);
    }
    setTimeout(function(){
        logSave();
    }, 120*1000);
}

process.stdin.setRawMode(true);
process.stdin.resume();

process.on('uncaughtException', function (err) {
    console.error(`error----${err.stack}`);
});

var crawler = null;

crawler = new Crawler()
.configure({
    ignoreRelative: false, 
    depth: 1,
    userAgent: userAgent,
    maxConcurrentRequests: 30,
    oblivious: true,
    enableTimeOut: true,
    shouldCrawl: function(url) {
        return true;
    },
    onSuccess: function(page) {
        console.log('response',page.actualUrl);
        if (page.options.URLType === 'right-arrow'){
            parsePhotosWebPageAndRequest(page.actualUrl, page.options.id, page.body, page.options.URLType);
        
        }
        else if (page.options.URLType === 'image'){
            saveImage(page.actualUrl, page.options.id, page.body, rootPathOfImages);
        };

    },
    onFailure: function(postmortem) {
        console.log('Failed to crawl %s (%s)', postmortem.url, postmortem.status? `HTTP: ${postmortem.status}` : `OTHER: ${postmortem.error}`);
        if (postmortem.status && [404, 403].indexOf(postmortem.status) < 0) {
            console.log('...Ask for re-crawling when possibily recoverable failure/error returned from web server', url);
            return true;
        }
        if (postmortem.error && ['EAI_AGAIN', 'ETIMEDOUT', 'ECONNRESET', 'ENOTFOUND'].indexOf(postmortem.error.code) >= 0) {
            console.log('...Ask for re-crawling in case of: 1. name resolving error, 2. timeout, 3. connection reset');
            return true;
        }
        // when unauthorized to access the original image, fail-over to the small one.
        if (postmortem.status && postmortem.status === 403) {
            if (postmortem.options.URLType === 'image') {
                if (postmortem.options.size === 'o') {
                    crawler.enqueueRequest({
                        url: postmortem.url.replace(/photo-.{1}/im,'photo-s'),
                        'Accept-Language': requestLanguage,
                        id: postmortem.options.id,
                        URLType: 'image',
                        size: 's'
                    },1,true);
                    console.log(`restaurantid-${postmortem.options.id} one image-request again with photo-s`);
                } else {
                    // crawler.enqueueRequest(options);
                    console.log('...Already request the small image, stop the crawling efforts');
                }
            }
        }
        return false;
    },

    onAllFinished: function() {
        console.log('Pictures of all hotels have been crawled & saved');

        setTimeout(function(){
            process.exit(1);
        }, 3*60*1000);

    }
});


co(function*() {
    let db = yield mongoClient.connect(crawlerDatabase);
    let linksColl = db.collection(restaurantImageWebPageLinks);
    let records = yield linksColl.find({flag: 1}).toArray();
    
    yield db.close();
    crawler.crawl();
  
    let spliceArr = records.splice(0, 100);
    console.log('%d restaurants to crawl', spliceArr.length);

    for (let record of spliceArr) {
        crawler.enqueueRequest({
            url: record.url,
            'Accept-Language': requestLanguage,
            URLType: 'right-arrow',
            id: record.id
        });
    }

    logSave();
})
.catch(err => { console.error(err.stack); });

    //Math.round(x)
//     与 x 最接近的整数。
// 说明
// 对于 0.5，该方法将进行上舍入。
// 例如，3.5 将舍入为 4，而 -3.5 将舍入为 -3。
// Math.floor(x)
// 参数  描述
// x   必需。任意数值或表达式。
// 返回值
// 小于等于 x，且与 x 最接近的整数。

  //抽取函数----------
    // let swapMap = {};
    // let pickedNums = [];
    // const totalCount = 100000;
    // let count = totalCount - 1;
    // for (let j = 0; j < 1000; j++) {
    //     //math .floor(x) 进行的下舍入, 最接近的整数, <= x
    //     let index = Math.floor(Math.random() * count);
    //     // console.log('count',c ,'index',index, 'swapMap',swapMap[index]);
    //     if (swapMap[index]) {
    //         console.log(`--- swaped index was picked: [${index}] -> ${swapMap[index]}) ---`);
    //         pickedNums.push(swapMap[index]);
    //     }else {
    //         pickedNums.push(index);
    //     }
    //     swapMap[index] = count--;
    // }
    // console.log(pickedNums.length);

 // error----TypeError: Cannot read property '3' of null
 //    at parsePhotosWebPageAndRequest (/Users/zhongjie/Desktop/node/crawler/Web_Crawler1/tripAdvisorCrawler/tripAdvisorEnRestaurantImagesCrawler.js:109:33)
 //    at Crawler.onSuccess (/Users/zhongjie/Desktop/node/crawler/Web_Crawler1/tripAdvisorCrawler/tripAdvisorEnRestaurantImagesCrawler.js:247:13)
 //    at Request._callback (/Users/zhongjie/node_modules/js-crawler/crawler.js:428:16)
 //    at Request.self.callback (/Users/zhongjie/node_modules/js-crawler/node_modules/request/request.js:368:22)
 //    at emitTwo (events.js:106:13)
 //    at Request.emit (events.js:191:7)
 //    at Request.<anonymous> (/Users/zhongjie/node_modules/js-crawler/node_modules/request/request.js:1219:14)
 //    at emitOne (events.js:101:20)
 //    at Request.emit (events.js:188:7)
 //    at IncomingMessage.<anonymous> (/Users/zhongjie/node_modules/js-crawler/node_modules/request/request.js:1167:12)








