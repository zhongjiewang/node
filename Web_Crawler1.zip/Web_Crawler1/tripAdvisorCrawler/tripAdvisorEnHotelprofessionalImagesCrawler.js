#!/usr/bin/env node
'use strict';

const userAgent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36';
const crawlerDatabase = 'mongodb://localhost:27017/tripadvisor',
    // hotelImageWebPageLinks = 'hotelImageWebPageLinks',
    hotelLinksCollName = 'hotelLinks',
    rootPathOfImages = '/Users/zhongjie/Desktop/SavePicture/1ap/';


// const crawlerDatabase = 'mongodb://localhost:27017/crawler',
//     hotelLinksCollName = 'tempHotelLinks',
//     // hotelImageWebPageLinks = 'tempHotelImageWebPageLinks',
//     rootPathOfImages = '/galleries/tripadvisor.com/hotels/professional/';

//https://www.tripadvisor.com/Hotel_Review-g1120615-d670212-Reviews-Hotel_Sierra_resort_Hakuba-Hakuba_mura_Kitaazumi_gun_Nagano_Prefecture_Chubu.html
//https://www.tripadvisor.com/LocationPhotoAlbum?detail=670212&geo=1120615&filter=4&albumId=101&heroMinWidth=1164&heroMinHeight=261&albumid=101&albumViewMode=images&albumPartialsToUpdate=full&extraAlbumCoverCount=4&area=QC_Meta_Mini%7CPhoto_Lightbox&metaReferer=Hotel_Review
//https://www.tripadvisor.com/LocationPhotoAlbum?detail=1811698&geo=1066460&filter=4&albumId=101&heroMinWidth=1185&heroMinHeight=197&albumid=101&albumViewMode=images&albumPartialsToUpdate=full&extraAlbumCoverCount=4&area=QC_Meta_Mini%7CPhoto_Lightbox&metaReferer=Hotel_Review
//https://www.tripadvisor.com/LocationPhotoAlbum?detail=310308&geo=1066443&filter=4&albumId=101&heroMinWidth=1185&heroMinHeight=197&albumid=101&albumViewMode=images&albumPartialsToUpdate=full&extraAlbumCoverCount=4&area=QC_Meta_Mini%7CPhoto_Lightbox&metaReferer=Hotel_Review
//https://www.tripadvisor.com/LocationPhotoAlbum?detail=310298&geo=1066461&filter=4&albumId=101&heroMinWidth=1185&heroMinHeight=237&albumid=101&albumViewMode=images&albumPartialsToUpdate=full&extraAlbumCoverCount=4&area=QC_Meta_Mini%7CPhoto_Lightbox&metaReferer=Hotel_Review
// <div class="sizedThumb_container">
// <img class="sizedThumb_thumbnail" src="https://media-cdn.tripadvisor.com/media/photo-o/03/61/16/a4/palace-side-sueprior.jpg" width="560px" alt="The Tokyo Station Hotel" style="height: auto" height="362px"/>
// </div>
// </div>
// <!--trkP:hr_view_all_photos_card-->


const tripadvisorUrl = 'https://www.tripadvisor.com',
      requestLanguage = 'en-US;q=0.8,zh-CN;q=0.2';
var Crawler = require('js-crawler'),
    mongoClient = require('mongodb').MongoClient,
    co = require('co'),
    _ = require('underscore'),
    log4js = require('log4js'),
    fs = require('fs'),
    keypress = require('keypress'),
    AsyncStreamer = require('async-streamer');

log4js.configure({
  appenders: [
    { type: 'console' },
    { type: 'file', filename: '/repos.git/webCrawler/zhongjie/log/tripadvisorHotelImagesCrawler5.log' }
  ]
});


log4js.replaceConsole();

// const crawlerDatabase = 'mongodb://localhost:27017/tripadvisor',
  const  hotelListCollName = 'tempHotelLinks2222';

var asyncStreamer = new AsyncStreamer({
    url: crawlerDatabase,
    collection: hotelListCollName
}).start();


var count = 0;
var not = 0;
function parseHotelDetailsAndRequestImageLink (link, hotelId, content,  crawler) {
    // console.log(link);
    let match = /<img class="sizedThumb_thumbnail" src="(.+?)" width=[^]+?<!--trkP:hr_view_all_photos_card-->/img.exec(content);
    // console.log(match[1]);
    if (match) {
        // console.log(match[1]);
        let url = match[1].replace(/photo-.{1}/img, 'photo-o');
        let opathName = `${rootPathOfImages}${hotelId}.jpg`;
        let wpathName = `${rootPathOfImages}${hotelId}.jpg`;
        if (!fs.existsSync(opathName) && !fs.existsSync(wpathName)){
            crawler.enqueueRequest({
                url: url,
                'Accept-Language': requestLanguage,
                id: hotelId,
                URLType: 'image',
                size: 'o'
            },1,true);
        }else{
            console.error(`image already exit----${hotelId}--${link}--`);
        }
        count ++;  
    }else{
        not ++;
        console.error(`not mactch ----${hotelId}--${link}--`);
        let hotel = {
            id: hotelId,
            url:link
        }
        asyncStreamer.commit(hotel);

    }

    console.log(count,'--------',not);
}


function saveImage(url, hotelId, bufferContent, rootPath){

    let path = `${rootPathOfImages}/${hotelId}.jpg`;
    writeFile(path, bufferContent, {encoding : null}, hotelId);
}

function fsMake (path) {
   let  k =   new Promise (function (resolve, reject) {
                fs.stat(path,function (err, stats) {
                    if(!err) {
                        resolve(path) ;
                    }else {
                        fs.mkdir (path, function(err){
                            if(!err) resolve(path);
                        })
                    }
                });
            }); 

   return k;
};
var writeImageSuccessCount = 0;
function writeFile(path, data, options, hotelId) {
    if (!fs.existsSync(path)) {
        fs.writeFile(path, data, options,function(err){
            if (!err) { writeImageSuccessCount ++ };
        });
    };
};

keypress(process.stdin); 
process.stdin.on('keypress', function (ch, key) {
    if (key && key.name === 'space') {
        if (crawler) {
            console.log('------ log save ------------');
            let obj = crawler.dump();
            console.log(`WriteImageSuccessCount: ${writeImageSuccessCount}`);
        };
    };
    if (key && key.ctrl && key.name == 'c') {
        process.exit(1);
    }
});


function logSave() {
    if(crawler){
        console.log('------ log save ------------');
        let obj =  crawler.dump();
        console.log(`WriteImageSuccessCount: ${writeImageSuccessCount}`);
    }
    setTimeout(function(){
        logSave();
    }, 120*1000);
}

process.stdin.setRawMode(true);
process.stdin.resume();

process.on('uncaughtException', function (err) {
    console.error(`error----${err.stack}`);
});

var crawler = null;

crawler = new Crawler()
.configure({
    ignoreRelative: false, 
    depth: 1,
    userAgent: userAgent,
    maxConcurrentRequests: 30,
    oblivious: true,
    enableTimeOut: true,
    shouldCrawl: function(url) {
        return true;
    },
    onSuccess: function(page) {

        if (page.options.URLType === 'hotelweb') {

            parseHotelDetailsAndRequestImageLink (page.actualUrl, page.options.id, page.body, this);

        }else if (page.options.URLType === 'image'){
            saveImage(page.actualUrl, page.options.id, page.body, rootPathOfImages);
        }

    },
    onFailure: function(postmortem) {
        console.log('Failed to crawl %s (%s)', postmortem.url, postmortem.status? `HTTP: ${postmortem.status}` : `OTHER: ${postmortem.error}`);
        if (postmortem.status && [404, 403].indexOf(postmortem.status) < 0) {
            console.log('...Ask for re-crawling when possibily recoverable failure/error returned from web server', url);
            return true;
        }
        if (postmortem.error && ['EAI_AGAIN', 'ETIMEDOUT', 'ECONNRESET', 'ENOTFOUND'].indexOf(postmortem.error.code) >= 0) {
            console.log('...Ask for re-crawling in case of: 1. name resolving error, 2. timeout, 3. connection reset');
            return true;
        }
        // when unauthorized to access the original image, fail-over to the small one.
        if (postmortem.status && postmortem.status === 403) {
            if (postmortem.options.URLType === 'image') {
                if (postmortem.options.size === 'o') {
                    crawler.enqueueRequest({
                        url: postmortem.url.replace(/photo-.{1}/im,'photo-w'),
                        'Accept-Language': requestLanguage,
                        id: postmortem.options.id,
                        URLType: 'image',
                        size: 'w'
                    },1,true);
                    console.log(`hotelid-${postmortem.options.id}request again with photo-s-${postmortem.url}`);
                } else {
                    // crawler.enqueueRequest(options);
                    console.log('...Already request the small image, stop the crawling efforts');
                }
            }
        }
        return false;
    },

    onAllFinished: function() {
        console.log('Pictures of all hotels have been crawled & saved');

        setTimeout(function(){
            process.exit(1);
        }, 3*60*1000);

    }
});


co(function*() {
    let db = yield mongoClient.connect(crawlerDatabase);
    let linksColl = db.collection(hotelLinksCollName);
    let records = yield linksColl.find().toArray();
    
    yield db.close();
    
    let spliceArr = records.splice(10);
    console.log('%d professional hotels to crawl', spliceArr.length);
    crawler.crawl();


  
// let rurl = 'https://www.tripadvisor.com/Hotel_Review-g1120615-d670212-Reviews-Hotel_Sierra_resort_Hakuba-Hakuba_mura_Kitaazumi_gun_Nagano_Prefecture_Chubu.html';
    for (let record of spliceArr) {
        let opathName = `${rootPathOfImages}${record.id}.jpg`;
        let wpathName = `${rootPathOfImages}${record.id}.jpg`;
        if (!fs.existsSync(opathName) && !fs.existsSync(wpathName)){
            crawler.enqueueRequest({
                url: record.url,
                'Accept-Language': requestLanguage,
                URLType: 'hotelweb',
                id: record.id
            });
        }else{
            console.log('webResquest --already exit',record.id);
        }

    }

    // logSave();
})
.catch(err => { console.error(err.stack); });






















