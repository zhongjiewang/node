
var webpage = require('webpage'), page = webpage.create();
var fs = require('fs');
page.viewportSize = { width: 1024, height: 800 };
page.clipRect = { top: 0, left: 0, width: 1024, height: 800 };
page.settings = {
    javascriptEnabled: true,
    loadImages: false,
    webSecurityEnabled: false,
    userAgent: 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.137 Safari/537.36 LBBROWSER'
    //要指定谷歌ua,我用火狐无法浏览
};
var lastReceived = new Date().getTime();
var requestCount = 0;
var responseCount = 0;
var requestIds = [];
var startTime = new Date().getTime();

page.onLoadStarted = function () {
    page.startTime = new Date();
};//获取页面开始加载的时间

console.log('====================');
// var url2 = 'http://localhost:3333/geos/views/view-geo.client.view.html';

// var url2 = 'https://www.tripadvisor.com/Hotel_Review-g298566-d1094561-Reviews-Hotel_Brighton_City_Osaka_Kitahama-Osaka_Osaka_Prefecture_Kinki.html';
// var url2 = 'https://www.tripadvisor.com/Hotel_Review-g298566-d1830576-Reviews-The_St_Regis_Osaka-Osaka_Osaka_Prefecture_Kinki.html';
var url2 = 'https://www.tripadvisor.com/Hotel_Review-g298566-d598268-Reviews-Hotel_Monterey_Lasoeur_Osaka-Osaka_Osaka_Prefecture_Kinki.html'
page.open(url2, function () {
    console.log('start');
    if (status === 'fail') {
        console.log('open page fail!');
    } else {
        waitFor(function () {
            return page.evaluate(function () {
                //判断页面加载完成的信号,
                // console.log($("#d010006").length);
                console.log('+++++++++++++');
                var a = document.getElementsByClassName('inView');
                console.log(a);
                console.log(a[0].innerHTML);
                // return $("#d010006").length > 0;
                // console.log($("#888").length);

                // return $("#BIG_PHOTO_CAROUSEL").length > 0;
                return 1;

            });
        }, function () {
            //页面加载完成后我们的DOM操作,
            //引入外部js库
            page.includeJs('https://apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js', function () {
                page.evaluate(function () { //操作页面事件
                    console.log("jQuery version:" + jQuery.fn.jquery);
                    console.log('---------------')
                    // console.log($("#d010006").text());
                    // console.log($(".inView").html());
                    // var a = document.getElementById("p1").innerHTML;
                    var a = document.getElementsByClassName('inView');
                    console.log(a[0].innerHTML);
                    // $("a").each(function () {
                    //     console.log($(this).attr("href"));
                    // });
                });
                // setTimeout(function () {
                //     page.render('../snapshot/taoba2o.png');
                // }, 2000);
                //console.log()
                var t = Date.now() - page.startTime; //页面加载完成后的当前时间减去页面开始加载的时间，为整个页面加载时间
                console.log('firstLoadPage time :' + t + 'ms');
                console.log("end");
                // setTimeout(function () {
                //     page.close();
                //     phantom.exit();
                // }, 0);
            });
        });
    }
});

function screan(filename) {
    page.render(filename);
}


function waitFor(testFx, onReady, timeOutMillis) {
    var maxtimeOutMillis = timeOutMillis ? timeOutMillis : 150*1000, //< Default Max Timout is 3s
        start = new Date().getTime(),
        condition = false,
        interval = setInterval(function () {
            console.log('-----exec----');
            condition = (typeof (testFx) === "string" ? eval(testFx) : testFx()); //< defensive code

            typeof (onReady) === "string" ? eval(onReady) : onReady(); 

            // if ((new Date().getTime() - start < maxtimeOutMillis) && !condition) {
            //     // If not time-out yet and condition not yet fulfilled
            //     screan('../snapshot/taobao.png');
            //     condition = (typeof (testFx) === "string" ? eval(testFx) : testFx()); //< defensive code
                

            // } else {
            //     if (!condition) {
            //         // If condition still not fulfilled (timeout but condition is 'false')
            //         console.log("'waitFor()' timeout");
            //         phantom.exit(1);
            //     } else {
            //         // Condition fulfilled (timeout and/or condition is 'true')
            //         console.log("'waitFor()' finished in " + (new Date().getTime() - start) + "ms.");
            //         typeof (onReady) === "string" ? eval(onReady) : onReady(); //< Do what it's supposed to do once the condition is fulfilled
            //         clearInterval(interval); //< Stop this interval
            //     }
            // }
        }, 250); //< repeat check every 250ms
};

page.onCallback = function (data) {
    console.log('CALLBACK: ' + JSON.stringify(data));
    // Prints 'CALLBACK: { "hello": "world" }'
};


page.onAlert = function (msg) {
    console.log('ALERT: ' + msg);
};

page.onConsoleMessage = function (msg, lineNum, sourceId) {
    console.log('CONSOLE:' + msg);
    //var d = "http://h5.m.taobao.com/awp/core/detail.htm?id=43064483679";
    // var re = new RegExp("[/?id=]+[0-9]{11}");
    // var arr = (msg.match(re));
    //if (arr != null) {
    //    console.log(msg.match(re)[0].replace("?id=", ""));
    //}
};


page.onError = function (msg, trace) {
    var msgStack = ['ERROR: ' + msg];
    if (trace && trace.length) {
        msgStack.push('TRACE:');
        trace.forEach(function (t) {
            msgStack.push(' -> ' + t.file + ': ' + t.line + (t.function ? ' (in function "' + t.function + '")' : ''));
        });
    }

    console.error(msgStack.join('\n'));

};








