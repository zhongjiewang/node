#!/usr/bin/env node
'use strict';

var crypto = require('crypto'),
    co = require('co'),
    log4js = require('log4js'),
    fs = require('fs'),
    mongoClient = require('mongodb').MongoClient,
    keypress = require('keypress');

log4js.configure({
  appenders: [
    { type: 'console' },
    { type: 'file', filename: `/tripadvisor/hotel/hotelDetailsCrawler.log` }
  ]
});

log4js.replaceConsole();

 
const crawlerDatabase = 'mongodb://localhost:27017/compiler',
      collectionName = 'pois';

// When the code is running in the server, please change the root path of the picture, and make sure the root path is exist;
const rootPathOfImages = '/galleries/booking.com/hotel/';

const targetPath = '/galleries/tripadvisorBooking/'
// const rootPathOfImages = '/Users/zhongjie/Desktop/SavePicture/bookinghotel/';

fs.stat(rootPathOfImages,function (err, stats) {  
    if(err)  { console.error(`the rootPath is not exit,please create it: ${rootPathOfImages}`);   process.exit(1);}
});


co(function*() {
    let db = yield mongoClient.connect(crawlerDatabase);
    let linksColl = db.collection(collectionName);
    let records = yield linksColl.find({bookingId:{$ne:null}},{tid:1,bookingId:1}).toArray();
    yield db.close();

    console.log('%d find count', records.length);

    console.log(records[0]);

    for (let record of records) {

         let getpath = getPath(rootPathOfImages, record.bookingId);
         console.log(getpath);
           fs.readdir(getpath, function(err, idfiles){
                // console.log(file,idfiles[0]);
                let imgPath = `${getpath}/${idfiles[0]}`;
                console.log('imgpath',imgPath);
                fs.readFile(imgPath, function (err, data) {
                    // console.log('read error',err);
                    let writepath = `${targetPath}${record.tid}.jpg`;
                    // console.log(writepath);
                    writeFile(writepath, data, {encoding : null});
                });
            });
    };
 })
.catch(err => { console.error(err.stack); });


function parseImageBufferAndwriteImage (url, hotelID, bufferContent, rootPath) {
 
    let imageid = /\/(\d+?).jpg/im.exec(url);
    getPathAndWrite(rootPath, hotelID, imageid[1], bufferContent);
 }   


function getPath (rootPath, hotelID, imageIDName, bufferContent) {
    let theLastThreeNumber = hotelID.slice(-3);
    let sumOftheLastThreeNumber = function (){
                let sum = 0;
                for (let i = 0; i < theLastThreeNumber.length; i++) {
                    let temp = parseInt(theLastThreeNumber[i]);
                    sum += temp;
                };
                return sum;
        }();
    let firstDictionary = sumOftheLastThreeNumber.toString();
    let hashPath = rootPath + firstDictionary;
    return `${hashPath}/${hotelID}/`;
};


function fsMake (path) {
   let  k =   new Promise (function (resolve, reject) {
                fs.stat(path,function (err, stats) {
                    if(!err) {
                        resolve(path) ;
                    }else {
                        fs.mkdir (path, function(err){
                            if(!err) resolve(path);
                        })
                    }
                });
            }); 

   return k;
};


function writeFile(path, data, options) {
    fs.writeFile(path, data, options,function(err){
        // if(!err) console.log('Wrtie to Success :' + path);
        // else console.error('Write Failed :' + path);
        if (!err) {
            console.log('success', path);
            console.log('');
        };
    })
};













