

var fs = require("fs"),
    ProtoBuf = require("protobufjs"),
    userProtoStr = fs.readFileSync('./user.proto').toString(),
    UserModel = ProtoBuf.loadProto(userProtoStr).build('protobuf').UserModel,
    userModel;
    console.log('======')
    console.log(userProtoStr);


userModel= new UserModel();
userModel.set('cyUserno', 'wang');
userModel.set('cyPassWord', 'password');
userModel.set('cyStatus', '1');
 
var buffer = userModel.encode().toBuffer();


console.log(buffer);


var userInfo = UserModel.decode(buffer);
 
var info = userInfo.get('cyUserno');

console.log(info)

















































