
var  ProtoBuf = require("protobufjs");

var str = 'package protobuf; message UserModel { required string cyUserno = 1;required string cyPassWord = 2;}';

var  UserModel = ProtoBuf.loadProto(str).build('protobuf').UserModel;
var  userModel;
 
userModel= new UserModel();
userModel.set('cyUserno', 'wang');
userModel.set('cyPassWord', 'password');
 
console.log(userModel)
var buffer = userModel.encode().toBuffer();

console.log('=================')
console.log(buffer[0]);
console.log(buffer.length);


var userInfo = UserModel.decode(buffer);
 
var info = userInfo.get('cyUserno');

console.log(info);




















