

module.exports = function (a, b) {
    console.log("js:multiply");
    return a * b;
};















