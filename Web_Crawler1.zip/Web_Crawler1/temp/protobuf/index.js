

var square = require('./square');
console.log("js:index");
console.log(square(125));

