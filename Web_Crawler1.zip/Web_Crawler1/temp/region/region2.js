#!/usr/bin/env node
'use strict';

var  co = require('co');
var  mongoClient = require('mongodb').MongoClient;
var fs = require('fs');
const poiDatabase = 'mongodb://localhost:27017/Poi';
const poicollection = 'regioncollection';


// var AsyncStreamer = require('async-streamer');
// var asyncRecordStreamer = new AsyncStreamer({
//     url: 'mongodb://localhost:27017/Poi',
//     collection: 'regioncollection'
// });
// asyncRecordStreamer.start();

var t = [1, 2, 3].includes(2);
console.log(t);
co(function*() {
    let db = yield mongoClient.connect(poiDatabase);
    let poiColl = db.collection(poicollection);
    let records = yield poiColl.find({'attrib':1}).toArray();
    yield db.close();

    console.log(records);


})
.catch(err => { console.error(err.stack); });

function dedupe(array) {
  return Array.from(new Set(array));
}

// function demo () {
//     return new Promise(function(resolve,reject){
//         for (let record of records) {
//             asyncRecordStreamer.commit(record);
//         };
//     });
// }






































