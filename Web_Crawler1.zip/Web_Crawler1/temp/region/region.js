#!/usr/bin/env node
'use strict';

var  co = require('co');
var  mongoClient = require('mongodb').MongoClient;

const poiDatabase = 'mongodb://localhost:27017/Poi';
const poicollection = 'regioncollection';


// var AsyncStreamer = require('async-streamer');
// var asyncRecordStreamer = new AsyncStreamer({
//     url: 'mongodb://localhost:27017/Poi',
//     collection: 'regioncollection'
// });
// asyncRecordStreamer.start();

var t = [1, 2, 3].includes(2);
console.log(t);
co(function*() {
    let db = yield mongoClient.connect(poiDatabase);
    let poiColl = db.collection(poicollection);
    let records = yield poiColl.find({'attrib':1}).toArray();
    yield db.close();

    console.log(records.length);

    let arr = [];
    for(let record of records) {

        arr.push(record.localName);
    }

    let shifArr = dedupe(arr);
    console.log(shifArr.length);

    let res = [1];
    let ddd = [];
    // console.log(arr.toString())
    var str = arr.join('and');
    // console.log(str)

    // console.log(str.match(/三郷町/g));

    // console.log(str)
    // let strT = '高千穂町';
    // console.log(str.match(/\`\$\{strT\}\`/g));
        // console.log(ll)
    for (let  i = 0; i < arr.length; i ++ ) {
         // console.log(arr[i]);
         // let temp = arr[i].match(arr.toString());
         
         let importantInfoRegExp = eval('/'+'and'+arr[i]+'and'+'/g');

         let ll = str.match(importantInfoRegExp);

         if(ll !== null && ll.length > 1) {
            ddd.push(ll);
         }
     }

    console.log(ddd.length)  

    let result  = dedupe(ddd);
    console.log(result.length);

})
.catch(err => { console.error(err.stack); });

function dedupe(array) {
  return Array.from(new Set(array));
}

// function demo () {
//     return new Promise(function(resolve,reject){
//         for (let record of records) {
//             asyncRecordStreamer.commit(record);
//         };
//     });
// }






































