#!/usr/bin/env node
'use strict';

var request = require('request'),
    xmldom = require('xmldom'),
    osmtogeojson = require('osmtogeojson');

module.exports = function(name) {
    console.log(name);
    return new Promise((resolve, reject) => {
        let options = {
            url: 'https://nominatim.openstreetmap.org/search',
            qs: {
                format: 'json',
                q: `${name}`,
                ploygon:1,
                addressdetails:1
            }
        };
        // console.log('REquest======')
        request(options, (error, response, body) => {
            if (!error && response.statusCode === 200) {
                // console.log(body)
                let places = JSON.parse(body);
                console.log(places)
                // console.log('yishangshiPLACE')
                let place = null;
                for (place of places) {
                    if (place.osm_type === 'relation') {
                        const areaIdProto = '3600000000';
                        let areaId = `${areaIdProto.substring(0, areaIdProto.length - place.osm_id.length)}${place.osm_id}`;
                        options = {
                            url: 'http://overpass-api.de/api/interpreter',
                            method: 'post',
                            form: {
                                data: `area(${areaId});rel(pivot);out geom;`
                            }
                        };
                        // console.log(options.form);
                        request(options, (error, response, body) => {
                            // console.log(body);
                            if (!error && response.statusCode === 200) {
                                let bounds = null;
                                let boundsMatch = /<bounds minlat="(.+?)" minlon="(.+?)" maxlat="(.+?)" maxlon="(.+?)"\/>/g.exec(body);
                                if (boundsMatch) {
                                    bounds = {
                                        southwest: [parseFloat(boundsMatch[2]), parseFloat(boundsMatch[1])],
                                        northeast: [parseFloat(boundsMatch[4]), parseFloat(boundsMatch[3])]
                                    };
                                }
                                try {
                                    let doc = new xmldom.DOMParser().parseFromString(body);
                                    let boundary = osmtogeojson(doc);
                                    resolve({
                                        matched: place.display_name,
                                        bounds: bounds,
                                        boundary: boundary
                                    });
                                } catch (e) {
                                    reject(e);
                                }
                            } else reject(error || http.STATUS_CODES[response.statusCode]);
                        });
                        break;
                    }
                }
                if (!place) reject(`"${name}" might not exist`);
                else if (place.osm_type !== 'relation') reject(`"${name}" has no boundary`);
            } else reject(error || http.STATUS_CODES[response.statusCode]);
        });
    });
}








