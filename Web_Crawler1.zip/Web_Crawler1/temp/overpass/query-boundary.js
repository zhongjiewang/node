#!/usr/bin/env node
'use strict';
//http://nominatim.openstreetmap.org/search?q=%E5%B1%B1%E5%BD%A2%E7%9C%8C&format=json&polygon=1
//http://nominatim.openstreetmap.org/search?q=%E5%B1%B1%E5%BD%A2%E7%9C%8C&format=json&ploygon=1
var request = require('request'),
    xmldom = require('xmldom'),
    osmtogeojson = require('osmtogeojson');

module.exports = function(name) {
    console.log(name);
    return new Promise((resolve, reject) => {
        let options = {
            url: 'https://nominatim.openstreetmap.org/search',
            qs: {
                format: 'json',
                q: `${name}`,
                polygon:1,
                addressdetails:1
            }
        };
        // console.log('REquest======')
        request(options, (error, response, body) => {
            if (!error && response.statusCode === 200) {
                console.log(response.request.url);
                let places = JSON.parse(body);
                console.log(places)


            

            } else reject(error || http.STATUS_CODES[response.statusCode]);
        });
    });
}








