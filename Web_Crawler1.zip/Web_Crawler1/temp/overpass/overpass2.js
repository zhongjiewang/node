#!/usr/bin/env node
'use strict';

var queryBoundary = require('./query-boundary');

queryBoundary('山形県')
.then(function(data) {
    console.log(data)
})











































