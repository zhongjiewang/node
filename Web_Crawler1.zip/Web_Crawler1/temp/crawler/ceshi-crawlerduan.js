



var Crawler = require('js-crawler')

const startPage = 'http://www.emingren.com';


crawler = new Crawler()
.configure({
    ignoreRelative: false, 
    depth: 3,
    // userAgent: userAgent,
    maxConcurrentRequests: 10,
    oblivious: true,
    shouldCrawl: function(url) {
        return true;
    },
    onSuccess: function(page) {
        // console.log('Received content from %s', page.actualUrl);
        // if (page.actualUrl == startPage && !onceForAll) {
        //     parseAndRequestRestaurantLists(this, page.body);
        //     onceForAll = true;
        // }
        // if (page.actualUrl.match(restaurantListPageRegEx)) {
        //     parseAndStreamRestaurantLinks(page.body, page.actualUrl);
        // }
        console.log(page.url)

    },
    onFailure: function(postmortem) {
        console.log('Failed to crawl %s (%s)', postmortem.url, postmortem.status? 'HTTP: ' + postmortem.status : 'OTHER: ' + postmortem.error);
        // if (postmortem.status && [404].indexOf(postmortem.status) < 0) {
        //     console.log('...Ask for re-crawling when possibily recoverable failure/error returned from web server');
        //     return true;
        // }
        // if (postmortem.error && ['EAI_AGAIN', 'ETIMEDOUT', 'ECONNRESET'].indexOf(postmortem.error.code) >= 0) {
        //     console.log('...Ask for re-crawling in case of: 1. name resolving error, 2. timeout, 3. connection reset');
        //     return true;
        // }
        // return false;
    },
    onAllFinished: function() {
        console.log('All crawling are finished');
        //asyncRecordStreamer.stop();


    }
})
.crawl(startPage);
























































