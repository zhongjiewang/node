﻿#!/usr/bin/env node
'use strict';

const userAgent = 'crawler@tourank';
RegExp.escape = function(s) { return s.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&'); };

const startPage = 'https://gurunavi.com/en/rs/srh/',
	restaurantListPageRegEx = /^https:\/\/gurunavi\.com\/en(.*?)\/rs\/srh\/(.*?)$/ig;

// list page related markers
const restaurantListBeginsMarker = '<div class="main -right">',
	restaurantListEndsMarker = '<ul class="horizontal-item horizontal-list -with-button-small">',
	restaurantBeginsMarker = '<section>',
	restaurantEndsMarker = '</section>';
	
const crawlerDatabase = 'mongodb://localhost:27017/crawler',
	restaurantLinkCollName = 'restaurantLinks';

var Crawler = require('js-crawler'),
	co = require('co'),
	_ = require('underscore'),
	keypress = require('keypress'),
	log4js = require('log4js'),
	AsyncStreamer = require('./async-streamer/asyncmongostreamer');

log4js.configure({
  appenders: [
    { type: 'console' },
    { type: 'file', filename: '/var/log/tourank/crawler.log' }
  ]
});

log4js.replaceConsole();

// make `process.stdin` begin emitting "keypress" events
var crawler = null;

keypress(process.stdin);
 
// listen for the "keypress" event 
process.stdin.on('keypress', function (ch, key) {
	if (key.name === 'space') {
		console.log('space key pressed');
		if (crawler) {
			crawler.dump();
			console.log('-------- issued --------')
			console.log('.restaurantIds.length: %d', restaurantIds.length);
			restaurantIds.sort();
			for (let id of restaurantIds) {
				console.log('\t%s', id);
			}
		}
	}
	if (key && key.ctrl && key.name == 'c') {
		process.stdin.pause();
	}
});
 
process.stdin.setRawMode(true);
process.stdin.resume();

var asyncRecordStreamer = new AsyncStreamer({
	url: crawlerDatabase,//数据库地址
	collection: restaurantLinkCollName //数据库中集合的名字
});

var onceForAll = false;
asyncRecordStreamer.start();

var restaurantIds = [];

function parseAndRequestRestaurantLists(crawler, content) {
	let matches = /<a href="(https:\/\/gurunavi\.com\/en(.*?)\/rs\/srh\/)\?p=([0-9]+?)">Last<\/a>/img.exec(content);
	if (matches) {
		let lastPage = parseInt(matches[3]);
		for (let i = 2; i <= lastPage; i++) {
			crawler.enqueueRequest({url: matches[1] + '?p=' + i}, 1);
		}
		console.log('Found and requested page#2 to page#%d', lastPage);
	}
}

function parseAndStreamRestaurantLinks(content, url) {
	let narrowed = content.substring(content.indexOf(restaurantListBeginsMarker) + restaurantListBeginsMarker.length);
	narrowed = narrowed.substring(0, narrowed.indexOf(restaurantListEndsMarker));
	let idx = -1;
	let count = 0;
	let issuedCount = 0;
	while (idx = narrowed.indexOf(restaurantBeginsMarker) >= 0) {
		let endIdx = narrowed.indexOf(restaurantEndsMarker);
		let restaurantSection = narrowed.substring(idx + restaurantBeginsMarker.length, endIdx);
		narrowed = narrowed.substring(endIdx + restaurantEndsMarker.length);
		let matches = /<a[^>]+?href="(.+?)"/img.exec(restaurantSection);
		if (matches) {
			count++;
			let id = /^https:\/\/gurunavi\.com\/en\/(.+?)\/rst\/$/ig.exec(matches[1])[1];
			/*
			contains_.contains(list, value) 别名： include 
如果list包含指定的value则返回true（注：使用===检测）。如果list 是数组，内部使用indexOf判断。

_.contains([1, 2, 3], 3);
=> true
			*/
			if (!_.contains(restaurantIds, id)) {
				issuedCount++;
				asyncRecordStreamer.commit({
					crawler: 'gurunaviEnRestaurantLinksCrawler',
					website: 'gurunavi.com',
					country: 'jp',
					language: 'en',
					id: id,
					href: url,
					name: /&nbsp;(.+?)<\/p>/g.exec(restaurantSection)[1].trim(),
					url: matches[1],
					crawledAt: new Date()
				});
				restaurantIds.push(id);
			}
		}
	}
	console.log('Found %d restaurants and streamed %d ones - %s', count, issuedCount, url);
}
	
crawler = new Crawler()
.configure({
	ignoreRelative: false, 
	depth: 1,
	userAgent: userAgent,
	maxConcurrentRequests: 10,
	oblivious: true,
	shouldCrawl: function(url) {
		return true;
	},
	onSuccess: function(page) {
		// console.log('Received content from %s', page.actualUrl);
		if (page.actualUrl == startPage && !onceForAll) {
			parseAndRequestRestaurantLists(this, page.body);
			onceForAll = true;
		}
		//match() 方法可在字符串内检索指定的值，或找到一个或多个正则表达式的匹配。如果有返回数组,
		//如果没有返回null
		if (page.actualUrl.match(restaurantListPageRegEx)) {
			parseAndStreamRestaurantLinks(page.body, page.actualUrl);
		}
	},
	onFailure: function(postmortem) {
    	console.log('Failed to crawl %s (%s)', postmortem.url, postmortem.status? 'HTTP: ' + postmortem.status : 'OTHER: ' + postmortem.error);
    	if (postmortem.status && [404].indexOf(postmortem.status) < 0) {
    		console.log('...Ask for re-crawling when possibily recoverable failure/error returned from web server');
    		return true;
    	}
    	if (postmortem.error && ['EAI_AGAIN', 'ETIMEDOUT', 'ECONNRESET'].indexOf(postmortem.error.code) >= 0) {
    		console.log('...Ask for re-crawling in case of: 1. name resolving error, 2. timeout, 3. connection reset');
    		return true;
    	}
    	return false;

    //onFailure 返回true就是自动重新发起请求,再次爬取
  	},
	onAllFinished: function() {
		console.log('All crawling are finished');
		asyncRecordStreamer.stop();
  	}
})
.crawl(startPage);






























