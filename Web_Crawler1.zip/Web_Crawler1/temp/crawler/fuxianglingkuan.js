

    var temphtml1 = '<div class="item spot_list">' + 
    '<ul class  ="summary_list_box">' +
       '<li> <p class="summary_ttl">' + 
        '<a href= class="ico_kankospot">錦市場v    <em></a>'
    
        var temphtml2 = 'Give <g>nisng\n</g>i8t'

    filterHtml(temphtml2)

function filterHtml (html) {
    var patt1 = 


    var result = patt1.exec(html)

    console.log(result)
}
















