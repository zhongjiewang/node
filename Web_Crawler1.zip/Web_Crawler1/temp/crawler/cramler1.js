
'use strict';
//const 也用来声明变量，但是声明的是常量。一旦声明，常量的值就不能改变。
//const 的作用域与 let 命令相同：只在声明所在的块级作用域内有效。
const userAgent = 'crawler@tourank';

//替换与正则表达式匹配的子串。
// 1.先放一个[],用于查找方括号之间的任何字符
//2. | 查找任何指定的选项
//3.  . 元字符 查找单个字符，除了换行和行结束符。
//4. n* 匹配任何包含零个或多个 n 的字符串。
//5. n? 匹配任何包含零个或一个 n 的字符串。
//6. ^n 匹配任何开头为 n 的字符串。
//7. n$   匹配任何结尾为 n 的字符串。
//需要常规的字符转义规则（在前面加反斜杠 \）
RegExp.escape = function(s) { return s.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&'); };


const startPage = 'https://gurunavi.com/en/rs/srh/',
//餐馆页面
    restaurantListPageRegEx = /^https:\/\/gurunavi\.com\/en(.*?)\/rs\/srh\/(.*?)$/ig;

// list page related markers
const restaurantListBeginsMarker = '<div class="main -right">',
    restaurantListEndsMarker = '<ul class="horizontal-item horizontal-list -with-button-small">',
    restaurantBeginsMarker = '<section>',
    restaurantEndsMarker = '</section>';
    
const crawlerDatabase = 'mongodb://localhost:27017/crawler',
    restaurantLinkCollName = 'restaurantLinks';

var Crawler = require('js-crawler'),
    co = require('co'),
    _ = require('underscore'),
    keypress = require('keypress'),
    log4js = require('log4js'),
    AsyncStreamer = require('./async-streamer/asyncmongostreamer');

log4js.configure({
  appenders: [
    { type: 'console' },
    { type: 'file', filename: '/var/log/tourank/crawler.log' }
  ]
});

log4js.replaceConsole();

// make `process.stdin` begin emitting "keypress" events
var crawler = null;

keypress(process.stdin);
 
// listen for the "keypress" event 
process.stdin.on('keypress', function (ch, key) {
    if (key.name === 'space') {
        console.log('space key pressed');
        if (crawler) {
            crawler.dump();
            console.log('-------- issued --------')
            console.log('.restaurantIds.length: %d', restaurantIds.length);
            restaurantIds.sort();
            for (let id of restaurantIds) {
                console.log('\t%s', id);
            }
        }
    }
    if (key && key.ctrl && key.name == 'c') {
        process.stdin.pause();
    }
});
 
process.stdin.setRawMode(true);
process.stdin.resume();

var asyncRecordStreamer = new AsyncStreamer({
    url: crawlerDatabase,
    collection: restaurantLinkCollName
});

var onceForAll = false;
asyncRecordStreamer.start();

var restaurantIds = [];

//i 执行大小写不敏感的匹配
// g 执行全局匹配(查找所有匹配而非找到第一个匹配后停止)
// m 执行多行匹配
function parseAndRequestRestaurantLists(crawler, content) {
    //返回content字符串中匹配前边表达式的值,也就是说以前边表达式的为基准的值,返回值只是content中的一部分
    let matches = /<a href="(https:\/\/gurunavi\.com\/en(.*?)\/rs\/srh\/)\?p=([0-9]+?)">Last<\/a>/img.exec(content);
    if (matches) {
        let lastPage = parseInt(matches[3]);
        for (let i = 2; i <= lastPage; i++) {
            crawler.enqueueRequest({url: matches[1] + '?p=' + i}, 1);
        }
        console.log('Found and requested page#2 to page#%d', lastPage);
    }
}

function parseAndStreamRestaurantLinks(content, url) {
    let narrowed = content.substring(content.indexOf(restaurantListBeginsMarker) + restaurantListBeginsMarker.length);
    narrowed = narrowed.substring(0, narrowed.indexOf(restaurantListEndsMarker));
    let idx = -1;
    let count = 0;
    let issuedCount = 0;
    while (idx = narrowed.indexOf(restaurantBeginsMarker) >= 0) {
        let endIdx = narrowed.indexOf(restaurantEndsMarker);
        let restaurantSection = narrowed.substring(idx + restaurantBeginsMarker.length, endIdx);
        narrowed = narrowed.substring(endIdx + restaurantEndsMarker.length);
        let matches = /<a[^>]+?href="(.+?)"/img.exec(restaurantSection);
        if (matches) {
            count++;
            let id = /^https:\/\/gurunavi\.com\/en\/(.+?)\/rst\/$/ig.exec(matches[1])[1];
            if (!_.contains(restaurantIds, id)) {
                issuedCount++;
                asyncRecordStreamer.commit({//对数据库的封装
                    crawler: 'gurunaviEnRestaurantLinksCrawler',
                    website: 'gurunavi.com',
                    country: 'jp',
                    language: 'en',
                    id: id,
                    href: url,
                    name: /&nbsp;(.+?)<\/p>/g.exec(restaurantSection)[1].trim(),
                    url: matches[1],
                    crawledAt: new Date()
                });
                restaurantIds.push(id);
            }
        }
    }
    console.log('Found %d restaurants and streamed %d ones - %s', count, issuedCount, url);
}
    
crawler = new Crawler()
.configure({
    ignoreRelative: false, //忽视相关的
    depth: 2,
    userAgent: userAgent, // 'crawler@tourank' //用户代理
    maxConcurrentRequests: 10,//最大并发数
    oblivious: true,//不知道的
    shouldCrawl: function(url) {
        return true;
    },

//获取每个成功爬取页面的url
    onSuccess: function(page) {
        // console.log('Received content from %s', page.actualUrl);
        if (page.actualUrl == startPage && !onceForAll) {
            parseAndRequestRestaurantLists(this, page.body);
            onceForAll = true;
        }
        if (page.actualUrl.match(restaurantListPageRegEx)) {
            parseAndStreamRestaurantLinks(page.body, page.actualUrl);
        }
    },

    onFailure: function(postmortem) {
        console.log('Failed to crawl %s (%s)', postmortem.url, postmortem.status? 'HTTP: ' + postmortem.status : 'OTHER: ' + postmortem.error);
        if (postmortem.status && [404].indexOf(postmortem.status) < 0) {
            console.log('...Ask for re-crawling when possibily recoverable failure/error returned from web server');
            return true;
        }
        if (postmortem.error && ['EAI_AGAIN', 'ETIMEDOUT', 'ECONNRESET'].indexOf(postmortem.error.code) >= 0) {
            console.log('...Ask for re-crawling in case of: 1. name resolving error, 2. timeout, 3. connection reset');
            return true;
        }
        return false;
    },
//把成获取的地址以数组的形势返回
    onAllFinished: function() {
        console.log('All crawling are finished');
        asyncRecordStreamer.stop();
    }
})
.crawl(startPage);









































