//crawler 
//crawler  读音 kerole
 //英  ['krɔːlə]   美  ['krɔlɚ
//The basic design of this crawler is to load the first link to check onto a queue.
//这个爬虫的基本设计是加载第一个链接并将其放入一个队列。 

//相当于jquery,能够操作装载后的html
var cheerio = require('cheerio')

var http = require('http')

var  url = require('url')

var Buffer = require('buffer').Buffer;
var Iconv  = require('iconv').Iconv;
var assert = require('assert');

var Encoding = require('encoding-japanese');

var BufferHelper = require('bufferhelper');
// var urlstr = 'http://4travel.jp/domestic/area/okinawa/okinawa/hontohokubu/motobu/zoo/10000190/'
// var urlstr = 'http://4travel.jp/search/shisetsu/dm?category_group=kankospot&sa=%E5%9B%BD%E5%86%85'
// var urlstr = 'http://4travel.jp/domestic/area/kanto/chiba/maihamaurayasu/tokyodisneyresort/themepark/11187263/'
// var urlstr = 'http://4travel.jp/domestic/area/chugoku/hiroshima/miyajima/miyajima/temple/10002779/'
    var urlstr =  'http://4travel.jp/domestic/area/hokkaido/hokkaido/asahikawa/asahikawa/zoo/10000013/'


var arr = [];

http.get(urlstr,function (res) {
    // var html = ''
    var bufferHelper = new BufferHelper();

    res.on('data',function (data) {
        // console.log(data)
        // html +=data 
        let  buf = new Buffer(data)

        arr.push(buf)

        // console.log(buf.length)
          // console.log(buf.toString())  
                // console.log(data)
        // data+=data;
        // var iconv = new Iconv('EUC-JP','UTF-8');
        // var buffer = iconv.convert(data);

        // console.log(buffer);
        // console.log(buffer.toString('utf-8'))
        // bufferHelper.concat(chunk);

    })

    res.on('end',function (data){

       let buff3 = Buffer.concat(arr)

       console.log(buff3)

       let  utf8Array = Encoding.convert(buff3, {
                to: 'UTF8',
                from: 'EUCJP'
            });
       let strHtml = new Buffer(utf8Array)
        // console.log( utf8Array.toString('utf-8') );
        // let strHtml = Buffer.concat(utf8Array)

        console.log(strHtml.toString())

       // console.log(buff3.length)

       // let  iconv = new Iconv('EUC-JP','UTF-8');
       //  let bufferE = iconv.convert(buff3);

       //  console.log(bufferE.toString('utf-8'))
        // console.log(data)
        // console.log(html)
        // filterChapters(html)//删选章节内容
        // var html = bufferHelper.toBuffer().toString();
        // console.log(html)
    })
}).on('error',function (){
    console.log('获取课程数据出错')
})

// 
function filterChapters (html) {

    var $ = cheerio.load(html)
    var chapters = $('.port_1').text()
    console.log(chapters)
    console.log(typeof chapters)
}


// console.log(url.parse(urlstr))


/*
function filerexm (html) {
    var $ = cheerio.load(html)
    
    var chapters = $('.learnchapter')//拿到所有大章

    // [{
    //     chpterTitle:'',
    //     videos:[
    //         title:'',
    //         id:''
    //     ]
    // }] 

    var courseData = []

    chapters.each(function(item) {
        var chapter = $(this)//拿到单独的每一章

        var chapterTitle = chapter.find('.strong').text()//拿到里边的文本内容

        var videos = chapter.find('.video').children('li')

        var chapterData = {
            chapterTitle:chapterTitle,
            videos:[]
        }

        videos.each(function (item) {
            var video = $(this).find('.studyvideo')

            var videoTitle = video.text()

            var id = video.attr('href').spilt('/video')[1]

            chapterData.videos.push({
                title:videoTitle,
                id:id
            })

        })

        courseData.push(chapterData)

    })

    return courseData
}

*/


































































