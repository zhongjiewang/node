﻿#!/usr/bin/env node
'use strict';

const userAgent = 'crawler@tourank';
RegExp.escape = function(s) { return s.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&'); };

// details page related markers
const restaurantInfoBeginsMarker = '<div class="shop-information">',
	restaurantInfoEndsMarker = '</div><!-- /cassette -->',
	creditCardMarker = '<span class="card-icon">',
	freeWiFiMarker = '<span class="wifi-icon">',
	privateRoomMarker = '<span class="private-room-icon">',
	noSmokingMarker = '<span class="no-smoking-icon">',
	englishMenuMarker = '<span class="english-menu-icon">',
	smokingMarker = '<span class="smoking-icon">',
	englishStaffMarker = '<span class="english-ok-icon">',
	restaurantDetailBeginsMarker = '<div id="restaurantdetail" class="cassette triple-spacing" itemscope="" itemtype="http://schema.org/Restaurant">',
	restaurantDetailEndsMarker = '<div class="cassette double-spacing">';

const generalInfoProcessorMap = {
	'<span class="menu-icon">': function(obj, content) {
		obj.menu = removeCrLnAndUnescape(/<\/span>([^]+?)<\/li>/ig.exec(content)[1]).trim().split(',');
		return obj;
	},
	'<span class="price-icon">': function(obj, content) {
		obj.price = removeCrLnAndUnescape(/<\/span>([^]+?)<\/li>/ig.exec(content)[1]).trim();
		return obj;
	},
	'<span class="tel-icon">': function(obj, content) {
		obj.telephone = /<\/span>([^]+?)<\/li>/ig.exec(content)[1].trim();
		return obj;
	},
	'<span class="location-icon">': function(obj, content) {
		let matches = /<\/span>([^]+?)<br\/>([^]+?)<\/li>/ig.exec(content);
		matches = /^(.+?)\((.+?)\)$/ig.exec(removeCrLnAndUnescape(matches[1]).trim());
		if (matches) {
			obj.region = matches[1];
			obj.prefecture = matches[2];
		}
		return obj;
	}
};

const detailInfoProcessorMap = {
	'<th>Address </th>': function(obj, content) {
		obj.address = /<p class="sentence spacing">([^]+?)<\/p>/ig.exec(content)[1].trim();
		return obj;
	},
	'<th>Access</th>': function(obj, content) {
		obj.access = removeEmptyItems(removeCrLnAndUnescape(/<td>([^]+?)<\/td>/ig.exec(content)[1]).trim().split(', '));
		return obj;
	},
	'<th>Hours</th>': function(obj, content) {
		obj.bizHours = removeEmptyItems(removeCrLnAndUnescape(/<td>([^]+?)<\/td>/ig.exec(content)[1]).trim().split('<br />'));
		return obj;
	},
	'<th>Parking</th>': function(obj, content) {
		obj.parking = removeCrLnAndUnescape(/<td>([^]+?)<\/td>/ig.exec(content)[1]).trim();
		return obj;
	},
	'<th>Close</th>': function(obj, content) {
		obj.close = removeEmptyItems(removeCrLnAndUnescape(/<td>([^]+?)<\/td>/ig.exec(content)[1]).trim().split('<br />'));
		return obj;
	},
	'<th>Cards accepted</th>': function(obj, content) {
		obj.acceptedCards = removeEmptyItems(removeCrLnAndUnescape(/<td>([^]+?)<\/td>/ig.exec(content)[1]).trim().split(', '));
		return obj;
	},
	'<th>Seating Capacity</th>': function(obj, content) {
		obj.totalSeats = removeCrLnAndUnescape(/<td>([^]+?)<\/td>/ig.exec(content)[1]).trim();
		return obj;
	},
	'<th>Banquet Maximum Party Size</th>': function(obj, content) {
		obj.maxBanquetSize = removeEmptyItems(removeCrLnAndUnescape(/<td>([^]+?)<\/td>/ig.exec(content)[1]).trim().split('<br />'));
		return obj;
	},
	'<th>Reservation Maximum Party Size</th>': function(obj, content) {
		obj.maxReservationSize = removeCrLnAndUnescape(/<td>([^]+?)<\/td>/ig.exec(content)[1]).trim();
		return obj;
	},
	'<th>Wheelchair Accessible Restrooms</th>': function(obj, content) {
		obj.disabledFacilities = removeEmptyItems(removeCrLnAndUnescape(/<td>([^]+?)<\/td>/ig.exec(content)[1]).trim().split(', '));
		return obj;
	},
	'<th>Kid Friendly</th>': function(obj, content) {
		obj.kidFacilities = removeEmptyItems(removeCrLnAndUnescape(/<td>([^]+?)<\/td>/ig.exec(content)[1]).trim().split(', '));
		return obj;
	},
	'<th>Wi-Fi  /  Plug-in</th>': function(obj, content) {
		let items = removeCrLnAndUnescape(/<td>([^]+?)<\/td>/ig.exec(content)[1]).trim().split('<br />');
		obj.mobileDataServices = items[0].split(', ');
		items.splice(0, 1);
		obj.wiFiAndPower = items;
		return obj;
	},
	'<th>Take-out (Take-away)</th>': function(obj, content) {
		obj.takeAway = removeCrLnAndUnescape(/<td>([^]+?)<\/td>/ig.exec(content)[1]).trim();
		return obj;
	},
	'<th>Other</th>': function(obj, content) {
		obj.other = removeEmptyItems(removeCrLnAndUnescape(/<td>([^]+?)<\/td>/ig.exec(content)[1]).trim().split('<br />'));
		return obj;
	},
	'<th>Menu</th>': function(obj, content) {
		obj.menuOptions = removeEmptyItems(removeCrLnAndUnescape(/<td>([^]+?)<\/td>/ig.exec(content)[1]).trim().split(', '));
		return obj;
	},
	'<th>Lunch Service</th>': function(obj, content) {
		obj.lunchServices = removeEmptyItems(removeCrLnAndUnescape(/<td>([^]+?)<\/td>/ig.exec(content)[1]).trim().split(', '));
		return obj;
	},
	'<th>Dress Code</th>': function(obj, content) {
		obj.dressCode = removeEmptyItems(removeCrLnAndUnescape(/<td>([^]+?)<\/td>/ig.exec(content)[1]).trim().split(', '));
		return obj;
	}
};

const crawlerDatabase = 'mongodb://localhost:27017/crawler',
	restaurantLinkCollName = 'restaurantLinks',
	restaurantCollectionName = 'restaurants';

var Crawler = require('js-crawler'),
	mongoClient = require('mongodb').MongoClient,
	co = require('co'),
	log4js = require('log4js'),
	AsyncStreamer = require('./async-streamer/asyncmongostreamer');

log4js.configure({
  appenders: [
    { type: 'console' },
    { type: 'file', filename: '/var/log/tourank/crawler.log' }
  ]

});

log4js.replaceConsole();

var crawler = null;

var asyncRecordStreamer = new AsyncStreamer({
	url: crawlerDatabase,
	collection: restaurantCollectionName
});

asyncRecordStreamer.start();

function removeCrLnAndUnescape(s) {
	return s.replace(/[\r\n]/mg, '')
		.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"')
		.replace(/&rArr;/g, '⇒').replace(/&#039;/g, '\'').replace(/&hellip;/g, '…')
		.replace(/&amp;/ig, '&');
}

function removeEmptyItems(array) {
	for (let i = 0; i < array.length; i++) {
		if (array[i] == '') {
			array.splice(i, 1);
		}
	}
	return array;
}

function logTopLines(str, n) {
	let idx = -1;
	for (let i = 0; i < n; i++) {
		let newIdx = str.indexOf('\n', idx + 1);
		if (newIdx < 0) break;
		else idx = newIdx;
	}
	
	if (idx <= 0) console.log(str);
	else console.log(str.substring(0, idx));
}

function htmlUnescape(s) {
	let escapeTable = {
		'&times;': '×',
		'&ldquo;': '“',
		'&rdquo;': '”',
		'&lsquo;': '‘',
		'&rsquo;': '’',
		'&deg;': '°',
		'&rarr;': '→',
		'&pi;': 'π',
		'&Omega;': 'Ω',
		'&omega;': 'ω',
		'&infin;': '∞',
		'&hellip;': '…',
		'&alpha;': 'α',
		'&beta;': 'β',
		'&Eacute;': 'É'
	};
	
	return s.replace(/&[^ ]+?;/g, function(m) {
		return escapeTable[m]? escapeTable[m] : m;
	});
}

function parseAndStreamRestaurantDetail(content, url, id) {
	let restaurant = {
		crawler: 'gurunaviEnRestaurantDetailsCrawler',
		source: 'gurunavi.com',
		country: 'jp',
		language: 'en',
		href: url,
		id: id,
		crawledAt: new Date()
	};
	let narrowed = content.substring(content.indexOf(restaurantInfoBeginsMarker) + restaurantInfoBeginsMarker.length);
	let restaurantInfo = removeCrLnAndUnescape(narrowed.substring(0, narrowed.indexOf(restaurantInfoEndsMarker)));
	restaurant.name = htmlUnescape(/<h1 class="jumbo break\-word">(.+?)<\/h1>/img.exec(restaurantInfo)[1].trim());
	restaurant.localName = htmlUnescape(/<p class="small">(.+?)<\/p>/img.exec(restaurantInfo)[1].trim());
	
	let matches = restaurantInfo.match(/<span class=".+?">/img);
	for (let match of matches) {
		let func = generalInfoProcessorMap[match];
		if (func) {
			restaurant = func.apply(null, [restaurant, restaurantInfo.substring(restaurantInfo.indexOf(match) + match.length)]);
		}
		/*
		else {
			console.log('Unprocessed general info: %s', match);
		}
		*/
	}
	
	restaurant.amenities = [];
	if (restaurantInfo.indexOf(creditCardMarker) >= 0) restaurant.amenities.push('Credit Card');
	if (restaurantInfo.indexOf(freeWiFiMarker) >= 0) restaurant.amenities.push('Free Wi-Fi');
	if (restaurantInfo.indexOf(privateRoomMarker) >= 0) restaurant.amenities.push('Private Room');
	if (restaurantInfo.indexOf(noSmokingMarker) >= 0) restaurant.amenities.push('No Smoking');
	if (restaurantInfo.indexOf(smokingMarker) >= 0) restaurant.amenities.push('Smoking');
	if (restaurantInfo.indexOf(englishMenuMarker) >= 0) restaurant.amenities.push('English Menu');
	if (restaurantInfo.indexOf(englishStaffMarker) >= 0) restaurant.amenities.push('English Speaking Staff');
	
	let restaurantDetail = content.substring(content.indexOf(restaurantDetailBeginsMarker) + restaurantDetailBeginsMarker.length);
	restaurantDetail = restaurantDetail.substring(restaurantDetail, restaurantDetail.indexOf(restaurantDetailEndsMarker));
	
	matches = restaurantDetail.match(/<th>.+?<\/th>/img);
	for (let match of matches) {
		let func = detailInfoProcessorMap[match];
		if (func) {
			restaurant = func.apply(null, [restaurant, restaurantDetail.substring(restaurantDetail.indexOf(match) + match.length)]);
		}
		/*
		else {
			console.log('Unprocessed detail info: %s', match);
		}
		*/
	}
	
	let latitude = /<meta itemprop="latitude" content="(.+?)">/img.exec(restaurantDetail)[1];
	let longitude = /<meta itemprop="longitude" content="(.+?)">/img.exec(restaurantDetail)[1];
	restaurant.geoCoordinates = {
		lat: parseFloat(latitude),
		lon: parseFloat(longitude)
	}
	asyncRecordStreamer.commit(restaurant);
	console.log('Restaurant %s(%s) was parsed and streamed - %s', restaurant.name, restaurant.localName, url);
	// console.log(restaurant);
}
	
crawler = new Crawler()
.configure({
	ignoreRelative: false, 
	depth: 1,
	userAgent: userAgent,
	maxConcurrentRequests: 10,
	oblivious: true,
	shouldCrawl: function(url) {
		return true;
	},
	onSuccess: function(page) {
		console.log('Received content from %s', page.actualUrl);
		parseAndStreamRestaurantDetail(page.body, page.actualUrl, page.options.id);
	},
	onFailure: function(postmortem) {
    	console.log('Failed to crawl %s (%s)', postmortem.url, postmortem.status? 'HTTP: ' + postmortem.status : 'OTHER: ' + postmortem.error);
    	if (postmortem.status && [404].indexOf(postmortem.status) < 0) {
    		console.log('...Ask for re-crawling when possibily recoverable failure/error returned from web server');
    		return true;
    	}
    	if (postmortem.error && ['EAI_AGAIN', 'ETIMEDOUT', 'ECONNRESET', 'ESOCKETTIMEDOUT'].indexOf(postmortem.error.code) >= 0) {
    		console.log('...Ask for re-crawling in case of: 1. name resolving error, 2. timeout, 3. connection reset, 4. socket timeout');
    		return true;
    	}
    	return false;
  	},
	onAllFinished: function() {
		console.log('All crawling are finished');
		asyncRecordStreamer.stop();
  	}
});

co(function *() {
	let db = yield mongoClient.connect(crawlerDatabase);
	let linkColl = db.collection(restaurantLinkCollName);
	let records = yield linkColl.find({
		website: 'gurunavi.com',
		language: 'en'
	}).toArray();
	yield db.close();

	
	console.log(`${records.length} restaurants will be crawled`);
	crawler.crawl();	
	for (let record of records) {
		crawler.enqueueRequest({
			url: record.url,
			timeout: 30000,	// this option is very important 'coz sometimes this website will pend responding (forever!) and then the accumulated pending requests will exceed the concurrent threshold thus prevent the web crawler (forever!) from issuing other requests
			id: record.id
		});
	}
})
.catch(err => { console.error(err.stack); });


Error.stackTraceLimit = 15 //控制显示错误堆栈的行数














































