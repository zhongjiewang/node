'use statics'

var http = require('http');

var keypress = require('keypress')

http.createServer(function (request, response) {

    // 发送 HTTP 头部 
    // HTTP 状态值: 200 : OK
    // 内容类型: text/plain
    response.writeHead(200, {'Content-Type': 'text/plain'});

    // 发送响应数据 "Hello World"
    response.end('Hello World\n');
}).listen(8888);

// 终端打印如下信息
console.log('Server running at http://127.0.0.1:8888/');



// var err;

// if (err) {
//   process.exit(1);
// } else {

//     console.log('错误为0')
//   process.exit(0);
// }
//process对象是监听标准输入
// process.stdin.resume();

keypress(process.stdin);


// process.stdin.setEncoding('utf8');
// process.stdin.on('keypress', function(data) {
//   process.stdout.write(data);
//   process.stdout.write('gggggggg');
//   console.log('标准输入')
// });

process.stdin.on('keypress', function (ch, key) {

    if (key.name === 'space') {
        console.log('space key pressed');
        // if (crawler) {
        //     crawler.dump();
        //     console.log('-------- issued --------')
        //     console.log('.restaurantIds.length: %d', restaurantIds.length);
        //     restaurantIds.sort();
        //     for (let id of restaurantIds) {
        //         console.log('\t%s', id);
        //     }
        // }
    }

    console.log(key.name)

    if(key.name === 't') {
        //pause()是标准输入暂停,这样之后点击键盘没有反应了
        process.stdin.pause()
    }

    // if (key && key.ctrl && key.name == 'c') {
    //     process.stdin.pause();
    // }
});
 
process.stdin.setRawMode(true);

process.stdin.resume();






















