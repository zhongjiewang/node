'use strict'

var http = require('http')

var  url = require('url')

// var urlstr = 'http://bj.aura.cn/it/index.html?ka=projectExperience-URL'

const baseUrl = 'http://4travel.jp/search/shisetsu/dm?breadcrumb_id=37&category_group=kankospot&page='; 

const homeUrl = '&sa=%E5%9B%BD%E5%86%85' 

const urlstr = baseUrl.concat('1',homeUrl)

// http.get(urlstr,function (res) {
//     var html = ''
//     res.on('data',function (data) {
//         html +=data 
//     })

//     res.on('end',function (){
        
//         // filterChapters(html)//删选章节内容
//         // console.log(html)
//         // console.log(html.length)
        
        var temphtml1 = '<div class="item spot_list">' + 
    '<ul class  ="summary_list_box">' +
       '<li> <p class="summary_ttl">' + 
        '<a href= class="ico_kankospot">錦市場v    <em></a>'
    
        var temphtml2 = 'Give <g>nisng\n</g>i8t'

// // var temphtml = "Visit W3School, W3School is a W3School place to study web technology."; 

// //         filterChapterC(temphtml)
//     })
// }).on('error',function (){
//     console.log('获取课程数据出错')
// })

// var temphtml = "Visit W3SchoolW3School is a W3School place to study web technology."; 

    filterChapterC(temphtml2)

function filterChapterC (html) {
    console.log(html)
    // var patt = new RegExp('ico_kankospot\">.+<\/a>',"g");
    // var patt = new RegExp('<\w>.{0,}\n{0,2}<\/\w>','g')
    var patt = /<\w>.{0,}\n{0,2}<\/\w>/img
    var patt1 = /<(\S*?)[^>]*>.*?<\/>/img
    //用到\d \w类似的正则元字符时,在构造函数中需要用下转义字符,不然函数解析成,字母了,因为你是放在了一个字符串中
    var result;

    // // while ((result = patt.exec(html)) != null)  {
    //     var arr = patt.exec(html) //特别注意他返回的是一个数组,但是这个数组只有一个元素,就是匹配的值
    //     //而 index input不是数组的元素,是他给这个数组添加的属性
    //     console.log(arr)
    //     console.log(arr.length)
    //     console.log(arr instanceof Array)
    //     console.log(arr[0])
    //     console.log(arr.input)
    //     // console.log(arr.toSource())
    //     var temarr = [1,2,{name:'xiaoming',gen:'nan'}]
    //     console.log(temarr.index)
    //     // console.log(arr.join('//'))
    //     console.log(arr.concat(temarr))

    //  // }
    console.log(patt1.exec(html))
    // console.log(html.match(/<\w>.{0,}\n{0,2}<\/\w>/img));

    // while((result = patt.exec(html)) != null) {
    //     console.log(result)
    //     console.log(patt.lastIndex)
    // }  
}

function filterChaptersB (html) {

    var patt1 = /ico_kankospot/img

    var arr = patt1.exec(html)
    // var indexObj = patt1[1]
    // var index = indexObj.index;

    // console.log(patt1)
    console.log(arr)
    console.log(arr instanceof Array)
    console.log(arr.length)

}


function filterChaptersA (html) {
    // var str  = 'str'
    console.log(html.length)
    var patt1 = /spot"\>/img.exec(html)
    console.log(patt1)
    var patt2 = /<\/a>/img.exec(html)
    console.log(patt2)
    console.log(patt1 instanceof Array)
    console.log(html.slice(0,1))//slice 不包括最后的下标,对应的是接着,注意是接着要抽取得字符串片段的下标
    //不修改原始的字符串
    console.log(html.length)
}



















































