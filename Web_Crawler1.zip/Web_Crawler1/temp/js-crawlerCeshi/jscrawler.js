
var Crawler = require('js-crawler');
var crawler = new Crawler();
//// userAgent: userAgent,
const startPage = 'http://www.emingren.com';

//核心在第二个值,如果第一个为假,则直接返回第一个值, 如果第一个值为真,则直接返回第二个值
//用&& 或时,我们往往是想得到第二个值,
// var det = (true  && 5) ;

//用||时,我们往往想得到第一个值, 两者共同点是, 真假的判断只在第一个值, 第二个值的真假不重要,不做判断
//||或运算符的核心在第一个值,如果第一个值为真,则直接返回第一个值,如果为假,则返回第二个值,第二个值的真假不重要;
// var det = 'ddd' || 'ddds';

// console.log(det)
 
// var det = 9 < 8;

// console.log(det)   

// crawler.temp(5);
// var a = crawler.shouldCrawl();

var options = {}
options['!@#id#@!'] = 1;

console.log(options)
// crawler.crawl('https://www.baidu.com/');

// console.log(a)
// crawler.configure({
//     ignoreRelative: false, 
//     depth: 1,
//     maxConcurrentRequests: 10,
//     oblivious: true,
//     enableTimeOut:true,//if timeOut ,will exec the onFailure
//     shouldCrawl: function(url) {
//         return true;
//     },
//     onSuccess: function(page) {
//         console.log('Received message from: %s', page.actualUrl);
//     },
//     onFailure: function(postmortem) {
//         console.warn('Failed to crawl %s (%s)', postmortem.url, postmortem.status? 'HTTP: ' + postmortem.status : 'OTHER: ' + postmortem.error);
//         if (postmortem.status && [404].indexOf(postmortem.status) < 0) {
//             console.error('...Ask for re-crawling when possibily recoverable failure/error returned from web server');
//             return true;
//         }
//         if (postmortem.error && ['EAI_AGAIN', 'ETIMEDOUT', 'ECONNRESET'].indexOf(postmortem.error.code) >= 0) {
//             console.error('...Ask for re-crawling in case of: 1. name resolving error, 2. timeout, 3. connection reset');
//             return true;
//         }
//        // if return false,no crawler, if return true,mean will request again,
//         return false;
//     },
//     onAllFinished: function() {
//         console.log('All crawling are finished');
//     }
// })
// .crawl(startPage);



















































