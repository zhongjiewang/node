'use strcit'

var co = require('co')

co(function* () {
  var result =  Promise.resolve({name:'nihao'});
  var a = Promise.resolve({name:'xxxxxx'});

  var res = yield [result,a]
  console.log(res)
  return res;

}).then(function (value) {
  console.log(value);


}, function (err) {
  console.error(err.stack);
});



// co(function *() {
//     // var str  = yield new Promise(function(resolve, reject){
//     //     resolve('nnnnnnnnn');
//     // })
//     var str = yield 'dddd'
//     console.log(str);
//     var db = yield 'xxxx'
//     // console.log(str + db)
//     console.log('ni');

// })
// .catch(err => { console.error(); });



