



  var   keypress = require('keypress');

keypress(process.stdin);


// listen for the "keypress" event 
process.stdin.on('keypress', function (ch, key) {
    // if (key.name === 'space') {
    //     console.log('space key pressed');

    // }

    if (key && key.name === 'space') {
        console.log('33333333333333')


        // process.exit(1);

    }
    console.log(key);
    if (key && key.ctrl && key.name == 'c') {
        process.exit(1);
    }
});
 //原始的,未加工的,
process.stdin.setRawMode(true);
process.stdin.resume();


console.log('111111111')



console.log('2222222222')





















