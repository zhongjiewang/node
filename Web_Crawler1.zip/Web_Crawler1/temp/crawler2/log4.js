'use strict'

var log4js = require('log4js');
log4js.configure({
  appenders: [
    { type: 'console' }
    //这里是手动配置日志的
    // { type: 'file', filename: 'cheese.log', category: 'cheese' }
  ],
   replaceConsole: true
});

// console.debug('错误')
// console.trace('Entering cheese testing');//
console.debug('我是蓝色'); //蓝色
console.info('console.info打印出来是绿色');//绿色;以后打印信息可以使用这个,这样方便区分
console.warn('这是预警色,棕黄色');//棕黄色
console.error('错误,红色,以后用这个打印错误信息,搜索前边的表示,可以立马定位错误');//红色,以后打印错误要用这个
// console.fatal('Cheese was breeding ground for listeria.');


var a = 'ls';
var b = 'sd';
var str = 'lsggllsdhdd';
//eval. 重新运算求出参数的内容
var regedp =  eval('/'+a+'g{0,2}\\w{2}'+b+'/ig') ;


var cone = regedp.exec(str)
console.log(cone)



























































