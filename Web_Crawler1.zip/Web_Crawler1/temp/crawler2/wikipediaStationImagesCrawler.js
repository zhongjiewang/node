﻿#!/usr/bin/env node
'use strict';

const userAgent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36';

const crawlerDatabase = 'mongodb://localhost:27017/crawler',
	stationLinkCollName = 'wikiStationList',
	stationCollName = 'wikiStations';

const FOLDER_TO_STORE = '/galleries/wikipedia.org/stations/';

const Crawler = require('js-crawler'),
	mongoClient = require('mongodb').MongoClient,
	co = require('co'),
	fs = require('fs'),
	url = require('url'),
	_ = require('underscore'),
	log4js = require('log4js'),
	AsyncStreamer = require('async-streamer');

require('./util-exts.js');

log4js.configure({
  appenders: [
    { type: 'console' },
    { type: 'file', filename: '/var/log/tourank/crawler.log' }
  ]
});

log4js.replaceConsole();

var asyncStreamer = new AsyncStreamer({
	url: crawlerDatabase,
	collection: stationCollName
})
.start();

function saveStationImage(stationName, content, link) {
	let name = link.substring(link.lastIndexOf('/') + 1);
	// console.log(name);
	let pathName = `${FOLDER_TO_STORE}${stationName}/${name}`;
	// console.log(pathName);
	if (!fs.existsSync(pathName)) {
		fs.writeFileSync(pathName, content, {encoding: null});
		console.log('Image %s was saved as %s', name, pathName);
	}
}

function parseAndRequestImage(stationName, content, link, crawler) {
	let hrefMatch = /<div class="fullImageLink" id="file"><a href="(.+?)"/g.exec(content);
	if (hrefMatch) {
		console.log('Requesting %s...', url.resolve(link, hrefMatch[1]));
		crawler.enqueueRequest({
			url: url.resolve(link, hrefMatch[1]),
			type: 'img',
			stationName: stationName
		}, 1, true);
	}
}

function parseAndStreamStationDetails(content, link, crawler) {
	const roi = {
		'所在地':		'address',
		'所属事業者':	'operator',
		'所属路線':		'line',
		'駅構造':		'structure',
		'開業年月日':	'openedAt'
	};
	
	let name = /<h1.+?>(.+?)<\/h1>/g.exec(content)[1];
	let stationInfo = {
		source: 'wikipedia.org',
		href: link,
		name: name,
		crawledAt: new Date()
	}
	
	let narrowed = content.substring(content.indexOf('<table class="infobox bordered"'), content.indexOf('</table>'));
	let rowPattern = /<tr.+?>([^]+?)<\/tr>/mg;
	let match = null;
	let imgFound = false;
	while (match = rowPattern.exec(narrowed)) {
		let rowContent = match[1].replace(/[\r\n]/g, '').unescapeHtml();
		// console.log(rowContent);
		let smatch = /<th.+?>(.+?)<\/th>/g.exec(rowContent);
		if (smatch) {
			let th = smatch[1].replace(/<.+?>/g, '').trim();
			// console.log(th);
			let td = /<td.+?>(.+?)<\/td>/g.exec(rowContent)[1].replace(/<.+?>/g, '').trim();
			// console.log(td);
			let field = roi[th];
			if (field) stationInfo[field] = td;
		}
		if (!imgFound) {
			let hrefMatch = /<a href="([^>]+?)" class="image"/mg.exec(match[1]);
			if (hrefMatch) {
				imgFound = true;
				if (!fs.existsSync(`${FOLDER_TO_STORE}${name}`)) {
					fs.mkdirSync(`${FOLDER_TO_STORE}${name}`);
					console.log('Requesting %s...', url.resolve(link, hrefMatch[1]));
					crawler.enqueueRequest({
						url: url.resolve(link, hrefMatch[1]),
						type: 'imgpage',
						stationName: name
					}, 1, true);
				}
			}
		}
	}
}

var crawler = new Crawler()
.configure({
	ignoreRelative: false, 
	depth: 1,
	userAgent: userAgent,
	maxConcurrentRequests: 10,
	oblivious: true,
	enableTimeOut: true,
	shouldCrawl: function(url) {
		return true;
	},
	onSuccess: function(page) {
		console.log('Received message from: %s', page.actualUrl);
		if (page.options.type) {
			if (page.options.type === 'imgpage') parseAndRequestImage(page.options.stationName, page.body, page.actualUrl, this);
			else saveStationImage(page.options.stationName, page.body, page.actualUrl);
		} else parseAndStreamStationDetails(page.body, page.actualUrl, this);
	},
	onFailure: function(postmortem) {
    	console.log('Failed to crawl %s (%s)', postmortem.url, postmortem.status? `HTTP: ${postmortem.status}` : `OTHER: ${postmortem.error}`);
    	if (postmortem.status && [404].indexOf(postmortem.status) < 0) {
    		console.log('...Ask for re-crawling when possibily recoverable failure/error returned from web server', url);
    		return true;
    	}
    	if (postmortem.error && ['EAI_AGAIN', 'ETIMEDOUT', 'ECONNRESET', 'ENOTFOUND'].indexOf(postmortem.error.code) >= 0) {
    		console.log('...Ask for re-crawling in case of: 1. name resolving error, 2. timeout, 3. connection reset');
    		return true;
    	}
    	return false;
  	},
	onAllFinished: function() {
		console.log('All attraction details have been crawled');
		asyncStreamer.stop();
		console.log('All stations were completed and streamed');
  	}
});

co(function*() {
	let db = yield mongoClient.connect(crawlerDatabase);
	let linksColl = db.collection(stationLinkCollName);
	let records = yield linksColl.find().toArray();
	console.log('%d stations to crawl', records.length);
	crawler.crawl();
	for (let record of records) {
		// console.log(`Crawling ${record.enName}(${record.jpName}) - ${record.jpUrl}...`);
		crawler.enqueueRequest({
			url: record.jpUrl
		});
	}
})
.catch(err => { console.error(err.stack); });