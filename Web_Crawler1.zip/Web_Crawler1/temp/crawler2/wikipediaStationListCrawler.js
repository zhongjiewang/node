﻿#!/usr/bin/env node
'use strict';

const userAgent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36';

const crawlerDatabase = 'mongodb://localhost:27017/crawler',
	stationNameCollName = 'wikiStationList';
	
const Crawler = require('js-crawler'),
	mongoClient = require('mongodb').MongoClient,
	co = require('co'),
	url = require('url'),
	_ = require('underscore'),
	log4js = require('log4js'),
	AsyncStreamer = require('async-streamer');

log4js.configure({
  appenders: [
    { type: 'console' },
    { type: 'file', filename: '/var/log/tourank/crawler.log' }
  ]
});

log4js.replaceConsole();

var asyncStreamer = new AsyncStreamer({
	url: crawlerDatabase,
	collection: stationNameCollName
})
.start();

function parseStationNamesAndStream(content, link) {
	const specialCharMap = {
		'Ā': 'A',
		'ā': 'a',
		'Ē': 'E',
		'ē': 'e',
		'Ī': 'I',
		'ī': 'i',
		'Ō': 'O',
		'ō': 'o',
		'Ū': 'U',
		'ū': 'u'
	};
	let narrowed = content.substring(content.indexOf('<h2><span class="mw-headline" id="Station_List">'), content.indexOf('<noscript><img'));
	let trElementRegEx = /<tr>([^]+?)<\/tr>/g;
	let matches = null;
	let count = 0;
	let enName = null;
	while (matches = trElementRegEx.exec(narrowed)) {
		let tdElementRegEx = /<td>(.+?)<\/td>/g;
		let enTdContent = tdElementRegEx.exec(matches[1])[1];
		// console.log('enTdContent @ %s: "%s" ', link, enTdContent);
		let jpTdContent = tdElementRegEx.exec(matches[1])[1];
		let enName = enTdContent;
		let smatches = /<a [^>]+?>(.+?)<\/a>/mg.exec(enTdContent);
		if (smatches) enName = smatches[1];
		// console.log(`${enName}: ${jpTdContent}`);
		let aHrefRegEx = /<a href="(.+?)"[^>]+?>(.+?)<\/a>/mg;
		while (smatches = aHrefRegEx.exec(jpTdContent)) {
			count++;
			let jpUrl = smatches[1];
			let jpName = smatches[2];
			let jpkName = null;
			let jpkNameRegEx = /（(.+?)）<\/td>/mg;
			jpkNameRegEx.lastIndex = smatches.lastIndex;
			smatches = jpkNameRegEx.exec(jpTdContent);
			if (smatches) jpkName = smatches[1];
			let record = {
				source: "wikipedia.org",
				href: link,
				enName: enName,
				jpName: jpName,
				jpkName: jpkName,
				jpUrl: url.resolve(link, jpUrl),
				crawledAt: new Date()
			}
			asyncStreamer.commit(record);
		}
	}
	console.log('%d stations found & streamed - %s', count, link);
}

var crawler = new Crawler()
.configure({
	ignoreRelative: false, 
	depth: 1,
	userAgent: userAgent,
	maxConcurrentRequests: 10,
	oblivious: true,
	enableTimeOut: true,
	shouldCrawl: function(url) {
		return true;
	},
	onSuccess: function(page) {
		parseStationNamesAndStream(page.body, page.actualUrl);
	},
	onFailure: function(postmortem) {
    	console.log('Failed to crawl %s', postmortem.url);
    	console.log('...Ask for re-crawling when any expected error happens');
    	return true;
  	},
	onAllFinished: function() {
		console.log('All japanese station crawled & streamed!!!');
		asyncStreamer.stop();
 	}
})
.crawl();
for (let postfix of ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K-L', 'M', 'N', 'O-P', 'R', 'S', 'T', 'U', 'W', 'Y', 'Z']) {
	crawler.enqueueRequest({
		url: 'https://en.wikipedia.org/wiki/List_of_railway_stations_in_Japan:_' + postfix
	});
}