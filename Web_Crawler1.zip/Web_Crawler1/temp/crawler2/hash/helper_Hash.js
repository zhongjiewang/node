
'use strict'

var crypto = require('crypto');



class Helper_Hash
 {
     //  /**
     //   * 生成随机的hash字符串
     //   * @param int $length
     //   */
     // static setVerifyKey($length = 16)
     // {
     //     // first three characters is capitalize
     //     $key =  chr(mt_rand(65,90)).chr(mt_rand(65,90)).chr(mt_rand(65,90)); 

     //     // rest are either 0-9 or a-z
     //     for($k = 0; $k < $length - 3; $k++)
     //     {
     //        $probab = mt_rand(1,16); 

     //        if($probab <= 11)
     //        {
     //            // a-z probability is 80%
     //            $key .= chr(mt_rand(97,122));
     //        }
     //        else
     //        {
     //            // 0-9 probability is 20%
     //            $key .= chr(mt_rand(48, 57));
     //        }
     //     }
     //     return $key;
     // }

     // /**
     //  * 根据数字生成一个3层深度的目录路径
     //  * @param int $keyid
     //  */
     // static hashDIR($keyid)
     // {
     //    $keyid = abs(intval($keyid));
     //    $keyid = sprintf("%09d", $keyid);
     //    $dir1 = substr($keyid, 0, 3);
     //    $dir2 = substr($keyid, 3, 2);
     //    $dir3 = substr($keyid, 5, 2);
     //    console.log($dir1 + '/' + $dir2 + '/' + $dir3 +'/');
     //    // return $dir1.'/'.$dir2.'/'.$dir3.'/';
     // }

     static   hello () {
        console.log('HELLO');
        let  shasum = crypto.createHash('sha1');
        shasum.update('4');

    // return shasum.digest('hex')
        console.log(shasum.digest('hex'))
     }
 }

module.exports = Helper_Hash;


//这个是暴露出一个类或者对象
//module.exports = Wechat


// Helper_Hash.hello();
//这个是暴露出一个方法
// exports.parsexmlAsync = function (xmlString){
//     var result ;
//     xml2js.parseString(xmlString,{trim:true},function(err,content){
//         // console.log(content);
//         result = content;
//     })
//     return result;
// }
