#!/usr/bin/env node
'use strict';

var resouce = require('./resource')
// console.log(resouce.html)

// var startPage = 'http://www.emingren.com';
const startPage = 'https://gurunavi.com/en/rs/srh/';
 var    restaurantListPageRegEx = /^https:\/\/gurunavi\.com\/en(.*?)\/rs\/srh\/(.*?)$/ig;



const restaurantListBeginsMarker = '<div class="main -right">',
    restaurantListEndsMarker = '<ul class="horizontal-item horizontal-list -with-button-small">',
    restaurantBeginsMarker = '<section>',
    restaurantEndsMarker = '</section>';


var Crawler = require('js-crawler')
var onceForAll = false;
var crawler = null;
crawler = new Crawler()
.configure({
    ignoreRelative: false, 
    depth: 1,
    userAgent:'crawler@tourank',
    maxConcurrentRequests: 10,
    oblivious: true,
    shouldCrawl: function(url) {
        // console.log(url+'显示')
        return true;
    },
    onSuccess: function(page) {
        console.log(page.actualUrl)
        console.log('队列请求'+page.actualUrl)
        // console.log(page.body)
        if (page.actualUrl == startPage && !onceForAll) {
            parseAndRequestRestaurantLists(this, page.body);
        // parseAndRequestRestaurantLists(this, resouce.html);

            onceForAll = true;
        }

        if (page.actualUrl.match(restaurantListPageRegEx)) {
            parseAndStreamRestaurantLinks(page.body, page.actualUrl);
        }
    },
    onFailure: function(postmortem) {
        console.log('Failed to crawl %s (%s)', postmortem.url, postmortem.status? 'HTTP: ' + postmortem.status : 'OTHER: ' + postmortem.error);
       
        return false;
    },
    onAllFinished: function() {
        console.log('All crawling are finished');


    }
})
.crawl(startPage);

/*
[ '<a href="https://gurunavi.com/en/rs/srh/?p=8403">Last</a>',
  'https://gurunavi.com/en/rs/srh/',
  '',
  '8403',
  index: 56817,
  input: '<!DOCTYPE html>
*/
/*
　　?等价于匹配长度{0,1}
　　*等价于匹配长度{0,}
　　+等价于匹配长度{1,}
　　\d等价于[0-9]
\D等价于[^0-9]
　　\w等价于[A-Za-z_0-9]
\W等价于[^A-Za-z_0-9]。
*/

/*
表5.懒惰限定符
代码/语法   说明
*?  重复任意次，但尽可能少重复
+?  重复1次或更多次，但尽可能少重复
??  重复0次或1次，但尽可能少重复
{n,m}?  重复n到m次，但尽可能少重复
{n,}?   重复n次以上，但尽可能少重复
*/
/*
我们已经提到了怎么重复单个字符（直接在字符后面加上限定符就行了）；但如果想要重复多个字符又该怎么办？你可以用小括号来指定子表达式(也叫做分组)，然后你就可以指定这个子表达式的重复次数了，你也可以对子表达式进行其它一些操作(后面会有介绍)。
(\d{1,3}\.){3}\d{1,3}是一个简单的IP地址匹配表达式。要理解这个表达式，请按下列顺序分析它：\d{1,3}匹配1到3位的数字，(\d{1,3}\.){3}匹配三位数字加上一个英文句号(这个整体也就是这个分组)重复3次，最后再加上一个一到三位的数字(\d{1,3})。
*/
/*
小括号的值他会放在数组中,0下标是返回整个的匹配的项目
*/
function parseAndRequestRestaurantLists(crawler, content) {
    // let matches = /<a href="(https:\/\/gurunavi\.com\/en(.*?)\/rs\/srh\/)\?p=([0-9]+?)">Last<\/a>/img.exec(content);
    let matches = /<a href="(https:\/\/gurunavi\.com\/en(.*?)\/rs\/srh\/)\?p=([0-9]+?)">Last<\/a>/img.exec(content);
    
    // console.log(matches)
    // console.log(matches[0])
    console.log(matches[3])//直接拿到最后的页码
    console.log(matches.length + '这是长度')
    matches.forEach(function(elm,index,arr){
        //arr 可选。当期元素属于的数组对象
        console.log(elm + '编号'+ index)
        // conole.log(arr)
    })
    if (matches) {
        let lastPage = parseInt(matches[3]);
        for (let i = 2; i <= 1000; i++) {
            crawler.enqueueRequest({url: matches[1] + '?p=' + i}, 1);
            console.log('这是队列请求')
        }
        console.log('Found and requested page#2 to page#%d', lastPage);
    }


}

function parseAndStreamRestaurantLinks(content, url) {
    /*
    // console.log(content)
    var patt1 = /<a href="https:\/\/gurunavi\.com\/en\/g(\w{0,10})\/rst\/">/img.exec(content);


    console.log(patt1[0])
    console.log(patt1[1])
    console.log(patt1.length + '这是数组长度')
    console.log(patt1.index)
    console.log(content.slice(patt1.index, patt1.index + 250))
    */

    let narrowed = content.substring(content.indexOf(restaurantListBeginsMarker) + restaurantListBeginsMarker.length);
    narrowed = narrowed.substring(0, narrowed.indexOf(restaurantListEndsMarker));
    let idx = -1;
    let count = 0;
    let issuedCount = 0;

}





























































































