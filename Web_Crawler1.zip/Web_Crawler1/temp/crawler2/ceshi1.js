

'use strict'


var resource = require('./resource');
var _= require('underscore')
const restaurantListBeginsMarker = '<div class="main -right">',
    restaurantListEndsMarker = '<ul class="horizontal-item horizontal-list -with-button-small">',
    restaurantBeginsMarker = '<section>',
    restaurantEndsMarker = '</section>';

var  html = resource.html;

var index = html.indexOf(restaurantBeginsMarker);

console.log(index)

var idx = -1;

while (idx = html.indexOf(restaurantBeginsMarker) >= 0) {

    // console.log(html.indexOf(restaurantBeginsMarker))
    console.log(idx)
}

var arr = _.map([1, 2, 3], function(num){ return num * 3; });

console.log(arr)


















































