
'use strict'

var AsyncStreamer = require('async-streamer');


// const crawlerDatabase = 'mongodb://localhost:27017/crawler',
//     // restaurantLinkCollName = 'restaurantLinks',
//     restaurantCollectionName = 'restaurants';


// var asyncRecordStreamer = new AsyncStreamer({
//     url: crawlerDatabase,
//     collection: restaurantCollectionName
// });

// // asyncRecordStreamer.start();

// // for (let i = 0; i < 10; i++) {
// //     var restaurant = {
// //     name:'山西刀削',
// //     location:'beijing',
// //     number: i + '编号'
// //     }

// // asyncRecordStreamer.commit(restaurant);


// // }

// asyncRecordStreamer.stop();




var MongoClient = require('mongodb').MongoClient
  , assert = require('assert');
 
// Connection URL 
var url = 'mongodb://localhost:27017/myproject1';
// Use connect method to connect to the Server 
MongoClient.connect(url, function(err, db) {
  assert.equal(null, err);
  // console.log(db)
  console.log("Connected correctly to server");
 
  insertDocuments(db, function() {
    // updateDocument(db, function() {
    //   db.close();
    // });
  });
  findDocuments(db,function (){
    db.close()
  })

});


var insertDocuments = function(db, callback) {
  // Get the documents collection 
  var collection = db.collection('documents');
  // Insert some documents 
  collection.insertMany([
    {a : 1}, {a : 2}, {a : 3}
  ], function(err, result) {
    console.log('这里是写入数据中的')
    console.log(result)
    /*
    //打印出的result的格式
{ result: { ok: 1, n: 3 },
  ops: 
   [ { a: 1, _id: 57cf84a0491630256f520bb6 },
     { a: 2, _id: 57cf84a0491630256f520bb7 },
     { a: 3, _id: 57cf84a0491630256f520bb8 } ],
  insertedCount: 3,
  insertedIds: 

    */
    assert.equal(err, null);
    assert.equal(3, result.result.n);
    assert.equal(3, result.ops.length);
    console.log("Inserted 3 documents into the document collection");
    callback(result);
  });
}


var updateDocument = function(db, callback) {
  // Get the documents collection 
  var collection = db.collection('documents');
  // Update document where a is 2, set b equal to 1 
  collection.updateOne({ a : 2 }
    , { $set: { b : 1 } }, function(err, result) {
    assert.equal(err, null);
    assert.equal(1, result.result.n);//AssertionError: 0 == 1,这里是
    //断言的意思,就是先进行判断,符合我们的预期,才会往下边执行,如果不符合,就会报错,程序中断
    console.log("Updated the document with the field a equal to 2");
    callback(result);
    console.log('我是结果')
    console.log(result.result.n)
  });  
}

var findDocuments = function(db, callback) {
  // Get the documents collection 
  var collection = db.collection('documents');
  // Find some documents 
  collection.find({}).toArray(function(err, docs) {
    assert.equal(err, null);
    assert.equal(2, docs.length);//数据库的元素的个数
    console.log("Found the following records");
    console.dir(docs);
    callback(docs);
  });
}
/*
我是结果
{ result: { ok: 1, nModified: 0, n: 1 },
  connection: 
   EventEmitter {
     domain: null,
     _events: {},
     _eventsCount: 0,


    opts: 
      { promoteLongs: true,
        promoteValues: true,
        promoteBuffers: false },
     length: 71,
     requestId: 37,
     responseTo: 2,
     responseFlags: 8,
     cursorId: Long { _bsontype: 'Long', low_: 0, high_: 0 },
     startingFrom: 0,
     numberReturned: 1,
     documents: [ [Object] ],
     cursorNotFound: false,
     queryFailure: false,
     shardConfigStale: false,
     awaitCapable: true,
     promoteLongs: true,

*/


























































































