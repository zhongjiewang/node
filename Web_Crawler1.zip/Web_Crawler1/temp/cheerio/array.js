
var arr = [1,3,5,0,100,555]

arr.forEach(function (ar) {
    console.log(ar)

})

arr.map(function (ar){
    console.log(ar)
})