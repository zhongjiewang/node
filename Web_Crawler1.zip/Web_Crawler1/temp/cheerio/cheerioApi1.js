// cheerio 
//  英  [tʃɪərɪ'əʊ]   美  [,tʃɪrɪ'o] 读音:chairuio
// int. 好呀；加油；恭喜恭喜

/*
let cheerio = require('cheerio')
let $ = cheerio.load('<h2 class="title">Hello world</h2>')

$('h2.title').text('Hello there!')
$('h2').addClass('welcome')

$.html()
//=> <h2 class="title welcome">Hello there!</h2>
console.log($.html())
*/

/*
<ul id="fruits">
  <li class="apple">Apple</li>
  <li class="orange">Orange</li>
  <li class="pear">Pear</li>
</ul>
*/

var htmlstr = '<ul id="fruits"> <li class="apple">Apple</li> <li class="orange">Orange</li> <li class="pear">Pear</li> </ul>'

var cheerio = require('cheerio')

$ = cheerio.load(htmlstr)

var str1 = $('#fruits .apple').text()

console.log(str1)

// console.log($('ul').attr('id'))

 var str2 = $('.apple').attr('id', 'favorite').html()

 console.log(str2)

var fruits = []

$('li').each(function(i,elem) {
    fruits[i] = $(this).text()
})

console.log(fruits)

console.log($('ul').html())

var str3 = $('li')//得到的是 对象{ 0: ... ,1:....,2:....}键值是0 1 2 3

console.log(str3.length)
































































