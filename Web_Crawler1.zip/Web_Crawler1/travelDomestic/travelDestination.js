/*
func {
var options = {
    det:3
}

var det = (5 && false) //如果前边的的值为false,就会直接返回fasle,因为它是与运算符,只要检测到第一个
为false就直接返回,不再判断下个,如果第一个为true,非空,就会判断第二个,同样如果第二个值为false,也会返回
false,记住与运算符,如果第二个也为真,就直接返回第二个的值

console.log(det)
 
new Crawler().configure({depth: 1})//depth是深度的意思,爬取页面的层级,
1 就是只是当前的网页 depth=2就是爬取当前网页中的链接, 3就是进入二级页面之后,在爬取一次链接
  .crawl("http://www.emingren.com", function onSuccess(page) {
    console.log(page.url);
});
}
*/

var Crawler = require("js-crawler");

var crawler = new Crawler().configure({
    ignoreRelative: false, 
    depth: 2,
    maxRequestsPerSecond: 10,//每秒最大的请求数量
    maxConcurrentRequests: 5

    /*
    shouldCrawl: function(url) {
        console.log(url)
        console.log(url.indexOf('recruit'))//返回这个字符串在整个字符串中开始位置的索引
        return url.indexOf("recruit") < 0; //如果没有直接返回-1,这样的话就得到的是true,意思是需要爬取的
                                        //如果是false,则是不需要爬取的网页
        }
    */    
    })

crawler.crawl({
  url: "http://4travel.jp/search/shisetsu/dm?breadcrumb_id=37&category_group=kankospot&sa=%E5%9B%BD%E5%86%85",
  success: function(page) {
    console.log('成功爬取')
    console.log(page.url);
  },
  failure: function(page) {
    console.log('失败爬取')

    console.log(page.status);
  },
  finished: function(crawledUrls) {
    console.log('爬取结束')

    console.log(crawledUrls);//会把爬取成功的都放在一个数组中
    console.log(crawledUrls.length);
    console.log(crawledUrls instanceof Array)
  }
});
























































































































