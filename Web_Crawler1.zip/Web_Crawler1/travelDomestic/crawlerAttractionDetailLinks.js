#!/usr/bin/env node 

'use strict';
/*
Readme: when the code run in the server, please open 109 line and 117 line;

*/

const userAgent = 'crawler@tourank';
const startPage = 'http://4travel.jp/search/shisetsu/dm?category_group=kankospot&page=1&sa=%E5%9B%BD%E5%86%85'
var requestSuccessCount = 0;
var attractionsNumber = 0;

var Crawler = require('js-crawler'),
    keypress = require('keypress');
var crawler = new Crawler();
var onceForAll = false;


keypress(process.stdin);
process.stdin.on('keypress', function (ch, key) {
    if (key && key.name === 'space') {
        if (crawler) {
            // crawler.dump();
            console.log(`AttractionsNumber: ${attractionsNumber}`);
            console.log(`RequestSuccessCount: ${requestSuccessCount}\n`);
        };
    };

    if (key && key.ctrl && key.name == 'c') {
        process.exit(1);
    }
});
process.stdin.setRawMode(true);
process.stdin.resume();


var AsyncStreamer = require('async-streamer');
// const crawlerDatabase = 'mongodb://localhost:27017/attractionCrawler',
//      collectionNameOfTravelDetailLinks = 'attractionDetailLinks';
const crawlerDatabase = 'mongodb://localhost:27017/tripadvisor',
     collectionNameOfTravelDetailLinks = 'tripadvisorDetailLinks';
//tripadvisor
var asyncRecordStreamer = new AsyncStreamer({
    url: crawlerDatabase,
    collection: collectionNameOfTravelDetailLinks
});

asyncRecordStreamer.start();

crawler.configure({
    ignoreRelative: false, 
    depth: 1,
    userAgent: userAgent,
    maxConcurrentRequests: 10,
    oblivious: true,
    enableTimeOut:true,//if timeOut ,will exec the onFailure
    shouldCrawl: function(url) {
        return true;
    },
    onSuccess: function(page) {
        // console.log('Received message from: %s', page.actualUrl);
        requestSuccessCount ++;
        if (page.actualUrl == startPage && !onceForAll) {
            attractionsNumber = parseAttractionPageHtmlAndRequestAttractionPagesFromPageSecond(this, page.body);
            onceForAll = true;
        };
        parseAttractionPageHtmlAndStreamAttractionDetailLinks(page.body, page.actualUrl);
       
    },
    onFailure: function(postmortem) {
        console.warn('Failed to crawl %s (%s)', postmortem.url, postmortem.status? 'HTTP: ' + postmortem.status : 'OTHER: ' + postmortem.error);
        if (postmortem.status && [404].indexOf(postmortem.status) < 0) {
            console.error('...Ask for re-crawling when possibily recoverable failure/error returned from web server');
            return true;
        }
        if (postmortem.error && ['EAI_AGAIN', 'ETIMEDOUT', 'ECONNRESET'].indexOf(postmortem.error.code) >= 0) {
            console.error('...Ask for re-crawling in case of: 1. name resolving error, 2. timeout, 3. connection reset');
            return true;
        }
       // if return false,no crawler, if return true,mean will request again,
        return false;
    },
    onAllFinished: function() {
        console.log('All crawling are finished');
        asyncRecordStreamer.stop();
        console.log(`RequestSuccessCount: ${requestSuccessCount}\n`);
        setTimeout(function(){ process.exit(1);} , 10000);     
    }
})
.crawl(startPage);

function  parseAttractionPageHtmlAndRequestAttractionPagesFromPageSecond(crawler, content) {

        let regExpForAllAttractionNumbers = new RegExp('全<span class="num">(.{0,10})</span>件中','ig')
        let allAttractionNumbers = regExpForAllAttractionNumbers.exec(content);

        let numbersTemp = parseInt(allAttractionNumbers[1].replace(/,/ig,''));
        
        let allAttractionPagesNumber = getPagesNumber(numbersTemp,10);
        console.log(`Attractions Number: ${numbersTemp}`);
        console.log('The Sum Of the page number' + allAttractionPagesNumber);
        let pageRegExp = /page=1/ig;

        for (let  i = 2; i <= allAttractionPagesNumber; i++) {
             crawler.enqueueRequest({url: startPage.replace(pageRegExp,`page=${i}`)}, 1);
         };

    return numbersTemp;   
}

function getPagesNumber (sum, numberOfOnePage) {
    let pagesNumber;
    if ((sum%numberOfOnePage) != 0)  {
        pagesNumber = parseInt(sum/numberOfOnePage) + 1;
    }else {
        pagesNumber = parseInt(sum/numberOfOnePage); 
    }
    return pagesNumber;
}


var  domesticUrlRegExp = /<a href="http:\/\/4travel\.jp\/domestic\/area\/.*?" class=(("ico_kankospot")|("ico_transport")|("ico_restaurant"))>\n(.*?)\n<em><\/em>\n<\/a>/ig;
var  spotUrlRegExp = /<a href="(http:\/\/spot4travel\.jp\/landmark\/dm\/)([0-9]*?)" class="ico_kankospot" target="_blank">\n(.*?)\n<em><\/em>\n<\/a>/ig;

function parseAttractionPageHtmlAndStreamAttractionDetailLinks (content,pageUrl) {
    
    let tempstart = pageUrl.indexOf('page=');
    let tempEnd = pageUrl.indexOf('&sa');
    let page_number = pageUrl.slice(tempstart + 5,tempEnd);
    
    let domesticUrl;
    while((domesticUrl = domesticUrlRegExp.exec(content))!= null){
        let objAttraction1 = sliceDomesticUrl(domesticUrl,page_number);
        // console.log(objAttraction1);

        asyncRecordStreamer.commit(objAttraction1);
    };

    let spotUrl;
    while((spotUrl = spotUrlRegExp.exec(content)) != null) {
        let objAttraction2 = sliceSpotUrl(spotUrl,page_number);
        // console.info(objAttraction2);

        asyncRecordStreamer.commit(objAttraction2);
    }; 

}

// parse spot4travel.jp Url and save;
function sliceSpotUrl(spotUrl,page_number){

    let obj;

    let url = spotUrl[1].concat(spotUrl[2]);
    let id = spotUrl[2];
    let name = spotUrl[3];

    let refUrl = `http://4travel.jp/search/shisetsu/dm?category_group=kankospot&page=${page_number}&sa=%E5%9B%BD%E5%86%85`;

    obj = {
        crawler:'TravelDetailLinks',
        website:'4travel.jp',
        country:'jp',
        language:'en',
        id:id,
        href:url,
        attractionName:name,
        refUrl:refUrl,
        crawledAt: new Date() 
    }

    return obj;
}

// parse 4travel.jp/domestic url and save 
function sliceDomesticUrl (domesticUrl,page_number) {

    let obj;

    let start = domesticUrl[0].indexOf('href="')
    let end  = domesticUrl[0].indexOf('class=')
    let url  = domesticUrl[0].slice(start + 6,end-2)
    
    let tempId = /\/([0-9]+?)\//.exec(url);
    let id = tempId[1];
    let name = domesticUrl[5];

    let  refUrl = `http://4travel.jp/search/shisetsu/dm?category_group=kankospot&page=${page_number}&sa=%E5%9B%BD%E5%86%85`;

    obj = {
        crawler:'TravelDetailLinks',
        website:'4travel.jp',
        country:'jp',
        language:'en',
        id:id,
        href:url,
        attractionName:name,
        refUrl:refUrl,
        crawledAt: new Date()
    }

    return obj;
}
