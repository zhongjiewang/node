#!/usr/bin/env node
'use strict';

const userAgent = 'crawler@tourank';

var Crawler = require('js-crawler');
var crawler = new Crawler();

var Buffer = require('buffer').Buffer,
   assert = require('assert');



const crawlerDatabase = 'mongodb://localhost:27017/travelCrawler',
    attractionsCollection  = 'travelDetailLinks';

var Crawler = require('js-crawler'),
    mongoClient = require('mongodb').MongoClient,
    co = require('co');
  

/******* 改变控制台输出颜色,便于观察 ******/
var log4js = require('log4js');
log4js.configure({
  appenders: [
    { type: 'console' }
 ],
   replaceConsole: true
});


/************向数据库中查询attractionsDetailLinks****************/
co(function *() {
    let db = yield mongoClient.connect(crawlerDatabase);
    let linkColl = db.collection(attractionsCollection);
    let records = yield linkColl.find({
        website: '4travel.jp',
        language: 'en'
    }).toArray();
    yield db.close();

    console.info(`${records.length} attractions will be crawled`);
    crawler.crawl(); 

    let arr = records.slice(82400); //25100有错误
    // console.log(arr);

    // //  var DD =  ['http://4travel.jp/domestic/area/okinawa/okinawa/hontohokubu/motobu/zoo/10000190/',
    // //             'http://4travel.jp/domestic/area/kanto/chiba/maihamaurayasu/tokyodisneyresort/themepark/11187263/',
    // //             'http://4travel.jp/domestic/area/kanto/chiba/maihamaurayasu/tokyodisneyresort/themepark/11187264/',
    // //             'http://4travel.jp/domestic/area/hokkaido/hokkaido/asahikawa/asahikawa/zoo/10000013/',
    // //             'http://4travel.jp/domestic/area/chugoku/hiroshima/miyajima/miyajima/temple/10002779/',
    // //             'http://4travel.jp/domestic/area/kanto/tokyo/tokyo/marunouchi/hotplace/10006108/'
    // //             ];
    // // var ddA = DD.slice(5)

    //     var spotDD = ['http://spot4travel.jp/landmark/dm/10667842',
    //                   'http://spot4travel.jp/landmark/dm/11187501',
    //                   'http://spot4travel.jp/landmark/dm/10666533',
    //             // 'http://4travel.jp/domestic/area/hokkaido/hokkaido/asahikawa/asahikawa/zoo/10000013/',
    //             'http://4travel.jp/domestic/area/kinki/kyoto/kyoto/kyotoshimogamo/temple/10002151/',
    //              'http://4travel.jp/domestic/area/okinawa/okinawa/hontohokubu/motobu/zoo/10000190/',
    //              'http://4travel.jp/domestic/area/chugoku/hiroshima/miyajima/miyajima/temple/10002779/',
                      
    //                   'http://spot4travel.jp/landmark/dm/10010449',
    //                   'http://spot4travel.jp/landmark/dm/11289841',
    //                   'http://spot4travel.jp/landmark/dm/10001020'
    //                   ];
    //     var ddS = spotDD.slice(3,4);
    for (let record of arr) {
        crawler.enqueueRequest({
            url: record.href,
            timeout: 30000, // this option is very important 'coz sometimes this website will pend responding (forever!) and then the accumulated pending requests will exceed the concurrent threshold thus prevent the web crawler (forever!) from issuing other requests
            id: record.id
        });
    }
})
.catch(err => { console.error(err.stack); });

var AsyncStreamer = require('async-streamer');
var asyncRecordStreamer = new AsyncStreamer({
    url: 'mongodb://localhost:27017/attractionsInfoCrawler',
    collection: 'attractionsInfo'
});

// asyncRecordStreamer.start();

/*********爬取页面********/

crawler.configure({
    ignoreRelative: false, 
    depth: 1,
    userAgent: userAgent,
    maxConcurrentRequests: 10,
    oblivious: true,
    enableTimeOut:true,
    shouldCrawl: function(url) {
        // console.warn(url)
        return true;
    },
    onSuccess: function(page) {

        // console.log(page.actualUrl)
        let infoObjCommit = {};

        if (page.actualUrl.match(/domestic/ig)) {
            // console.log('nishi')
            infoObjCommit = parseAndStreamAttractionsImportantInfoOf4travelURL(page.body, page.actualUrl, page.options.id);
        }else {
            infoObjCommit = parseAndStreamAttractionsImportantInfoOfSpot4travelURL(page.body, page.actualUrl, page.options.id);
        }
       
        console.log(infoObjCommit);

        // asyncRecordStreamer.commit(infoObjCommit);

    },
    onFailure: function(postmortem) {
        console.error('Failed to crawl %s (%s)', postmortem.url, postmortem.status? 'HTTP: ' + postmortem.status : 'OTHER: ' + postmortem.error);
        if (postmortem.status && [404].indexOf(postmortem.status) < 0) {
            console.error('...Ask for re-crawling when possibily recoverable failure/error returned from web server');
            return true;
        }
        if (postmortem.error && ['EAI_AGAIN', 'ETIMEDOUT', 'ECONNRESET'].indexOf(postmortem.error.code) >= 0) {
            console.error('...Ask for re-crawling in case of: 1. name resolving error, 2. timeout, 3. connection reset');
            return true;
        }
        //onFailure:这里就是对超时的响应对报错处理,不再让他等待,要不然一直挂起
        //返回true就是重新爬取,
        return false;
    },
    onAllFinished: function() {
        // asyncRecordStreamer.stop();
        console.log('All crawling are finished');
        // console.log('请求并解析成功的页面的数量'+ pageNumbersArr.length + '数组'+ pageNumbersArr)
    }
});



function parseAndStreamAttractionsImportantInfoOf4travelURL (content, url, id) {
    // console.log(id)
    
    let importantInfoStart = '<div class="spot_amenity_info" id="spot_amenity_info">';
    //<!-- / .spot_amenity_info --></div>
    // let importantInfoEndD = '<div class="popular_peripheral_spot group">';
    let importantInfoEnd = '<!--.+?spot_amenity_info --><.div>';
    let importantInfoRegExp = eval('/'+importantInfoStart+'[^]*?'+importantInfoEnd+'/ig');

    let importantInfo = importantInfoRegExp.exec(content);

    // imagePath-/galleries/tripadvisor.com/attractions/1999086/o-0a_97_f7_72_caption.jpg-with-2000--height-1500-size-383393
    //    let tripId = 10000008;
    // let Regexp2 = new RegExp("\/attractions\/" + tripId + ".+?with-(.+?)--height-(.+?)-size-(.+?)" ,"img");
    // console.log(Regexp2);
    // let matches2 = null;
    // let arr2 = [];
    // while ((matches2 = Regexp2.exec(str1)) != null ) {
    //     // console.log(matches2[1]);
    //     console.log('matches2[0]---',matches2[0]);
    //     console.log('width-',matches2[1],'height-',matches2[2],'size-',matches2[3]);
    // }

    // console.log(importantInfo[0])
    // console.log('dddddddd')
    // console.log(importantInfo.length)

    let infoGroup = /<dl class="group">[^]*?<\/dl>/ig;
    
    let result;
    let infoObj = {};
     infoObj.country = 'jp';
     infoObj.language = 'en';
     infoObj.id = id;
     infoObj.refUrl = url;
     infoObj.crawler = 'attractionsOfImportantInformationCrawler';

     // console.log(importantInfo[0])
    assert.notEqual(null, importantInfo,`${url}`);
    // if(importantInfo[0])

    //粗处理
   while((result = infoGroup.exec(importantInfo[0])) != null){
            
        let infoKeyRegExp = /<dt>([^]*?)<\/dt>/ig;
        let infoValueRegExp = /<dd.*?>([^]*?)<\/dd>/ig; 
        let tempKey =  infoKeyRegExp.exec(result[0]);
        let tempValue = infoValueRegExp.exec(result[0])
        // console.log(tempValue[1])
        let key = getKey(tempKey[1].replace('：',''));
        // console.log(key) 
        if(key !== 'category') {
            infoObj[key] = tempValue[1];
        }else {
           infoObj[key] = result[0].match(/<dd.*?>([^]*?)<\/dd>/ig);
        }
        
    }

    //细处理
    if (infoObj.address) {
        let index = infoObj.address.indexOf('&nbsp');
        infoObj.address = infoObj.address.slice(0,index);
    }

    if (infoObj.url) {
        // console.log(infoObj.url)
        infoObj.url = (/data-href="([^]*?)">/ig.exec(infoObj.url))[1];
        
    }

    if (infoObj.budget) {
        infoObj.budget = infoObj.budget.split(/<br \/>[^]*?\n/ig);
    }

    if (infoObj.other) {
        infoObj.other = infoObj.other.split('<br />\n');
        if(infoObj.other[0] == '') {
            infoObj.other.shift();
        }
    }

    if (infoObj.businessHour) {
        infoObj.businessHour = infoObj.businessHour.split(/<br \/>[^]*?\n/ig);
        infoObj.businessHour = infoObj.businessHour.filter(function(currentValue) {
            if (currentValue !== ''){
                return true;
            }
        });
    }

    if (infoObj.visit) {
        infoObj.visit = infoObj.visit.split('<br />\n');
    }

    if (infoObj.category) {

        let infoCategoryTemp = {};
       for (let  i = 0; i < infoObj.category.length; i++) { 

            let result;             
            let infoCategoryKey = /class="(.*?)">/ig.exec((infoObj.category)[i]);

            // console.log(infoCategoryKey[1])
            let kkkk = infoCategoryKey[1];
            let infoCategoryValueReg = /<a href=".*?">(.*?)<\/a>/ig;
            let valueArr = [];
            while ((result = infoCategoryValueReg.exec((infoObj.category)[i])) != null) {
                // console.log(result)
                valueArr.push(result[1]);
            }
            infoCategoryTemp[kkkk] = valueArr;
 
        }

        infoObj.category = infoCategoryTemp;
    }

    if (infoObj.relatedLink) {
        infoObj.relatedLink = /href="(.*?)" target="_blank">/ig.exec(infoObj.relatedLink)[1];
    }

    infoObj.createDate = new Date();

    // console.log(infoObj)

    return infoObj;
}


function parseAndStreamAttractionsImportantInfoOfSpot4travelURL (content, url, id) {

    // console.log(url)

    let importantInfo = /<div class="u\_outLineModule">[^]*?<div class="u\_mainPictBox">/ig.exec(content);

    // console.log(importantInfo[0])

    let summaryInfo = /<p class="leadExplainText">([^]*?)<\/p>/ig.exec(importantInfo[0]);
    // console.log(summaryInfo[1])


    let infoObj = {};
     infoObj.country = 'jp';
     infoObj.language = 'en';
     infoObj.id = id;
     infoObj.refUrl = url;
     infoObj.crawler = 'attractionsOfImportantInformationCrawler';


    infoObj.summaryInfo = summaryInfo[1];
    let result;
    let group = /<tr>[^]*?<\/tr>/ig;
    while ((result = group.exec(importantInfo[0])) != null) {

        // console.log(result)
        let infoKeyRegExp = /<th>([^]*?)<\/th>/ig;
        let infoValueRegExp = /<td.*?>([^]*?)<\/td>/ig; 
        let tempKey =  infoKeyRegExp.exec(result[0]);
        let tempValue = infoValueRegExp.exec(result[0])

        // console.log(tempKey[1])
        // console.log(tempValue[1])
        let key = getKey(tempKey[1].replace('：',''));
        // console.log(key) 
        infoObj[key] = tempValue[1];

    }

    if (infoObj.address) {
        let index  = infoObj.address.indexOf('\n');
        infoObj.address = infoObj.address.slice(0,index);
    }

    if (infoObj.url) {
        infoObj.url = /href="(.+?)"/ig.exec(infoObj.url)[1];

    }

    if (infoObj.visit) {
        infoObj.visit = infoObj.visit.split('<br />')

    }

    if (infoObj.businessHour) {
        infoObj.businessHour = infoObj.businessHour.replace('<br />','')

    }

    if (infoObj.budget) {
        infoObj.budget = infoObj.budget.replace('<br />',': ')
        infoObj.budget = infoObj.budget.split('<br /><br />')

    }

    infoObj.createDate = new Date();
    // console.log(infoObj)
    return infoObj;
}



var keyValueObj = {
               name:'施設名',
         postalcode:'郵便番号',
            address:'住所',
          telephone:'電話番号',
               url :'URL',
              visit:'アクセス',
       businessHour:['営業期間' , '営業時間'],
            restDay:'休業日',
             budget:['予算' , '料金'],
              other:'その他',
         parkingLot:'駐車場',
           category:'カテゴリー',
        relatedLink:'関連情報'
        };

function getKey (infokey){
   
    for (let key in keyValueObj){

        if(keyValueObj[key] instanceof Array) {

            for (let  i = 0; i < keyValueObj[key].length; i++) {

                 if (infokey == keyValueObj[key][i]) {
                    return key;
                 }     
            }
        }

       if (infokey == keyValueObj[key]) {
           return key;
       }  
    }
}











































































































































































































































































