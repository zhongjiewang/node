

var http = require('http'); 
// var Promise = require('bluebird'); // 第三方 Promises 模块 
var cheerio = require('cheerio'); // 爬虫分析模块 
// var BufferHelper = require('bufferhelper'); // buffer 组装模块 
// var iconv = require('iconv-lite'); // 字符转码模块 
const baseUrl = 'http://4travel.jp/search/shisetsu/dm?breadcrumb_id=37&category_group=kankospot&page='; 

const homeUrl = '&sa=%E5%9B%BD%E5%86%85' 

var pagesArr = []; //爬取到的HTML页面集合 

grabPages(1);

function grabPages(pageNumber) { 

    // return new Promise(function (resolve, reject) { 
        var url = baseUrl.concat(pageNumber ,homeUrl)

        console.log('正在爬取 ' + url); 

        http.get(url, function (res) { 

            // var bufferHelper = new BufferHelper();
            let html = '';
            res.on('data', function (data) { 
                html +=data  
            }); 

            res.on('end', function () { 
                console.log('爬取 ' + url + ' 成功'); 

                filterChapterB(html)
                // filterPages(html)
                // resolve(html)
                pageNumber = pageNumber + 1

                if (pageNumber < 264) {

                    return grabPages(pageNumber)
                }else {
                    console.log('页面爬取结束')
                    return ''
                }
                
            }); 

        }).on('error', function (e) { // 爬取成功 
                // reject(e); 
                console.log('爬取  失败'); 
        });

    
    // }); 

}

//用模块进行解析
function filterPages(html) { 
        var  $ = cheerio.load(html); 
        
        var  title = $('.summary_list_box li .summary_ttl .ico_kankospot').text()
        
        console.log(title)
        // return courseData; 
} 

//用正则来筛选
function filterChapterB (html) {

    var patt1 = new RegExp('ico_kankospot".{0,20}>\n.{2,15}\n<em',"img");

    var result ;
   
    var arrResult = []

    while((result = patt1.exec(html)) !=null) {

        let start = result[0].indexOf('\n')
        let travelName = result[0].slice(start+1,-4)
        arrResult.push(travelName)
    }
    console.log(arrResult.length)
    console.log(arrResult)
}
// 


 // 

/*
Promise .all(pagesArr) 
    .then(function (pages) { 

        var coursesData = []; 

        pages.forEach(function (html) { // 提取课程信息 
            var courses = filterChapters(html);

            coursesData.push(courses); 
            }); // 打印课程信息 
            
            printCourseInfo(coursesData); 
 }); // 提取课程信息 





 function printCourseInfo(coursesData) { 

        if(Object.prototype.toString.call(coursesData) == '[object Array]' && coursesData.length > 0){ 
                
                coursesData.forEach(function (courseData) { 

                    console.log('\n\n【' + courseData.number + '】人学过《' + courseData.title + '》'); 
                    console.log('----------------------------------------------'); 
                    
                    courseData.videos.forEach(function (item) { 

                        console.log('\n' + item.chapterTitle); 

                        item.videos.forEach(function (video) { 
                            console.log(' ' + video.title.trim()); 
                        })

                    }); 
                }); 

        }else{ 

            console.log('暂无课程信息'); 
        } 
 }


*/




































































































































