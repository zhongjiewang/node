
var http = require('http');
var domain = require('domain');

http.createServer(function(req,res){

    var d = domain.create();
    d.on('error',function(err){
        console.log(err.stack);
        res.writeHead(500, {'Content-Type':'text/plain'});
        res.end('Server error\n');
    });

    d.run(function(){
        resAction(req,res);
    })


}).listen(3000)
console.log('Server running at http: 3000');

function resAction (req, res) {
    var fs = require('fs');
    sss
    setTimeout(function(){
        var s = wrong + true;
        console.log(somepath);
        res.writeHead(200, {'Content-Type':'text/plain'});
        res.end('hello world\n');

    },10)
};










