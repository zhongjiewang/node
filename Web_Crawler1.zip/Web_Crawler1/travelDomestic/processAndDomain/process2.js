

// Promise.reject('ddd');

// process.on('rejectionHandled', (p) => {
//     console.log('dddddddddddd')
//   // unhandledRejections.delete(p);
// });


function demo () {

    return new Promise (function(resolve, reject){
        reject('555555')
    })
    .then(function(data){

    });
}
 
var r = demo();

const unhandledRejections = new Map();
process.on('rejectionHandled', (p) => {
    console.log('已经处理')
    console.log(p);
  // unhandledRejections.delete(p);
});

process.on('unhandledRejection', (reason, p) => {
    console.log('未处理')
    console.log(p)
    console.log(reason)
  unhandledRejections.set(p, reason);
  console.log(unhandledRejections)
});

// console.log(unhandledRejections)



// setTimeout(function(){

// r.catch(err => { console.log('我是catch'+err)});
// },0)

process.on('uncaughtException', (err) => {
  console.log(`Caught exception: ${err}`);
});

w;



















