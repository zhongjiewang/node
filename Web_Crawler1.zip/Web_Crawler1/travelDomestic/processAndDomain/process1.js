
var util = require('util');

console.log('当前目录：' + process.cwd());
try {
  process.chdir('/Users/zhongjie/Desktop/node/Web_Crawler1/travelDomestic/test1');

  console.log('新目录：' + process.cwd());
}
catch (err) {
  console.log('chdir: ' + err);
}


console.log(process.versions); 


console.log(process.execPath);


console.log('当前进程 id: ' + process.pid);

console.log(process.title)


console.log(util.inspect(process.memoryUsage())); 


console.log('开始');
//因为它的效率高多了。该函数能在任何 I/O 事前之前调用我们的回调函数。但是这个函数在层次超过某个限制的时候，也会出现瑕疵，详细见
//递归设置 nextTick 的回调就像一个 while(true) ; 循环一样，将会阻止任何 I/O 操作的发生。


process.nextTick(function() {
  console.log('nextTick 回调');
});
console.log('已设定');
// 输出:
// 开始
// 已设定
for (var i = 0; i < 10; i++) {
    console.log(i)
}
console.log(process.uptime())











