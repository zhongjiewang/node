
// 下面这个例子，domain将捕捉不到异步异常
var domain = require('domain');
var EventEmitter = require('events').EventEmitter;

var e = new EventEmitter();

var timer = setTimeout(function () {
    e.emit('data');
}, 10);

function next() {
    e.once('data', function () {
        throw new Error('Receive data error!');
    });
}

var d = domain.create();
d.on('error', function (err) {
    console.log(err);
});

d.run(next);

//如果timer和e两个关键的对象在初始化的时候都时没有在domain的范围之内，因此，当在next函数中监听的事件被触发，执行抛出异常的回调函数时，其实根本就没有处于domain的包裹中，就不会被domain捕获到异常了！

