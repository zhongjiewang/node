
var d = require('domain').create();
var fs = require('fs');

try {
    a
} catch (err) {
    console.log(err)
}

// var d = domain.create();
d.on('error', function(er) {
  console.error('Caught error!', er);
});
d.run(function() {
  process.nextTick(function() {
    setTimeout(function() { // 模拟几个不同的异步的东西
      fs.open('non-existent file', 'r', function(er, fd) {
        if (er) throw er;
        // 继续。。。
      });
    }, 100);
  });
})



// console.log('出错之后')


// d.on('error', function(err) { // 这个错误不会导致进程崩溃，但是情况会更糟糕！ // 虽然我们阻止了进程突然重启动，但是我们已经发生了资源泄露 // 这种事情的发生会让我们发疯。
//     console.log(err);
// });
// // try {
// //     tryCode - 尝试执行代码块
// // }
// // catch(err) {
// //     catchCode - 捕获错误的代码块
// // } 
// // finally {
// //     finallyCode - 无论 try / catch 结果如何都会执行的代码块
// // }
// d.run()







