
var domain = require('domain');
var d = domain.create();

d.on('error',function(err){
    console.log(err);
})

function callErr (a) {
    console.log('woshi' + a)
    setTimeout(function(){
        var s = wrong + true;
        console.log(somePath);
    },10);
}
var a = 5;
d.run(function(){
    callErr(a);
})

// try catch只能捕获同步的错误
//  try {
//     setTimeout(function(){
//          var s = wrong + true;
//         console.log(somePath);
//     },10);
// }catch(err) {
//     console.log('rrrrrr')
//     console.log(err)

// }


// try {
//     tryCode - 尝试执行代码块
// }
// catch(err) {
//     catchCode - 捕获错误的代码块
// } 
// finally {
//     finallyCode - 无论 try / catch 结果如何都会执行的代码块
// }







































