
//增加e和timer到domain的范围内，运行程序
var domain = require('domain');
var EventEmitter = require('events').EventEmitter;

var e = new EventEmitter();

var timer = setTimeout(function () {
    e.emit('data');
}, 10);

function next() {
    e.once('data', function () {
        throw new Error('Receive data error!');
    });
}

var d = domain.create();
d.on('error', function (err) {
    console.log(err);
});

d.add(e);
d.add(timer);

d.run(function(){
    next();
});


// 4. domain的API介绍

// 基本概念

// 隐式绑定: 把在domain上下文中定义的变量，自动绑定到domain对象
// 显式绑定: 把不是在domain上下文中定义的变量，以代码的方式绑定到domain对象
// API介绍

// domain.create(): 返回一个domain对象
// domain.run(fn): 在domain上下文中执行一个函数，并隐式绑定所有事件，定时器和低级的请求。
// domain.members: 已加入domain对象的域定时器和事件发射器的数组。
// domain.add(emitter): 显式的增加事件
// domain.remove(emitter): 删除事件
// domain.bind(callback): 以return为封装callback函数
// domain.intercept(callback): 同domain.bind，但只返回第一个参数
// domain.enter(): 进入一个异步调用的上下文，绑定到domain
// domain.exit(): 退出当前的domain，切换到不同的链的异步调用的上下文中。对应domain.enter()


// domain.dispose(): 释放一个domain对象，让node进程回收这部分资源





