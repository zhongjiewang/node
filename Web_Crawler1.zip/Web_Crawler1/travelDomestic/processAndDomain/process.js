

process.on('exit', function() {
  // 设置一个延迟执行
  setTimeout(function() {
    console.log('主事件循环已停止，所以不会执行');
  }, 0);
  console.log('退出前执行');
});

process.on('SIGINT', function() {
  console.log('收到 SIGINT 信号。  退出请使用 Ctrl + D ');
  process.exit(1);
});

console.log = function(d) {
  process.stdout.write(d + '\n');
};

process.stdin.on('end', function() {
  process.stdout.write('end');
});


// gets 函数的简单实现
function gets(cb){
  process.stdin.resume();
  process.stdin.setEncoding('utf8');

  process.stdin.on('data', function(chunk) {
    console.log('xxxxxx')
     // process.stdin.pause();
     cb(chunk);
  });
}
//标准输入流默认是暂停 (pause) 的，所以必须要调用 process.stdin.resume() 来恢复 (resume) 接收。
gets(function(reuslt){
  console.log("["+reuslt+"]");
     process.stdin.pause();//暂停的话,代表不再监听标准输入,如果
        //没有其他运行的代码,就会对出程序

});

// process.stdin.pause();

console.log('111111111')

//第一个元素会是 'node'， 第二个元素将是 .Js 文件的名称。接下来的元素依次是命令行传入的参数。
///usr/local/bin/node: 0
///Users/zhongjie/Desktop/node/Web_Crawler1/travelDomestic/process.js: 1
// 第一个参数是值,第二个参数是位置
process.argv.forEach(function(val, index, array) {
  // console.log(val + ': ' + index);
  console.log(array);
});

//返回进程当前的工作目录
console.log('当前目录：' + process.cwd());































































