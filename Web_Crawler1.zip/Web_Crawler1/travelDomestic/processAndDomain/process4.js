


// [ '/usr/local/bin/node',
//   '/Users/zhongjie/Desktop/node/Web_Crawler1/travelDomestic/process4.js',
//   '--version' ] argv 
// [ '--harmony' ] execArgv


console.log(process.argv);
console.log(process.execArgv);
 // node --harmony script.js --version 