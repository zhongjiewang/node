
<div class="item spot_list">
<ul class ="summary_list_box">
<li>
<p class="summary_ttl">
<a href="http://4travel.jp/domestic/area/kinki/kyoto/kyoto/karasuma/hotplace/10667359/" class="ico_kankospot">
錦市場
<em></em>
</a>
</p>
<div class="inner group">
<div class="unit_img02">
<div class="img">
<p>
<a href="http://4travel.jp/domestic/area/kinki/kyoto/kyoto/karasuma/hotplace/10667359/">
<img alt="錦市場" height="90" src="http://img.4travel.jp/img/tcs/t/tips/pict/sml/140/817/sml_14081731.jpg" width="120">
</a></p>
</div>
<div class="txt">
<p class="area">エリア：
二条・烏丸・河原町 (京都)
</p>
<p></p>

<p class="category"><span class="ttl">カテゴリ：</span>
市場・商店街
,&nbsp;&nbsp;
名所・史跡
,&nbsp;&nbsp;
グルメ・レストラン

</p>

<p class="access"><span class="ttl">住所：</span>京都府京都市中京区錦小路通青町～高倉間
（<a href="http://4travel.jp/domestic/area/kinki/kyoto/kyoto/karasuma/hotplace/10667359-map/" class="map">地図</a>）
</p>
<p class="tips">
<span class="star star40_m">4.24</span>
<span class="divide">｜</span>
  <a href="http://4travel.jp/domestic/area/kinki/kyoto/kyoto/karasuma/hotplace/10667359-tips/" class="ico_tips_s">
  <span class="num">317</span>件
</a></p>
<p class="info">
</p>
<ul class="spot_tips">
<li class="tips_cs4_5_m">
<a href="/domestic/area/kinki/kyoto/kyoto/karasuma/tips/12358427/">色々食べ歩きできて楽しい</a>&nbsp;by&nbsp;
tequilaさん</li>
<li class="tips_cs4_5_m">
<a href="/domestic/area/kinki/kyoto/kyoto/karasuma/tips/12358427/">【錦市場】いつも大盛況だが買い物客は不在。見るだけで買わない観光客だけしかいない。衰退の一途。</a>&nbsp;by&nbsp;
こどもの隠れ家さん</li>
</ul>
</div>
<!-- / .unit_img02 --></div>
<!-- / .inner --></div>
</li>

<li>
<p class="summary_ttl">
<a href="http://4travel.jp/domestic/area/kinki/kyoto/kyoto/kyotoeki/hotplace/10005176/" class="ico_kankospot">
京都タワー
<em></em>
</a>
</p>
<div class="inner group">
<div class="unit_img02">
<div class="img">
<p>
<a href="http://4travel.jp/domestic/area/kinki/kyoto/kyoto/kyotoeki/hotplace/10005176/">
<img alt="京都タワー" height="90" src="http://img.4travel.jp/img/tcs/t/tips/pict/sml/140/776/sml_14077685.jpg" width="120">
</a></p>
</div>
<div class="txt">
<p class="area">エリア：
京都駅周辺 (京都)


</p>
<p></p>

<p class="category"><span class="ttl">カテゴリ：</span>
名所・史跡

</p>

<p class="access"><span class="ttl">住所：</span>京都府京都市下京区烏丸通七条下る
（<a href="http://4travel.jp/domestic/area/kinki/kyoto/kyoto/kyotoeki/hotplace/10005176-map/" class="map">地図</a>）
</p>
<p class="tips">
<span class="star star40_m">4.23</span>
<span class="divide">｜</span>
  <a href="http://4travel.jp/domestic/area/kinki/kyoto/kyoto/kyotoeki/hotplace/10005176-tips/" class="ico_tips_s">
  <span class="num">386</span>件
</a></p>
<p class="info">
</p>
<ul class="spot_tips">
<li class="tips_cs4_5_m">
<a href="/domestic/area/kinki/kyoto/kyoto/kyotoeki/tips/12354425/">京都の街をぐるりと一周眺められます</a>&nbsp;by&nbsp;
さらんさん</li>
<li class="tips_cs4_5_m">
<a href="/domestic/area/kinki/kyoto/kyoto/kyotoeki/tips/12354425/">高さ131メートル</a>&nbsp;by&nbsp;
だるまっこさん</li>
</ul>
</div>
<!-- / .unit_img02 --></div>
<!-- / .inner --></div>
</li>
</ul>
</div>

