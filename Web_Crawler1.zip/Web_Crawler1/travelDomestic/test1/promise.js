

var fs = require('fs');
var Promise = require('bluebird');
 // fs.stat(hashPath, function (err, stats) {
 //        if (err) {//目录不存在,需要创建目录;
 //            fs.mkdir(finalPath,function(err){
 //                if (err) return console.error(err);
 //                else return finalPath;
 //            });

 //        }else {
 //            return finalPath;
 //        }
 //    });

function fsMake (path) {

   var k =   new Promise (function (resolve, reject) {
                fs.stat(path,function (err, stats) {
                    if(!err) {
                        resolve(path) ;
                    }else {
                        fs.mkdir (path, function(err){
                            if(!err) resolve(path);
                        })
                    }
                });
            }); 

   return k;
};

// var path  = '/Users/zhongjie/Desktop/node/Web_Crawler1/ travelDomestic';
var firstDictionary = 'test1';

fsMake(firstDictionary)
.then(function(path) {
    let finalPath = path + '/' + 'test2';
    // return  fsMake(finalPath);
})
































