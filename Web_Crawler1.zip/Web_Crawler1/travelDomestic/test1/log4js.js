

process.on('exit', function() {
  

    console.log('退出前执行');
});


// 引入 events 模块
var events = require('events');
// 创建 eventEmitter 对象
var eventEmitter = new events.EventEmitter();

// eventEmitter.on('error',function(arg1) {
//     console.log(arg1);
//     console.log('monitor');
// })


eventEmitter.addListener('error', function (ar) {
    console.log(ar)
    console.log('minnnnn')
});


var i = 0;

process.on('uncaughtException', function (err) {
    logger.error('Cheese is too ripe!');
    
  console.log('错误' + err.stack);
});


var log4js = require('log4js'); 
//console log is loaded by default, so you won't normally need to do this 
//log4js.loadAppender('console'); 
log4js.loadAppender('file');//加载file模块
//log4js.addAppender(log4js.appenders.console()); 
log4js.addAppender(log4js.appenders.file('./test2/dd.log'), 'urlLog');
 
var logger = log4js.getLogger('urlLog');

logger.error('Cheese is too ripe!');
//致命的
logger.fatal('Cheese was breeding ground for listeria.');

time();


var name = 'd';

name.getname('dd');




// eventEmitter.emit('error')



// process.on('SIGINT', function() {
//   console.log('收到 SIGINT 信号。  退出请使用 Ctrl + D ');
//   process.exit(1);
// });

function time  () {
    console.log('nihao')
    i ++;
    console.log(`${i}`);
    if (i == 2) {

        name.gg('dd');
    }

    setTimeout(function () {
        time();
    },5000);
}

// setTimeout(function () {
//     console.log('cuowugggggggg')
//     name.gg();
// },10050);
























































