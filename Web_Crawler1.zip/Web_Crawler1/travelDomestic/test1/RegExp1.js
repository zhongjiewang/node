
// 'use strict'

// // var htmlStr = 

// // <p class="summary_ttl">
// // <a href="http://4travel.jp/domestic/area/kinki/kyoto/kyoto/karasuma/hotplace/10667359/" class="ico_kankospot">
// // 錦市場
// // <em></em>
// // </a>
// // </p>


// // var x = 'a', y = 'b';
// // var z = `${x,y}`; //'b'
// // // 模板字符串里面${var}是变量的占位符。
// // // x,y 逗号运算符是返回符号右边的值，这里面等于y。

// for (let  i = 2; i <= 1; i++) {
//     let temp = `Hello ${i}, how are you ${i}`;

//     console.log(temp)
    
// }
// // console.log()


// // 字符串中嵌入变量
// var name = "Bob", time = "today";
// // var temp = `Hello ${name}, how are you ${time}?`

// // console.log(temp)





































