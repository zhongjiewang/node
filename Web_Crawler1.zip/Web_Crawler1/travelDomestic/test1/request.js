




var request = require('request');
request('httwww.baidu.com', function (error, response, body) {

    console.log(error)
  if (!error && response.statusCode == 200) {
    console.log(body) // Show the HTML for the Google homepage. 
  }
})


setInterval(function(){
    
    console.log('ddd')
},1000);


