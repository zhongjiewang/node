#!/usr/bin/env node
'use strict';

const userAgent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36';
var  writeImageSuccessCount = 1;

var crypto = require('crypto'),
    Crawler = require('js-crawler'),
    co = require('co'),
    Promise = require('bluebird'),
    fs = require('fs'),
    mongoClient = require('mongodb').MongoClient,
    Encoding = require('encoding-japanese'),
    keypress = require('keypress');

var log4js = require('log4js'); 
log4js.loadAppender('file');
log4js.addAppender(log4js.appenders.file('print.log'), 'urlLog');
var logger = log4js.getLogger('urlLog');


var crawler = new Crawler();
 
const crawlerDatabase = 'mongodb://localhost:27017/attractionCrawler',
      collectionNameOfTravelDetailLinks = 'attractionDetailLinks';

// When the code is running in the server, please change the root path of the picture, and make sure the root path is exist;
// const rootPathOfImages = '/galleries/4travel.jp/attractions/4travelPictures/';

const rootPathOfImages = '/Users/zhongjie/Desktop/SavePicture/test/';

fs.stat(rootPathOfImages,function (err, stats) {  
    if(err)  { console.error(`the rootPath is not exit,please create it: ${rootPathOfImages}`);   process.exit(1);}
});

logger.trace('requestFrom55000');


co(function*() {
    let db = yield mongoClient.connect(crawlerDatabase);
    let linksColl = db.collection(collectionNameOfTravelDetailLinks);
    let records = yield linksColl.find().toArray();
    yield db.close();

    console.log('%d stations to crawl', records.length);

    crawler.crawl();

    for (let record of records.splice(55000)) {
        if (record.href.match(/domestic/ig)){
           crawler.enqueueRequest({
                url: record.href.slice(0,-1) + '-pict/',
            URLType: 'imagePageFirst',
                 id: record.id
            });
        }else {
            crawler.enqueueRequest({
                url: record.href + '/pict',
            URLType: 'imagePageFirst',
                 id: record.id
            });
        };
    };

    logSave();
})
.catch(err => { console.error(err.stack); });



var needSaveDetailLink ;
var needSavePageSecondLink;
var needSaveImageLink;

crawler.configure({
    ignoreRelative: false, 
    depth: 1,
    userAgent: userAgent,
    maxConcurrentRequests: 5,
    oblivious: true,
    enableTimeOut: true,// this option is very important 'coz sometimes this website will pend responding (forever!) and then the accumulated pending requests will exceed the concurrent threshold thus prevent the web crawler (forever!) from issuing other requests
    shouldCrawl: function(url) {
        return true;
    },
    onSuccess: function(page) {
        // console.log('Received message from: %s', page.actualUrl);
        if (page.actualUrl.match(/domestic/ig)) {
            page = encodingConvert(page);
        };

        if (page.options.URLType === 'imagePageFirst') {
            needSaveDetailLink = page.actualUrl;

            // if pageNumber is 1 , code will not perform the following request
            parseImagePageHtmlAndRequestImagePageFromPageSecond(this, page.actualUrl, page.options.id,page.body);
            parseImagePageHtmlAndRequestImageUrl(this, page.actualUrl, page.options.id, page.body);
        };

        if (page.options.URLType === 'imagePageFromPageSecond') {
            needSavePageSecondLink = page.actualUrl;
            parseImagePageHtmlAndRequestImageUrl(this, page.actualUrl, page.options.id, page.body);
        };

        if (page.options.URLType === 'image') {
            needSaveImageLink = page.actualUrl;
            parseImageBufferAndwriteImage(page.actualUrl,page.options.id, page.body,rootPathOfImages);
        };
    },

    onFailure: function(postmortem) {
        logger.error('Failed to crawl %s (%s)', postmortem.url, postmortem.status? `HTTP: ${postmortem.status}` : `OTHER: ${postmortem.error}`);
        logger.error(`statusSEE :${postmortem.status}`);// get 410 number
        console.log([410].indexOf(postmortem.status));
         // 410 是资源被删除,已经不存在
        if (postmortem.status && postmortem.status !== 404 && postmortem !== 410 ) {
            console.log('...Ask for re-crawling when possibily recoverable failure/error returned from web server', postmortem.url);
            return true;
        }
        if (postmortem.error && ['EAI_AGAIN', 'ETIMEDOUT', 'ECONNRESET', 'ENOTFOUND'].indexOf(postmortem.error.code) >= 0) {
            console.log('...Ask for re-crawling in case of: 1. name resolving error, 2. timeout, 3. connection reset');
            return true;
        }
        return false;
    },
    onAllFinished: function() {
        
        console.log('All attraction details have been crawled');
        console.log(`\nWriteImageSuccessCount: ${writeImageSuccessCount}`);
        setTimeout(function(){ process.exit(1);} , 10000);     
    }
});

keypress(process.stdin); 
process.stdin.on('keypress', function (ch, key) {
  
    if (key && key.name === 'space') {
        if (crawler) {
            crawler.dump();
            console.log(`\nWriteImageSuccessCount: ${writeImageSuccessCount}`);
            console.log(`Write to Path ${rootPathOfImages}\n`);
        };
    };

    if (key && key.ctrl && key.name == 'c') {
        process.exit(1);
    }
});


function logSave() {
    
    if(crawler){
        let  obj =  crawler.dump();
        // console.log(obj);
        logger.info(`request priorityQueue length :${obj.priorityQueue.length}`);
        logger.info(`request queue length : ${obj.queue.length}\n`);
    }
    setTimeout(function(){
        logSave();
    },1000);
}

process.stdin.setRawMode(true);
process.stdin.resume();

process.on('uncaughtException', function (err) {
    console.log('错误' + err.stack);

    logger.error('捕捉到错误');
    logger.fatal(`Request the Url is Wrong,${needSaveDetailLink}`);
    logger.fatal(`pagesecond:${needSavePageSecondLink}`);
    logger.fatal(`imageUrl: ${needSaveImageLink}`);
    //致命的
    logger.fatal(`${err.stack}`);

});


function encodingConvert (page) {
    let type = parseType(page.response);
    let utf8Array = Encoding.convert(page.response.body, {
                                        to: 'UTF8',
                                        from: 'EUCJP'
                                    });
    let buffer = new Buffer(utf8Array);  
    if (type === 'text/html') page.body = buffer.toString('utf-8');

    return page;
}

function parseType (response) {
    var result = null;  
    var match = /^(.+?)(;.+)?$/gi.exec(response.headers['content-type']);
    if (match && match[1]) result = match[1]; 
    return result;
}

function parseImagePageHtmlAndRequestImagePageFromPageSecond(crawler, url, attractionID, content) {
    
    if (url.match(/domestic/ig)) {

        let tempSumNumber1 = /全<span class="num">(.*?)<\/span>件中/ig.exec(content);
        let tempSumNumber2 = parseInt(tempSumNumber1[1].replace(/,/ig,''));
        let pagesNumber = getPagesNumber(tempSumNumber2, 21);  
       
        for (let  i = 2; i <= pagesNumber; i++) {
            crawler.enqueueRequest({
                method:'POST',
                   url: url,
                  form:{page:i},
               URLType:'imagePageFromPageSecond',
                    id:attractionID
            },1,true);
        };

    }else {
        
        let tempSumNumber1 = /<span class="u_commentNumber">(.*?)<span>件<\/span><\/span>/ig.exec(content);
        // console.log(tempSumNumber1[1]);
        let tempSumNumber2 = parseInt(tempSumNumber1[1].replace(/,/ig,''));
        let pagesNumber = getPagesNumber(tempSumNumber2,50);

        for (let  i = 2; i <= pagesNumber; i++) {
            crawler.enqueueRequest({
                method:'GET',
                   url:url+'?page='+i,
               URLType:'imagePageFromPageSecond',
                    id:attractionID
            },1,true);
        };

    } 
}

function getPagesNumber (sum, numberOfOnePage) {
    let pagesNumber;
    if ((sum%21) != 0)  {
        pagesNumber = parseInt(sum/numberOfOnePage) + 1;
    }else {
        pagesNumber = parseInt(sum/21); 
    }
    return pagesNumber;
}

function  parseImagePageHtmlAndRequestImageUrl (crawler, url, attractionID, content) {

    let pict_list_str;
    let imageUrlRegExp;
    if(url.match(/domestic/ig)) {
        pict_list_str = /<div class="pict_list">[^]*?pict_list --><\/div>/ig.exec(content);
        imageUrlRegExp = /<li><a href="(.*?)\?(.*?)" tips=/ig;

    }else {
        pict_list_str = /<ul class="u_spotPhotoList js_LightboxGallery2">[^]*?<\/ul>/ig.exec(content);
        imageUrlRegExp = /<a href="(.*?)" class=/ig;
    };
    
    let result;
    while ((result = imageUrlRegExp.exec(pict_list_str[0])) != null) {
        crawler.enqueueRequest({
               url:result[1],
           URLType:'image',
                id:attractionID
        },1,true);
    };
}


function parseImageBufferAndwriteImage (url, attractionID, bufferContent, rootPath) {
    // console.log('AttractionID :' + attractionID);

    let startStr = 'src_';
    let tempStart = url.indexOf(startStr);
    let imageIDName = url.slice(tempStart+startStr.length);

    getPathAndWrite(rootPath, attractionID, imageIDName, bufferContent);
 }   


function getPathAndWrite (rootPath, attractionID, imageIDName, bufferContent) {

    let theLastThreeNumber = attractionID.slice(-3);

    let sumOftheLastThreeNumber = function (){
                let sum = 0;
                for (let i = 0; i < theLastThreeNumber.length; i++) {
                    let temp = parseInt(theLastThreeNumber[i]);
                    sum += temp;
                };
                return sum;
        }();
    
    let firstDictionary = sumOftheLastThreeNumber.toString();

    let hashPath = rootPath + firstDictionary;

    fsMake(hashPath)
    .then(function(hashPath) {
        let finalPath = hashPath + '/' + attractionID;
        return fsMake(finalPath);
    })
    .then(function(finalPath) {
        writeFile(finalPath+'/'+imageIDName, bufferContent,{encoding: null});
    });
 
};


function fsMake (path) {
   let  k =   new Promise (function (resolve, reject) {
                fs.stat(path,function (err, stats) {
                    if(!err) {
                        resolve(path) ;
                    }else {
                        fs.mkdir (path, function(err){
                            if(!err) resolve(path);
                        })
                    }
                });
            }); 

   return k;
};

function writeFile(path, data, options) {
    fs.writeFile(path, data, options,function(err){
        // if(!err) console.log('Wrtie to Success :' + path);
        // else console.error('Write Failed :' + path);
        if (!err) writeImageSuccessCount ++ ;
    })
};
 


    //必须是路径已经存在的情况下,才会有回调函数stats,如果该路径下没有文件,则直接报错,并不会有stats的参数
    // fs.stat(hashPath, function (err, stats) {
    //     if (err) {//目录不存在,需要创建目录;
    //         fs.mkdir(finalPath,function(err){
    //             if (err) return console.error(err);
    //             else return finalPath;
    //         });

    //     }else {
    //         return finalPath;
    //     }
    // }); 
 
// fs.exists(path, callback)

// 判断文件是否存在，回调函数参数是 bool 值。例如：
// fs.exists('/etc/passwd', function (exists) {
//   util.debug(exists ? "it's there" : "no passwd!");
// });
// fs.exists() 是老版本的函数，因此在代码里不要用。
// 另外，打开文件前判断是否存在有漏洞，在fs.exists() 和 fs.open() 调用中间，另外一个进程有可能已经移除了文件。最好用 fs.open() 来打开文件，根据回调函数来判断是否有错误。
// fs.exists() 未来会被移除。
// fs.existsSync(path)

// fs.exists() 的同步版本. 如果文件存在返回 true, 否则返回false。
// fs.existsSync() 未来会被移除。
 //http://4travel.jp/domestic/area/okinawa/okinawa/hontohokubu/motobu/zoo/10000190/
 // 0 57个 1 60个; 共计117个
 // var arr = ['http://4travel.jp/domestic/area/kyushu/nagasaki/shimabara/shimabaraHantonanbu/park/10018813-pict/',
 //            'http://spot4travel.jp/landmark/dm/10032391/pict/',
 //            'http://4travel.jp/domestic/area/okinawa/okinawa/hontohokubu/motobu/zoo/10000190-pict/',
 //            'http://spot4travel.jp/landmark/dm/10667842/pict',
 //            'http://4travel.jp/domestic/area/kyushu/kagoshima/izumi/izumi/hotplace/11334051-pict/',
 //            'http://4travel.jp/domestic/area/kanto/chiba/maihamaurayasu/tokyodisneyresort/themepark/11187263/',
 //            'http://spot4travel.jp/landmark/dm/10033189',
 //            'http://4travel.jp/domestic/area/kanto/chiba/maihamaurayasu/tokyodisneyresort/themepark/11187264/',
 //            'http://spot4travel.jp/landmark/dm/10002108',
 //            'http://4travel.jp/domestic/area/chugoku/hiroshima/miyajima/miyajima/temple/10002779/',
 //            'http://4travel.jp/domestic/area/hokkaido/hokkaido/asahikawa/asahikawa/zoo/10000013/',
 //            'http://4travel.jp/domestic/area/kanto/tokyo/ueno/asakusa/temple/10000931/',
 //            'http://spot4travel.jp/landmark/dm/10002696'];



